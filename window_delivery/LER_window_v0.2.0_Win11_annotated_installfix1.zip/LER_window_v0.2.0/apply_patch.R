# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Run with R >= 4.1:
# Rscript apply_patch.R /path/to/clean/LakeEnsemblR /path/to/LakeEnsemblR-window
# Builds a source tree; it does NOT replace the currently installed package.
if (getRversion() < "4.1.0") stop("R >= 4.1.0 is required")
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Usage: Rscript apply_patch.R CLEAN_SOURCE NEW_DESTINATION")
script_arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
if (length(script_arg) != 1L) stop("Run this installer with Rscript")
home <- dirname(normalizePath(sub("^--file=", "", script_arg), winslash = "/"))
source(file.path(home, "R", "window_calibration.R"), encoding = "UTF-8")
source_dir <- normalizePath(args[1], winslash = "/", mustWork = TRUE)
dest <- args[2]
if (file.exists(dest) || dir.exists(dest)) stop("Destination must not already exist")
# Do not create the destination inside the source (recursive copies).
dest_parent <- normalizePath(dirname(dest), winslash = "/", mustWork = TRUE)
if (identical(dest_parent, source_dir) || startsWith(dest_parent, paste0(source_dir, "/")))
  stop("Destination must be outside the source tree")
des <- read.dcf(file.path(source_dir, "DESCRIPTION"))
if (des[1, "Package"] != "LakeEnsemblR" || des[1, "Version"] != "1.2.9")
  stop("Only a clean LakeEnsemblR 1.2.9 source tree is accepted")
# Version labels alone cannot identify the reviewed official source revision.
pin <- read.csv(file.path(home, "provenance", "upstream_source_sha256.csv"),
                stringsAsFactors = FALSE, check.names = FALSE)
if (!nrow(pin) || anyDuplicated(pin$file) ||
    any(!grepl("^[0-9a-f]{64}$", pin$sha256)) ||
    any(grepl("(^/|^[A-Za-z]:|(^|/)\\.\\.(/|$)|\\\\)", pin$file)))
  stop("Invalid pinned upstream source manifest")
pinned_paths <- file.path(source_dir, pin$file)
if (!all(file.exists(pinned_paths)) || any(dir.exists(pinned_paths)))
  stop("Missing files from the pinned official source revision")
actual_hashes <- vapply(pinned_paths, .lw_sha256_file, character(1))
if (!identical(unname(actual_hashes), pin$sha256))
  stop("Source differs from the pinned official revision; use the supplied complete package")
actual_files <- list.files(source_dir, recursive = TRUE, all.files = TRUE, no.. = TRUE)
actual_files <- actual_files[!grepl("^(\\.git|\\.Rproj\\.user)(/|$)", actual_files)]
if (!setequal(actual_files, pin$file))
  stop("Unexpected source files; start with a clean pinned official source tree")
files <- list.files(file.path(source_dir, "R"), "\\.[Rr]$", full.names = TRUE)
text <- unlist(lapply(files, readLines, warn = FALSE))
if (any(grepl("LER_WINDOW_MEAN|window_mean_match|lw_dispatch", text)))
  stop("Prior/custom window patches detected. Start from an unmodified upstream source")
required <- c("R/cali_ensemble.R", "R/get_output.R", "R/read_flake_out.R", "NAMESPACE")
if (!all(file.exists(file.path(source_dir, required)))) stop("Incomplete upstream source tree")
.lw_copy_tree(source_dir, dest, exclude_top = c(".git", ".Rproj.user"))
dest <- normalizePath(dest, winslash = "/", mustWork = TRUE)
path <- file.path(dest, "R", "cali_ensemble.R")
original_text <- readLines(path, warn = FALSE)
parsed <- parse(path, keep.source = TRUE)
is_target <- vapply(parsed, function(z) is.call(z) && identical(z[[1]], as.name("<-")) &&
                     identical(z[[2]], as.name("cali_ensemble")), logical(1))
if (sum(is_target) != 1L) stop("Could not uniquely locate cali_ensemble assignment")
k <- which(is_target)
fun <- eval(parsed[[k]][[3]], envir = .GlobalEnv)
if (!all(c("config_file", "num", "param_file", "cmethod", "qualfun", "parallel", "job_name",
           "model", "folder", "spin_up", "out_f", "ncores", "tmp_dir", "...") %in% names(formals(fun))))
  stop("Unexpected cali_ensemble signature")
old_body <- body(fun)
fml <- as.list(formals(fun)); dots <- fml["..."]; fml <- fml[names(fml) != "..."]
formals(fun) <- as.pairlist(c(fml, dots, alist(window = NULL)))
hook <- quote(if (!is.null(window)) {
  return(.lw_dispatch(config_file = config_file, num = num, param_file = param_file,
    cmethod = cmethod, qualfun_supplied = !missing(qualfun), parallel = parallel,
    job_supplied = !missing(job_name), model = model, folder = folder, spin_up = spin_up,
    out_f = out_f, ncores = ncores, tmp_dir = tmp_dir, window = window, dots = list(...)))
})
body(fun) <- as.call(c(list(as.name("{"), hook), as.list(old_body)[-1L]))
# Structural regression: the entire original function body is preserved as the tail.
canonical_expr <- function(x) parse(text = deparse(x, width.cutoff = 500L,
  control = c("keepInteger", "keepNA")), keep.source = FALSE)[[1L]]
original_tail <- as.call(c(list(as.name("{")), as.list(body(fun))[-c(1L, 2L)]))
if (!identical(canonical_expr(original_tail), canonical_expr(old_body)))
  stop("Internal patch error: original code was changed")
sr <- attr(parsed, "srcref")[[k]]
first <- as.integer(sr[1]); last <- as.integer(sr[3])
header <- if (first > 1L) original_text[seq_len(first - 1L)] else character()
footer <- if (last < length(original_text)) original_text[seq.int(last + 1L, length(original_text))] else character()
# Deparsing a function object in a call can retain attributes; explicitly deparse only the function.
newfun <- deparse(fun, width.cutoff = 100L, control = "keepInteger")
newfun[1] <- paste0("cali_ensemble <- ", newfun[1])
writeLines(c(header, newfun, footer), path, useBytes = TRUE)
file.copy(file.path(home, "R", "window_calibration.R"), file.path(dest, "R", "window_calibration.R"))
exports <- c("ler_modis_windows", "ler_window_predict", "calc_fit_window", "ler_window_control",
             "ler_read_window_surface", "ler_window_probe", "cali_window_ensemble", "evaluate_window_best")
ns <- readLines(file.path(dest, "NAMESPACE"), warn = FALSE)
writeLines(unique(c(ns, paste0("export(", exports, ")"))), file.path(dest, "NAMESPACE"))
# New source version, not an assertion of upstream release or validation.
des[1, "Version"] <- "1.2.9.9002"
des[1, "Depends"] <- "R (>= 4.1)"
des[1, "License"] <- "GPL-2 + file LICENSE"
imports <- trimws(unlist(strsplit(des[1, "Imports"], ",")))
needed_imports <- c("digest", "purrr")
for (package in needed_imports) {
  if (!any(sub("[[:space:]].*$", "", imports) == package)) imports <- c(imports, package)
}
des[1, "Imports"] <- paste(imports, collapse = ",\n    ")
if ("Collate" %in% colnames(des))
  des[1, "Collate"] <- paste(des[1, "Collate"], "'window_calibration.R'", sep = "\n")
write.dcf(des, file.path(dest, "DESCRIPTION"))
dir.create(file.path(dest, "inst", "window_patch"), recursive = TRUE, showWarnings = FALSE)
manifest <- data.frame(file = c(required, "DESCRIPTION"),
                       source_md5 = unname(tools::md5sum(file.path(source_dir, c(required, "DESCRIPTION")))))
write.csv(manifest, file.path(dest, "inst", "window_patch", "source_manifest.csv"), row.names = FALSE)
commit <- tryCatch(system2("git", c("-C", shQuote(source_dir), "rev-parse", "HEAD"), stdout = TRUE, stderr = FALSE),
                   error = function(e) "UNAVAILABLE")
if (!length(commit) || (!is.null(attr(commit, "status")) && attr(commit, "status") != 0L)) commit <- "UNAVAILABLE"
writeLines(c("Extension: 0.2.0", paste("Upstream git commit:", paste(commit, collapse = " "))),
           file.path(dest, "inst", "window_patch", "VERSION.txt"))
file.copy(file.path(home, "README_中文.md"), file.path(dest, "inst", "window_patch", "README_window.md"))
file.copy(file.path(home, "man_window.Rd"), file.path(dest, "man", "window_calibration.Rd"))
# Document the named-only window formal after ..., preserving old positional calls.
rd <- file.path(dest, "man", "cali_ensemble.Rd")
if (file.exists(rd)) {
  lines <- readLines(rd, warn = FALSE)
  at <- which(lines == "\\arguments{")
  if (length(at) != 1L) stop("Could not locate arguments in upstream man page")
  lines <- append(lines, "\\item{window}{NULL preserves the original route; a ler_window_control object enables the explicit-window LHC route. This is a named-only argument.}", after = at)
  dots_at <- which(trimws(lines) == "...")
  if (length(dots_at) != 1L) stop("Could not locate ... in upstream usage")
  lines[dots_at] <- "  ... ,"
  lines <- append(lines, "  window = NULL", after = dots_at)
  writeLines(lines, rd)
}
# Reparse the saved function, not only the in-memory patch, and verify compatibility.
saved <- parse(path, keep.source = FALSE)
saved_k <- which(vapply(saved, function(z) is.call(z) && identical(z[[1]], as.name("<-")) &&
  identical(z[[2]], as.name("cali_ensemble")), logical(1)))
saved_fun <- eval(saved[[saved_k]][[3L]], envir = .GlobalEnv)
saved_tail <- as.call(c(list(as.name("{")), as.list(body(saved_fun))[-c(1L, 2L)]))
if (!identical(canonical_expr(saved_tail), canonical_expr(old_body)))
  stop("Saved source does not preserve the original function body")
if (!identical(names(formals(saved_fun)), c(names(fml), "...", "window")))
  stop("Old positional formals were changed")
# Parse ALL R files using real R; stop on any syntax error.
for (p in list.files(file.path(dest, "R"), "\\.[Rr]$", full.names = TRUE)) parse(p)
# Run the supplied numerical tests in this R session before declaring the source ready.
sys.source(file.path(home, "tests", "test_core.R"), envir = .GlobalEnv)
source(file.path(home, "tools", "annotate_package.R"), local = TRUE, encoding = "UTF-8")
ler_annotate_package_source(dest)
cat("\nPatched source generated and core numerical checks passed:", dest, "\n")
cat("Install it into a separate R library; restart R before running models.\n")
