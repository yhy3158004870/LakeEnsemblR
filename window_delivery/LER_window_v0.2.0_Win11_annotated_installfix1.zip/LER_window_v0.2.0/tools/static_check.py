# [LER-WINDOW NEW SUPPORT FILE] This support tool is absent from official LER.
"""Lexical checks only. This is NOT an R parser and does not execute R."""
from pathlib import Path
import json
ROOT = Path(__file__).resolve().parents[1]
def check(path):
    s=path.read_text(encoding='utf-8'); stack=[]; quote=None; comment=False; i=0; line=1
    escapes=set('abfnrtv\\\'"`01234567xuU\n')
    while i<len(s):
        c=s[i]
        if c=='\n': line+=1; comment=False
        if comment: i+=1; continue
        if quote:
            if c=='\\':
                if i+1>=len(s) or s[i+1] not in escapes:
                    raise AssertionError(f'{path.name}:{line}: suspicious escape')
                i+=2; continue
            if c==quote: quote=None
            i+=1; continue
        if c=='#': comment=True
        elif c in "\"'`": quote=c
        elif c in '({[': stack.append((c,line))
        elif c in ')}]':
            if not stack or stack[-1][0]!='({['[')}]'.index(c)]:
                raise AssertionError(f'{path.name}:{line}: bracket mismatch')
            stack.pop()
        i+=1
    assert not stack and quote is None, (path,stack,quote)
    return {'file':str(path.relative_to(ROOT)),'lexical_check':'PASS','R_execution':False}
if __name__=='__main__':
    out=[check(p) for p in sorted(ROOT.rglob('*.R'))]
    print(json.dumps(out,ensure_ascii=False,indent=2))
    (ROOT/'reports'/'static_checks.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
