# [LER-WINDOW NEW SUPPORT FILE] Annotation generator; absent from official LER.
# This edits comments and one legal DESCRIPTION metadata field, not model equations.
ler_annotate_package_source <- function(source_dir) {
  insert_before <- function(lines, positions, comments) {
    for (i in order(positions, decreasing=TRUE))
      lines <- append(lines, comments[[i]], after=positions[i]-1L)
    lines
  }
  p <- file.path(source_dir,"R","cali_ensemble.R")
  x <- readLines(p,warn=FALSE,encoding="UTF-8")
  if (!any(grepl("[LER-WINDOW MODIFIED M001]",x,fixed=TRUE))) {
    signature <- which(startsWith(x,"cali_ensemble <- function"))
    hook <- which(trimws(x)=="if (!is.null(window)) {")
    old <- which(x=="    if (!missing(job_name)) {")
    end <- tail(which(x=="}"),1L)
    stopifnot(length(signature)==1L,length(hook)==1L,length(old)==1L,length(end)==1L)
    x <- insert_before(x,c(signature,hook,old,end),list(
      c("# [LER-WINDOW MODIFIED M001] Named-only window=NULL added after ... .",
        "# All original arguments/defaults are preserved; text was deparsed in v0.2.0."),
      "    # [LER-WINDOW ADD BEGIN M002] Explicit window route; NULL uses upstream body.",
      c("    # [LER-WINDOW ADD END M002]",
        "    # [LER-WINDOW UPSTREAM BODY BEGIN] Original executable AST is preserved."),
      "    # [LER-WINDOW UPSTREAM BODY END]"))
    writeLines(x,p,useBytes=TRUE)
  }
  p <- file.path(source_dir,"R","window_calibration.R")
  x <- readLines(p,warn=FALSE,encoding="UTF-8")
  if (!any(grepl("[LER-WINDOW NEW FILE BEGIN A001]",x,fixed=TRUE))) {
    labels <- c(.lw_canonical_text="Reproducibility, canonical hashes and runtime checks",
      ler_modis_windows="MODIS calendar and observation/contract validation",
      ler_window_predict="Window observation operators and complete coverage checks",
      calc_fit_window="Window error metrics",
      ler_window_control="Public control object and parameter sampling",
      .lw_read_config="Legacy-compatible YAML and immutable input snapshot",
      .lw_run_engine="Adapters invoking the supplied model engines",
      ler_read_window_surface="Read near-surface output with explicit time/depth contract",
      .lw_candidate="Candidate execution, failure handling and permanent evidence",
      ler_window_probe="Project probe and PSOCK worker",
      cali_window_ensemble="Window LHC calibration",
      evaluate_window_best="Best-parameter rerun and split evaluation",
      .lw_dispatch="Dispatch and restrictions for the new route")
    for (n in rev(names(labels))) {
      at <- which(startsWith(x,paste0(n," <- function")))
      stopifnot(length(at)==1L)
      x <- append(x,paste0("# [LER-WINDOW NEW SECTION A001] ",labels[[n]]),after=at-1L)
    }
    x <- c("# [LER-WINDOW NEW FILE BEGIN A001] Entire file added relative to official LER.",
      "# No original model equations, engine binaries or output reader are replaced here.",x,
      "# [LER-WINDOW NEW FILE END A001]")
    writeLines(x,p,useBytes=TRUE)
  }
  p <- file.path(source_dir,"NAMESPACE"); x <- readLines(p,warn=FALSE)
  if (!any(grepl("[LER-WINDOW ADD BEGIN M003]",x,fixed=TRUE))) {
    start <- which(x=="export(ler_modis_windows)")
    end <- which(x=="export(evaluate_window_best)")
    stopifnot(length(start)==1L,length(end)==1L)
    x <- insert_before(x,c(start,end+1L),list(
      "# [LER-WINDOW ADD BEGIN M003] Eight public window interfaces.",
      "# [LER-WINDOW ADD END M003]"))
    writeLines(x,p)
  }
  p <- file.path(source_dir,"DESCRIPTION"); d <- read.dcf(p)
  d <- cbind(d,`X-LER-Modification`=paste(
    "[LER-WINDOW MODIFIED M004] Derived version 1.2.9.9002; Depends R >= 4.1;",
    "Imports add digest and purrr; License notation GPL-2 + file LICENSE.",
    "Original authors and GPL-2 terms retained. Annotation-only edition of extension 0.2.0."))
  if (anyDuplicated(colnames(d))) d <- d[,!duplicated(colnames(d)),drop=FALSE]
  write.dcf(d,p)
  p <- file.path(source_dir,"man","cali_ensemble.Rd");x<-readLines(p,warn=FALSE)
  if (!any(grepl("[LER-WINDOW MODIFIED M005]",x,fixed=TRUE))) {
    at <- which(trimws(x)=="  window = NULL" | trimws(x)=="window = NULL")
    arg <- which(startsWith(x,"\\item{window}"))
    stopifnot(length(at)==1L,length(arg)==1L)
    x<-insert_before(x,c(at,arg),list(
      "% [LER-WINDOW MODIFIED M005] Named-only window usage after ... .",
      "% [LER-WINDOW ADD M005] Documentation for the new window argument."))
    writeLines(x,p)
  }
  p <- file.path(source_dir,"man","window_calibration.Rd");x<-readLines(p,warn=FALSE)
  if (!any(grepl("[LER-WINDOW NEW FILE A002]",x,fixed=TRUE)))
    writeLines(c("% [LER-WINDOW NEW FILE A002] Entire help page added relative to official LER.",x),p)
  p <- file.path(source_dir,"inst","window_patch","VERSION.txt")
  x <- readLines(p,warn=FALSE)
  tag <- "Annotation: [LER-WINDOW NEW METADATA] extension metadata absent from official LER"
  if (!tag %in% x) writeLines(c(x,tag),p)
  invisible(source_dir)
}
