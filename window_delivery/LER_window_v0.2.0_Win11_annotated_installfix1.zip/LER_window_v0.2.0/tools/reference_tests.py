# [LER-WINDOW NEW SUPPORT FILE] This support tool is absent from official LER.
"""Executed Python reference tests for the proposed numerical design.
Not an execution or a validation of the R engine adapters.
"""
from datetime import datetime, timezone, timedelta
from pathlib import Path
import numpy as np
import json
ROOT=Path(__file__).resolve().parents[1]
A=datetime(2001,1,1,tzinfo=timezone.utc).timestamp(); DAY=86400

def windows(year,doy):
    if not isinstance(year,int) or not isinstance(doy,int) or doy not in range(1,362,8):
        raise ValueError('calendar')
    a=datetime(year,1,1,tzinfo=timezone.utc).timestamp()+(doy-1)*DAY
    b=min(a+8*DAY,datetime(year+1,1,1,tzinfo=timezone.utc).timestamp())
    return a,b

def predict(t,y,a,b,dt=DAY,phase=0,method='sample_mean',label='point'):
    t=np.asarray(t,float); y=np.asarray(y,float); tol=1e-3
    if len(t)<2 or np.any(np.diff(t)<=0): raise ValueError('timestamps')
    if np.any(abs((t-phase)/dt-np.round((t-phase)/dt))*dt>tol):raise ValueError('grid')
    if not b>a:raise ValueError('duration')
    if method=='sample_mean':
        n=(b-a)/dt
        if abs(n-round(n))>1e-8:raise ValueError('noninteger window')
        f=phase+np.ceil((a-phase)/dt-tol/dt)*dt
        expected=f+np.arange(round(n))*dt
        ix=np.flatnonzero((t>=a-tol)&(t<b-tol))
        if len(ix)!=len(expected) or np.any(abs(t[ix]-expected)>tol):raise ValueError('missing sample')
        if np.any(~np.isfinite(y[ix])):raise ValueError('nonfinite')
        return float(np.mean(y[ix]))
    if method=='linear_time_mean':
        lo=np.flatnonzero(t<=a+tol); hi=np.flatnonzero(t>=b-tol)
        if not len(lo) or not len(hi):raise ValueError('unbracketed')
        l,r=lo[-1],hi[0]
        if l>=r:raise ValueError('too short')
        ix=np.arange(l,r+1)
        if np.any(abs(np.diff(t[ix])-dt)>tol):raise ValueError('gap')
        if np.any(~np.isfinite(y[ix])):raise ValueError('nonfinite')
        k=np.unique(np.r_[a,t[ix][(t[ix]>a)&(t[ix]<b)],b])
        v=np.interp(k,t[ix],y[ix],left=np.nan,right=np.nan)
        if np.any(~np.isfinite(v)):raise ValueError('interpolate')
        return float(np.sum(np.diff(k)*(v[:-1]+v[1:])/2)/(b-a))
    offset={'start':0,'center':dt/2,'end':dt}[label]
    s=t-offset;e=s+dt; ix=np.flatnonzero((e>a+tol)&(s<b-tol))
    if not len(ix) or s[ix[0]]>a+tol or e[ix[-1]]<b-tol or np.any(abs(np.diff(s[ix])-dt)>tol):raise ValueError('gap')
    if np.any(~np.isfinite(y[ix])):raise ValueError('nonfinite')
    w=np.minimum(e[ix],b)-np.maximum(s[ix],a)
    if abs(w.sum()-(b-a))>tol:raise ValueError('coverage')
    return float(w@y[ix]/w.sum())

def must_fail(fn):
    try: fn()
    except ValueError:return True
    return False

results=[]
def test(name,fn):
    try:
        val=fn()
        if not bool(val):raise AssertionError('wrong value')
        results.append({'test':name,'result':'PASS'})
    except Exception as e:
        results.append({'test':name,'result':'FAIL','error':str(e)})
def eq(a,b):return np.isclose(a,b,atol=1e-10,rtol=0)
t=A+np.arange(8)*DAY;y=np.arange(1,9)
test('complete daily mean',lambda:eq(predict(t,y,A,A+8*DAY),4.5))
test('right endpoint excluded',lambda:eq(predict(np.r_[t,A+8*DAY],np.r_[y,999],A,A+8*DAY),4.5))
test('four subdaily samples not four days',lambda:must_fail(lambda:predict(A+np.arange(4)*10800,np.arange(4),A,A+8*DAY,10800)))
test('only one finite value rejected',lambda:must_fail(lambda:predict(t,np.r_[7,np.repeat(np.nan,7)],A,A+8*DAY)))
test('missing early half window',lambda:must_fail(lambda:predict(t[4:],y[4:],A,A+8*DAY)))
test('duplicate times',lambda:must_fail(lambda:predict(np.r_[t,t[-1]],np.r_[y,8],A,A+8*DAY)))
test('unsorted times',lambda:must_fail(lambda:predict(t[::-1],y[::-1],A,A+8*DAY)))
test('infinite required value',lambda:must_fail(lambda:predict(t,np.r_[np.inf,y[1:]],A,A+8*DAY)))
test('wrong phase not inferred from first row',lambda:must_fail(lambda:predict(t+3600,y,A,A+8*DAY)))
test('common-year end five days',lambda:windows(2001,361)[1]-windows(2001,361)[0]==5*DAY)
test('leap-year end six days',lambda:windows(2004,361)[1]-windows(2004,361)[0]==6*DAY)
test('century 2100 not leap',lambda:windows(2100,361)[1]-windows(2100,361)[0]==5*DAY)
test('year 2000 leap',lambda:windows(2000,361)[1]-windows(2000,361)[0]==6*DAY)
test('calendar resets at Jan 1',lambda:datetime.fromtimestamp(windows(2002,1)[0],timezone.utc).strftime('%m-%d')=='01-01')
test('invalid DOY',lambda:must_fail(lambda:windows(2001,2)))
a,b=windows(2001,361)
test('common-year end excludes next-year outlier',lambda:eq(predict(a+np.arange(6)*DAY,np.r_[np.arange(1,6),999],a,b),3))
mid=(a+b)/2
test('noon midpoint does not define window',lambda:eq(mid%DAY,DAY/2) and a%DAY==0 and b%DAY==0)
tl=A+np.arange(65)*10800; yl=np.arange(65)*3
p=lambda tt,yy:predict(tt,yy,A,A+8*DAY,10800,method='linear_time_mean')
test('linear signal integral exact',lambda:eq(p(tl,yl),96))
test('linear integral requires final boundary',lambda:must_fail(lambda:p(tl[:-1],yl[:-1])))
test('linear integral requires initial boundary',lambda:must_fail(lambda:p(tl[1:],yl[1:])))
test('linear integral no gap',lambda:must_fail(lambda:p(np.delete(tl,20),np.delete(yl,20))))
test('linear integral NaN endpoint',lambda:must_fail(lambda:p(tl,np.r_[np.nan,yl[1:]])))
test('periodic signal integral',lambda:eq(p(tl,10+2*np.cos(2*np.pi*yl/24)),10))
test('midnight samples remain distinct from daily integral',lambda:eq(predict(t,np.repeat(12,8),A,A+8*DAY),12))
test('interval mean start label',lambda:eq(predict(tl[:-1],np.repeat(6,64),A,A+8*DAY,10800,method='interval_mean',label='start'),6))
test('interval mean end label',lambda:eq(predict(tl[1:],np.repeat(6,64),A,A+8*DAY,10800,method='interval_mean',label='end'),6))
test('interval mean centered label',lambda:eq(predict(tl[:-1]+5400,np.repeat(6,64),A,A+8*DAY,10800,phase=5400,method='interval_mean',label='center'),6))
test('interval gap rejected',lambda:must_fail(lambda:predict(np.delete(tl[:-1],20),np.repeat(6,63),A,A+8*DAY,10800,method='interval_mean',label='start')))
test('partial overlap weights',lambda:eq(predict(A+np.array([0,3,6])*3600,[0,6,12],A+3600,A+5*3600,10800,method='interval_mean',label='start'),3))
test('outside-window NaN does not invalidate complete window',lambda:eq(predict(np.r_[A-DAY,t],np.r_[np.nan,y],A,A+8*DAY),4.5))
test('half-window cannot improve a candidate score',lambda:must_fail(lambda:predict(t[:4],y[:4],A,A+8*DAY)))
# Independent analytic test at off-grid endpoints for a linear signal.
test('off-grid integration endpoints',lambda:eq(predict(tl,yl,A+3600,A+191*3600,10800,method='linear_time_mean'),96))
report={'scope':'Executed Python numerical reference tests only; R code and physical models NOT executed',
        'passed':sum(r['result']=='PASS' for r in results),'total':len(results),'results':results}
(ROOT/'reports'/'python_reference_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
assert report['passed']==report['total']
