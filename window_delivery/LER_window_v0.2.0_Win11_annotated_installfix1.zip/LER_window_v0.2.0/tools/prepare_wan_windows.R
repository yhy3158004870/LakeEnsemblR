# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Wan LSWT 8-day release -> traceable master, blank review, approved windows.
# Pure base R, UTF-8 paths, no Python and no automatic scientific approval.
# source(..., encoding = "UTF-8") defines the functions without running a CLI.

.wan_fail <- function(...) stop(..., call. = FALSE)
.wan_cols <- function(x, nms, label) {
  missing <- setdiff(nms, names(x))
  if (length(missing)) .wan_fail(label, " missing columns: ", paste(missing, collapse = ", "))
  if (anyDuplicated(names(x))) .wan_fail(label, " has duplicate column names")
}
.wan_int <- function(x, label, min_value = 1, max_value = 9998) {
  z <- trimws(as.character(x))
  if (anyNA(z) || any(!grepl("^[0-9]+$", z))) .wan_fail(label, " must contain decimal integers")
  a <- suppressWarnings(as.numeric(z))
  if (any(!is.finite(a) | a < min_value | a > max_value)) .wan_fail(label, " is outside supported bounds")
  as.integer(a)
}
.wan_key <- function(x, window = FALSE) {
  .wan_cols(x, c("NAME_ID", "YEAR", if (window) "DOY"), "key table")
  id <- .wan_int(x$NAME_ID, "NAME_ID", max_value = .Machine$integer.max)
  year <- .wan_int(x$YEAR, "YEAR")
  key <- paste(id, year, sep = ":")
  if (window) {
    doy <- .wan_int(x$DOY, "DOY", max_value = 361)
    if (any(!doy %in% seq.int(1L, 361L, 8L))) .wan_fail("DOY must be one of 001,009,...,361")
    key <- paste(key, doy, sep = ":")
  }
  if (anyDuplicated(key)) .wan_fail("Duplicate lake/year", if (window) "/DOY" else "", " keys")
  key
}
.wan_bool <- function(x, label, blank = FALSE) {
  z <- tolower(trimws(as.character(x)))
  z[is.na(z)] <- ""
  valid <- c("true", "false", "1", "0", if (blank) "")
  if (any(!z %in% valid)) .wan_fail(label, " must contain TRUE/FALSE or 1/0", if (blank) " or blank" else "")
  z %in% c("true", "1")
}
.wan_read_csv <- function(x, label) {
  if (is.data.frame(x)) return(x)
  if (!is.character(x) || length(x) != 1L || !file.exists(x)) .wan_fail(label, " must be an existing CSV or data.frame")
  utils::read.csv(x, check.names = FALSE, colClasses = "character", na.strings = "",
                  fileEncoding = "UTF-8-BOM", stringsAsFactors = FALSE)
}
.wan_temp <- function(x, label) {
  z <- trimws(as.character(x))
  missing <- is.na(z) | tolower(z) %in% c("null", "na", "nan", "")
  # Unknown sentinels, Inf and malformed tokens fail rather than becoming NA.
  out <- suppressWarnings(as.numeric(z))
  if (any(!missing & !is.finite(out))) .wan_fail(label, " has an unsupported temperature token")
  out[missing] <- NA_real_
  if (any(out < -273.15, na.rm = TRUE)) .wan_fail(label, " contains values below absolute zero in declared Celsius units")
  out
}
.wan_calendar <- function(year, doy) {
  year <- .wan_int(year, "YEAR"); doy <- .wan_int(doy, "DOY", max_value = 361)
  if (length(year) != length(doy) || any(!doy %in% seq.int(1L, 361L, 8L))) .wan_fail("Invalid year/DOY calendar")
  a <- as.POSIXct(sprintf("%04d-01-01 00:00:00", year), tz = "UTC") + (doy - 1L) * 86400
  y1 <- as.POSIXct(sprintf("%04d-01-01 00:00:00", year + 1L), tz = "UTC")
  if (anyNA(a) || anyNA(y1)) .wan_fail("This R platform cannot represent the requested years")
  b <- as.POSIXct(pmin(as.numeric(a) + 8 * 86400, as.numeric(y1)), origin = "1970-01-01", tz = "UTC")
  fmt <- function(x) format(x, "%Y-%m-%d %H:%M:%S", tz = "UTC")
  data.frame(period_start_UTC = fmt(a), period_end_exclusive_UTC = fmt(b),
             n_days = as.numeric(difftime(b, a, units = "days")),
             label_datetime_UTC = fmt(a + as.numeric(difftime(b, a, units = "secs")) / 2),
             stringsAsFactors = FALSE)
}
.wan_write_csv <- function(x, path) {
  if (file.exists(path)) .wan_fail("Refusing to overwrite existing file: ", path)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  opt <- options(digits = 17L); on.exit(options(opt), add = TRUE)
  utils::write.csv(x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}

# The release files contain lake-level temperatures already converted to Celsius.
# source_units is deliberately explicit: units cannot be recovered from bare TXT.
wan_prepare_master <- function(data_dir, name_id, source_units, out_dir = NULL,
                               calibration_years = integer(), validation_years = integer()) {
  if (!is.character(source_units) || length(source_units) != 1L || is.na(source_units) || source_units != "celsius")
    .wan_fail("source_units must be explicitly 'celsius'; do not rescale Wan release temperatures")
  id <- .wan_int(name_id, "name_id", max_value = .Machine$integer.max)
  if (length(id) != 1L) .wan_fail("Use one NAME_ID per master/window file")
  relative <- c(D_raw = "daytime/LSWT_D_raw.txt", N_raw = "nighttime/LSWT_N_raw.txt",
                D_filled = "daytime/LSWT_D_filled.txt", N_filled = "nighttime/LSWT_N_filled.txt",
                D_filter = "daytime/LSWT_D_filter.txt", N_filter = "nighttime/LSWT_N_filter.txt")
  files <- file.path(data_dir, relative)
  if (any(!file.exists(files))) .wan_fail("Missing source files: ", paste(relative[!file.exists(files)], collapse = ", "))
  read_wide <- function(path) {
    x <- utils::read.table(path, header = TRUE, sep = "\t", quote = "", comment.char = "",
                          colClasses = "character", na.strings = character(), check.names = FALSE,
                          fill = FALSE, fileEncoding = "UTF-8-BOM", stringsAsFactors = FALSE)
    if (identical(names(x)[1L], "%YEAR")) names(x)[1L] <- "YEAR"
    expected <- c("YEAR", "NAME_ID", sprintf("MEAN_%03d", seq.int(1L, 361L, 8L)))
    .wan_cols(x, expected, basename(path))
    if (!identical(names(x), expected)) .wan_fail("Unexpected/reordered wide columns in ", basename(path))
    .wan_key(x)
    x
  }
  all <- lapply(files, read_wide)
  names(all) <- names(relative)
  reference <- .wan_key(all[[1L]])
  for (nm in names(all)) {
    k <- .wan_key(all[[nm]])
    if (length(k) != length(reference) || !setequal(k, reference)) .wan_fail("Source lake/year keys differ: ", nm)
    all[[nm]] <- all[[nm]][match(reference, k), , drop = FALSE]
  }
  take <- .wan_int(all[[1L]]$NAME_ID, "NAME_ID", max_value = .Machine$integer.max) == id
  if (!any(take)) .wan_fail("NAME_ID not found in source files: ", id)
  year <- .wan_int(all[[1L]]$YEAR[take], "YEAR")
  year_order <- order(year); year <- year[year_order]
  doy <- seq.int(1L, 361L, 8L)
  master <- data.frame(NAME_ID = id, YEAR = rep(year, each = length(doy)), DOY = rep(doy, length(year)),
                       stringsAsFactors = FALSE)
  master <- cbind(master, .wan_calendar(master$YEAR, master$DOY))
  for (nm in names(all)) {
    one <- all[[nm]][take, , drop = FALSE][year_order, , drop = FALSE]
    tokens <- as.vector(t(as.matrix(one[, sprintf("MEAN_%03d", doy), drop = FALSE])))
    master[[paste0(nm, "_source_token")]] <- tokens
    master[[paste0(nm, "_celsius")]] <- .wan_temp(tokens, nm)
  }
  master$D_raw_available <- is.finite(master$D_raw_celsius)
  master$N_raw_available <- is.finite(master$N_raw_celsius)
  master$D_raw_missing <- !master$D_raw_available
  master$N_raw_missing <- !master$N_raw_available
  # Filled values at raw-present positions can differ slightly through rounding.
  # Missing raw values, not inequality of temperatures, establish gap origin.
  master$D_gap_filled <- master$D_raw_missing & is.finite(master$D_filled_celsius)
  master$N_gap_filled <- master$N_raw_missing & is.finite(master$N_filled_celsius)
  for (level in c("raw", "filled", "filter")) {
    d <- master[[paste0("D_", level, "_celsius")]]
    n <- master[[paste0("N_", level, "_celsius")]]
    proxy <- (d + n) / 2
    proxy[!is.finite(d) | !is.finite(n)] <- NA_real_
    master[[paste0("DN_", level, "_proxy_celsius")]] <- proxy
  }
  master$source_units <- source_units
  master$dataset_description <- "Wan et al. 2017 lake-level MODIS/Terra 8-day release; DOI:10.1038/sdata.2017.95"
  info_file <- file.path(data_dir, "LAKE_INFO.csv")
  if (!file.exists(info_file)) .wan_fail("LAKE_INFO.csv is required for NAME_ID metadata")
  info <- .wan_read_csv(info_file, "LAKE_INFO")
  .wan_cols(info, c("NAME_ID", "NAME_EN", "LAT_NORTH", "LONG_EAST"), "LAKE_INFO")
  info_id <- .wan_int(info$NAME_ID, "LAKE_INFO NAME_ID", max_value = .Machine$integer.max)
  if (anyDuplicated(info_id) || sum(info_id == id) != 1L) .wan_fail("NAME_ID must uniquely match LAKE_INFO")
  lake <- info[info_id == id, , drop = FALSE]
  for (nm in setdiff(names(lake), "NAME_ID")) master[[nm]] <- lake[[nm]][1L]
  source_manifest <- data.frame(source = c(names(relative), "LAKE_INFO"),
                                 relative_path = c(unname(relative), "LAKE_INFO.csv"),
                                 md5 = unname(tools::md5sum(c(files, info_file))),
                                 source_units = source_units, stringsAsFactors = FALSE)
  for (nm in names(relative)) master[[paste0(nm, "_source_md5")]] <- source_manifest$md5[match(nm, source_manifest$source)]
  cyrs <- .wan_int(calibration_years, "calibration_years")
  vyrs <- .wan_int(validation_years, "validation_years")
  if (anyDuplicated(cyrs) || anyDuplicated(vyrs) || length(intersect(cyrs, vyrs))) .wan_fail("Year splits must be unique and disjoint")
  if (any(!c(cyrs, vyrs) %in% year)) .wan_fail("Requested split years do not exist for this NAME_ID")
  review <- master[, c("NAME_ID", "YEAR", "DOY", "period_start_UTC", "period_end_exclusive_UTC"), drop = FALSE]
  review$include <- ""; review$open_water_ok <- ""; review$quality_ok <- ""; review$gap_filled_ok <- ""
  review$split <- ifelse(master$YEAR %in% cyrs, "calibration", ifelse(master$YEAR %in% vyrs, "validation", ""))
  review$open_water_basis <- ""; review$quality_basis <- ""; review$gap_fill_basis <- ""
  review$reviewer <- ""; review$review_date <- ""; review$notes <- ""
  answer <- list(master = master, review = review, source_manifest = source_manifest)
  if (!is.null(out_dir)) {
    paths <- file.path(out_dir, paste0(c("wan_master_", "wan_review_", "wan_sources_", "wan_master_md5_"), id, ".csv"))
    if (any(file.exists(paths))) .wan_fail("Refusing to overwrite a generated master/review/manifest in ", out_dir)
    .wan_write_csv(master, paths[1L]); .wan_write_csv(review, paths[2L]); .wan_write_csv(source_manifest, paths[3L])
    .wan_write_csv(data.frame(master_file = basename(paths[1L]), md5 = unname(tools::md5sum(paths[1L]))), paths[4L])
    answer$paths <- as.list(setNames(paths, c("master", "review", "sources", "master_md5")))
  }
  answer
}

# Export only approved records. Empty approval produces a header-only window CSV.
# Review must still include every master key, so dropping unreviewed rows cannot
# silently alter the fixed record universe. Scientific judgments remain external.
wan_export_windows <- function(master, review, proxy, output = NULL, allow_gap_filled = FALSE) {
  if (!is.character(proxy) || length(proxy) != 1L || !proxy %in% c("raw", "filled", "filter"))
    .wan_fail("proxy must be explicitly 'raw', 'filled' or 'filter'")
  if (!is.logical(allow_gap_filled) || length(allow_gap_filled) != 1L || is.na(allow_gap_filled))
    .wan_fail("allow_gap_filled must be TRUE or FALSE")
  m <- .wan_read_csv(master, "master"); r <- .wan_read_csv(review, "review")
  key <- .wan_key(m, TRUE); review_key <- .wan_key(r, TRUE)
  if (length(key) != length(review_key) || !setequal(key, review_key)) .wan_fail("Master and review keys must match exactly")
  # Normalize valid alternate decimal representations before grouping by year.
  m$NAME_ID <- .wan_int(m$NAME_ID, "NAME_ID", max_value = .Machine$integer.max)
  m$YEAR <- .wan_int(m$YEAR, "YEAR"); m$DOY <- .wan_int(m$DOY, "DOY", max_value = 361)
  if (length(unique(m$NAME_ID)) != 1L) .wan_fail("Use one NAME_ID per window file")
  # For generated on-disk masters, detect edits to source temperatures/flags.
  if (is.character(master)) {
    id <- .wan_int(m$NAME_ID[1L], "NAME_ID", max_value = .Machine$integer.max)
    manifest_path <- file.path(dirname(master), paste0("wan_master_md5_", id, ".csv"))
    if (!file.exists(manifest_path)) .wan_fail("Master MD5 manifest missing; regenerate with wan_prepare_master()")
    manifest <- .wan_read_csv(manifest_path, "master MD5 manifest")
    .wan_cols(manifest, c("master_file", "md5"), "master MD5 manifest")
    if (nrow(manifest) != 1L || manifest$master_file != basename(master) ||
        manifest$md5 != unname(tools::md5sum(master))) .wan_fail("Master file differs from its generated MD5 manifest")
  }
  value_column <- paste0("DN_", proxy, "_proxy_celsius")
  .wan_cols(m, c("source_units", "period_start_UTC", "period_end_exclusive_UTC", "n_days",
                "D_raw_available", "N_raw_available", "D_gap_filled", "N_gap_filled", value_column,
                paste0(rep(c("D_", "N_"), each = 3L), rep(c("raw", "filled", "filter"), 2L), "_celsius")), "master")
  if (anyNA(m$source_units) || any(m$source_units != "celsius")) .wan_fail("Master units must all be explicitly celsius")
  calendar <- .wan_calendar(m$YEAR, m$DOY)
  if (anyNA(m$period_start_UTC) || anyNA(m$period_end_exclusive_UTC) ||
      !identical(as.character(m$period_start_UTC), calendar$period_start_UTC) ||
      !identical(as.character(m$period_end_exclusive_UTC), calendar$period_end_exclusive_UTC) ||
      any(.wan_temp(m$n_days, "n_days") != calendar$n_days)) .wan_fail("Master windows differ from the annual MODIS calendar")
  r <- r[match(key, review_key), , drop = FALSE]
  .wan_cols(r, c("include", "open_water_ok", "quality_ok", "gap_filled_ok", "split",
                "open_water_basis", "quality_basis", "gap_fill_basis", "reviewer", "review_date"), "review")
  # If review retains calendar labels, reject a changed label rather than ignore it.
  for (nm in intersect(c("period_start_UTC", "period_end_exclusive_UTC"), names(r)))
    if (anyNA(r[[nm]]) || any(as.character(r[[nm]]) != m[[nm]])) .wan_fail("Review calendar differs from master: ", nm)
  include <- .wan_bool(r$include, "include", TRUE)
  water <- .wan_bool(r$open_water_ok, "open_water_ok", TRUE)
  quality <- .wan_bool(r$quality_ok, "quality_ok", TRUE)
  gap_ok <- .wan_bool(r$gap_filled_ok, "gap_filled_ok", TRUE)
  da <- .wan_bool(m$D_raw_available, "D_raw_available")
  na <- .wan_bool(m$N_raw_available, "N_raw_available")
  dg <- .wan_bool(m$D_gap_filled, "D_gap_filled")
  ng <- .wan_bool(m$N_gap_filled, "N_gap_filled")
  d_raw <- .wan_temp(m$D_raw_celsius, "D_raw_celsius"); n_raw <- .wan_temp(m$N_raw_celsius, "N_raw_celsius")
  d_fill <- .wan_temp(m$D_filled_celsius, "D_filled_celsius"); n_fill <- .wan_temp(m$N_filled_celsius, "N_filled_celsius")
  if (!identical(da, is.finite(d_raw)) || !identical(na, is.finite(n_raw)) ||
      !identical(dg, !da & is.finite(d_fill)) || !identical(ng, !na & is.finite(n_fill)))
    .wan_fail("Raw-availability/gap-origin flags are inconsistent with preserved source values")
  d <- .wan_temp(m[[paste0("D_", proxy, "_celsius")]], paste0("D_", proxy))
  n <- .wan_temp(m[[paste0("N_", proxy, "_celsius")]], paste0("N_", proxy))
  obs <- .wan_temp(m[[value_column]], value_column); expected <- (d + n) / 2
  if (!isTRUE(all.equal(obs, expected, tolerance = 1e-13, check.attributes = FALSE))) .wan_fail("DN proxy is not the preserved two-channel equal-weight mean")
  if (any(include & (!water | !quality | !is.finite(obs)))) .wan_fail("Included windows need explicit open-water/QC approval and two finite channels")
  gap <- !da | !na
  if (any(include & gap) && !allow_gap_filled) .wan_fail("Included records contain original raw gaps; explicit allow_gap_filled is required")
  if (any(include & gap & !gap_ok)) .wan_fail("Included original raw gaps also require per-record gap_filled_ok")
  nonblank <- function(x) !is.na(x) & nzchar(trimws(as.character(x)))
  for (nm in c("open_water_basis", "quality_basis", "reviewer", "review_date"))
    if (any(include & !nonblank(r[[nm]]))) .wan_fail("Included records need documented ", nm)
  dates <- as.character(r$review_date[include])
  parsed_dates <- suppressWarnings(as.Date(dates, format = "%Y-%m-%d"))
  if (any(!grepl("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", dates)) || anyNA(parsed_dates) ||
      any(format(parsed_dates, "%Y-%m-%d") != dates)) .wan_fail("Approved review_date must be a valid YYYY-MM-DD date")
  if (any(include & gap & !nonblank(r$gap_fill_basis))) .wan_fail("Included original raw gaps need documented gap_fill_basis")
  split <- trimws(as.character(r$split)); split[is.na(split)] <- ""
  if (any(!split %in% c("", "excluded", "calibration", "validation"))) .wan_fail("Unknown split label")
  if (any(include & !split %in% c("calibration", "validation"))) .wan_fail("Included records need calibration or validation split")
  assigned <- split %in% c("calibration", "validation")
  for (yr in unique(m$YEAR[assigned])) {
    labels <- unique(split[assigned & m$YEAR == yr])
    if (length(labels) != 1L) .wan_fail("Calibration/validation must be assigned to disjoint whole years; mixed YEAR=", yr)
  }
  out <- data.frame(window_id = sprintf("%04d_%03d", .wan_int(m$YEAR, "YEAR"), .wan_int(m$DOY, "DOY", max_value = 361)),
                     window_start = m$period_start_UTC, window_end = m$period_end_exclusive_UTC,
                     observed = obs, split = split, use = include, ice_free = water, qc_pass = quality,
                     Depth_meter = 0, NAME_ID = .wan_int(m$NAME_ID, "NAME_ID", max_value = .Machine$integer.max),
                     YEAR = .wan_int(m$YEAR, "YEAR"), DOY = .wan_int(m$DOY, "DOY", max_value = 361),
                     n_days = calendar$n_days, source_column = value_column, source_units = "celsius",
                     D_raw_available = da, N_raw_available = na, D_gap_filled = dg, N_gap_filled = ng,
                     uses_filtered_product = proxy == "filter", allow_gap_filled = allow_gap_filled,
                     stringsAsFactors = FALSE)
  for (nm in c("open_water_basis", "quality_basis", "gap_fill_basis", "reviewer", "review_date")) out[[nm]] <- r[[nm]]
  out <- out[include, , drop = FALSE]
  out <- out[order(out$window_start), , drop = FALSE]; rownames(out) <- NULL
  if (!is.null(output)) {
    manifest_output <- paste0(output, ".manifest.csv")
    if (file.exists(output) || file.exists(manifest_output)) .wan_fail("Refusing to overwrite window output/manifest")
    .wan_write_csv(out, output)
    checksum <- function(x) if (is.character(x)) unname(tools::md5sum(x)) else "in-memory data.frame; no file checksum"
    provenance <- data.frame(item = c("master_md5", "review_md5", "windows_md5", "proxy", "allow_gap_filled", "approved_records"),
                               value = c(checksum(master), checksum(review), unname(tools::md5sum(output)), proxy,
                                         as.character(allow_gap_filled), as.character(nrow(out))), stringsAsFactors = FALSE)
    .wan_write_csv(provenance, manifest_output)
  }
  out
}

# Optional command line; use R functions above from Windows R/RStudio.
wan_prepare_cli <- function(args = commandArgs(trailingOnly = TRUE)) {
  if (!length(args) || args[1L] %in% c("--help", "-h")) {
    cat("Rscript tools/prepare_wan_windows.R prepare DATA_DIR NAME_ID OUT_DIR celsius\n",
        "Rscript tools/prepare_wan_windows.R export MASTER REVIEW raw|filled|filter OUTPUT [allow-gap-filled]\n",
        "Preparation never approves records. Year splits and all review decisions remain external.\n", sep = "")
    return(invisible(NULL))
  }
  if (identical(args[1L], "prepare") && length(args) == 5L) {
    x <- wan_prepare_master(args[2L], args[3L], args[5L], args[4L])
    cat("Master records:", nrow(x$master), "; approved automatically: 0\n")
    return(invisible(x))
  }
  if (identical(args[1L], "export") && length(args) %in% c(5L, 6L)) {
    if (length(args) == 6L && args[6L] != "allow-gap-filled") .wan_fail("Unknown sixth argument")
    x <- wan_export_windows(args[2L], args[3L], args[4L], args[5L], length(args) == 6L)
    cat("Approved windows:", nrow(x), "\n")
    return(invisible(x))
  }
  .wan_fail("Invalid arguments; use --help")
}
if (sys.nframe() == 0L) wan_prepare_cli()
