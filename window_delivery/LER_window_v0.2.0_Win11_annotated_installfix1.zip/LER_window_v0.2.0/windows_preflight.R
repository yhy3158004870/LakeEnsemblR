# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Rscript windows_preflight.R --lib "D:/LER/library_v020" [--report "D:/LER/preflight_001"]
# Or source(..., encoding="UTF-8"); ler_windows_preflight(lib="D:/LER/library_v020")
.ler_preflight_script_file <- local({
  files <- unlist(lapply(sys.frames(), function(x) if (!is.null(x$ofile)) x$ofile else NULL), use.names = FALSE)
  if (length(files)) tail(files, 1L) else {
    args <- commandArgs(trailingOnly = FALSE); hit <- args[startsWith(args, "--file=")]
    if (length(hit)) sub("^--file=", "", hit[1L]) else "windows_preflight.R"
  }
})
.ler_preflight_bundle <- normalizePath(dirname(.ler_preflight_script_file), winslash = "/", mustWork = TRUE)
source(file.path(.ler_preflight_bundle, "tools", "windows_helpers.R"), local = TRUE, encoding = "UTF-8")

.ler_pe_machine <- function(path) {
  con <- file(path, "rb"); on.exit(close(con))
  if (!identical(readBin(con, "raw", n = 2L), charToRaw("MZ"))) return("invalid")
  seek(con, 60L, origin = "start")
  offset <- readBin(con, "integer", n = 1L, size = 4L, endian = "little", signed = TRUE)
  if (length(offset) != 1L || offset < 64L || offset > file.info(path)$size - 6L) return("invalid")
  seek(con, offset, origin = "start")
  if (!identical(readBin(con, "raw", n = 4L), as.raw(c(80L, 69L, 0L, 0L)))) return("invalid")
  code <- readBin(con, "integer", n = 1L, size = 2L, endian = "little", signed = FALSE)
  switch(as.character(code), "332" = "x86 (32 bit)", "34404" = "x64 (64 bit)", "43620" = "ARM64", "unknown")
}

ler_windows_preflight <- function(lib, bundle_dir = .ler_preflight_bundle, report_dir = NULL,
                                  run_numerical_tests = TRUE) {
  if (.Platform$OS.type != "windows") .ler_stop("预检用于 Win11 本机；Linux 结果不能证明 Windows 通过。")
  if (getRversion() < "4.1.0" || .Machine$sizeof.pointer != 8L) .ler_stop("需要 R >= 4.1 且为 64 位。")
  if (grepl("aarch64|arm64", R.version$arch, ignore.case = TRUE)) .ler_stop("Windows ARM64 尚未验收。")
  root <- .ler_path(bundle_dir); lib <- .ler_path(lib)
  manifest <- .ler_vendor_manifest(root)
  description <- .ler_read_description(file.path(root, "src", "LakeEnsemblR-window", "DESCRIPTION"))
  expected <- c(setNames(manifest$version, manifest$package), LakeEnsemblR = description$Version)
  existing <- installed.packages(lib.loc = lib)
  missing <- setdiff(names(expected), rownames(existing))
  if (length(missing)) .ler_stop("独立库缺少包: ", paste(missing, collapse = ", "))
  wrong <- names(expected)[existing[names(expected), "Version"] != expected]
  if (length(wrong)) .ler_stop("固定包版本不一致: ", paste(wrong, collapse = ", "))
  # Prevent an already-loaded old namespace from bypassing the requested library.
  for (p in intersect(loadedNamespaces(), rownames(existing))) {
    loaded_path <- .ler_path(getNamespaceInfo(asNamespace(p), "path"))
    if (!identical(tolower(loaded_path), tolower(.ler_path(file.path(lib, p)))))
      .ler_stop("当前 R 已加载其他库的 ", p, "，请重启 R 再运行预检。")
  }
  old_paths <- .libPaths(); .libPaths(c(lib, .Library), include.site = FALSE)
  on.exit(.libPaths(old_paths), add = TRUE)
  for (p in names(expected)) {
    tryCatch(loadNamespace(p, lib.loc = lib), error = function(e) .ler_stop("命名空间加载失败 ", p, ": ", conditionMessage(e)))
  }
  exports <- getNamespaceExports("LakeEnsemblR")
  need <- c("ler_window_control", "ler_modis_windows", "ler_window_predict", "cali_window_ensemble",
            "ler_window_probe", "evaluate_window_best", "calc_fit_window")
  if (!all(need %in% exports)) .ler_stop("安装包缺少窗口接口。")
  if (!"window" %in% names(formals(getExportedValue("LakeEnsemblR", "cali_ensemble"))))
    .ler_stop("cali_ensemble 不包含 window 分支。")
  executable_paths <- c(FLakeR = "extbin/win/flake.exe", GLM3r = "extbin/glm-3.0.5_x64/glm.exe",
                        GOTMr = "extbin/win64GOTM/gotm.exe", SimstratR = "extbin/win/simstrat_windows_301.exe")
  engines <- do.call(rbind, lapply(names(executable_paths), function(p) {
    path <- system.file(executable_paths[[p]], package = p, lib.loc = lib)
    if (!nzchar(path) || file.info(path)$size <= 0L) .ler_stop("缺少 Windows 模型可执行文件: ", p)
    machine <- .ler_pe_machine(path)
    if (!machine %in% c("x86 (32 bit)", "x64 (64 bit)")) .ler_stop("模型不是支持的 Windows x86/x64 PE: ", p)
    data.frame(package = p, wrapper_version = expected[[p]], executable = .ler_path(path),
               pe_machine = machine, sha256 = .ler_sha256(path), stringsAsFactors = FALSE)
  }))
  # MyLake is implemented in R; it has no external .exe to discover.
  if (!"run_mylake" %in% getNamespaceExports("MyLakeR")) .ler_stop("MyLakeR 缺少 run_mylake 导出。")
  for (p in names(expected)) {
    d <- .ler_read_description(file.path(lib, p, "DESCRIPTION"))
    dependencies <- .ler_dependencies(d)
    for (i in seq_len(nrow(dependencies))) {
      dep <- dependencies$package[i]
      version <- if (dep == "R") as.character(getRversion()) else {
        if (!requireNamespace(dep, quietly = TRUE)) .ler_stop("必需依赖不能加载: ", dep)
        as.character(packageVersion(dep))
      }
      if (!.ler_version_satisfies(version, dependencies$operator[i], dependencies$version[i]))
        .ler_stop("依赖最低版本不满足: ", p, " -> ", dep)
    }
  }
  if (is.null(report_dir)) report_dir <- file.path(lib, "_LER_install_records", paste0("preflight_", format(Sys.time(), "%Y%m%d_%H%M%S")))
  report_dir <- .ler_path(report_dir, must_work = FALSE)
  if (dir.exists(report_dir) && length(list.files(report_dir, all.files = TRUE, no.. = TRUE)))
    .ler_stop("报告目录非空，拒绝覆盖: ", report_dir)
  dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(report_dir) || file.access(report_dir, 2L) != 0L) .ler_stop("报告目录不可写。")
  write.csv(engines, file.path(report_dir, "windows-engines.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  writeLines(capture.output(sessionInfo()), file.path(report_dir, "sessionInfo.txt"), useBytes = TRUE)
  numerical_result <- "not run"
  if (isTRUE(run_numerical_tests)) {
    env <- new.env(parent = globalenv())
    failure <- NULL
    old_working_directory <- getwd(); setwd(root)
    on.exit(setwd(old_working_directory), add = TRUE)
    output <- capture.output(tryCatch({
      source(file.path(root, "tests", "run_tests.R"), local = env, keep.source = TRUE, encoding = "UTF-8")
    }, error = function(e) { failure <<- conditionMessage(e); cat("FAIL: ", failure, "\n", sep = "") }))
    writeLines(output, file.path(report_dir, "numerical-tests.txt"), useBytes = TRUE)
    if (!is.null(failure)) .ler_stop("数值测试失败: ", failure, "。日志: ", report_dir)
    numerical_result <- "passed"
  }
  text <- c("预检通过：固定包版本、命名空间、窗口接口、Windows PE 文件和最低依赖。",
            paste0("数值测试: ", numerical_result),
            "此预检没有执行模型物理求解，不能证明运行时 DLL、用户项目和模型时间语义均正确。",
            "GLM3r 的包版本不是求解器版本；本固定 Windows wrapper 使用 glm-3.0.5_x64/glm.exe。",
            "现代 Windows R 的 r_arch 可能为空；窗口分支直接调用已审计的 PE 路径，原非窗口接口保留官方 wrapper 行为。",
            "随后必须完成参考项目/真实项目五模型小试、输出语义确认、同参数串并行核对与最佳参数重跑。",
            "安装器支持空格/中文路径；第三方 Fortran 引擎的项目路径建议使用简单 ASCII，如 D:/LER/projects/NamCo。",
            "不需要 GitHub token；归档使用固定提交并核验 SHA256，不会关闭 TLS。")
  writeLines(text, file.path(report_dir, "preflight-summary.txt"), useBytes = TRUE)
  cat(paste(text, collapse = "\n"), "\n报告: ", report_dir, "\n", sep = "")
  invisible(list(lib = lib, engines = engines, numerical_tests = numerical_result, report_dir = report_dir))
}

.ler_preflight_cli <- commandArgs(trailingOnly = FALSE)
.ler_preflight_is_cli <- any(startsWith(.ler_preflight_cli, "--file=")) &&
  identical(normalizePath(sub("^--file=", "", .ler_preflight_cli[startsWith(.ler_preflight_cli, "--file=")][1L]),
                          winslash = "/", mustWork = FALSE), normalizePath(.ler_preflight_script_file, winslash = "/", mustWork = FALSE)) &&
  !length(unlist(lapply(sys.frames(), function(x) if (!is.null(x$ofile)) x$ofile else NULL)))
if (.ler_preflight_is_cli) {
  args <- .ler_cli_options(commandArgs(trailingOnly = TRUE))
  if (isTRUE(args$help)) cat("Rscript windows_preflight.R --lib D:/LER/library_v020 [--bundle PATH] [--report PATH]\n") else {
    if (is.null(args$lib)) .ler_stop("请指定 --lib 独立安装库。")
    if (any(c("offline", "allow-source-cran", "cran", "cran-cache") %in% names(args))) .ler_stop("预检不接受安装器的网络选项。")
    ler_windows_preflight(lib = args$lib, bundle_dir = if (is.null(args$bundle)) .ler_preflight_bundle else args$bundle,
                          report_dir = args$report)
  }
}
