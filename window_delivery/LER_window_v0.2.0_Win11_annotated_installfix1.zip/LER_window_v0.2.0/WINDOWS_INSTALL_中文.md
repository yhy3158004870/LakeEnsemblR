# Windows 11 安装、配置与本机验收

本交付的 R 包版本为 **1.2.9.9002**，窗口扩展版本为 **0.2.0**。它是 LakeEnsemblR 的派生版本，不是官方发布。随包提供完整派生源码、可安装源码归档和固定 GitHub 提交的模型依赖源归档。

本次开发机器为 Linux。Windows 安装脚本已经过真实 R 的解析及跨平台辅助逻辑检查，但不能据此声称已在 Win11 上完成安装、运行或结果验收。正式研究前必须在自己的 Win11 机器完成本文末尾的模型验收。

## 1. 安装条件

- Windows 11 x64、64 位 R >= 4.1。建议使用当前有 CRAN Windows 二进制包支持的 R 版本。Windows ARM64/x64 模拟层尚未验证。
- 首次安装默认需要联网，获取 CRAN Windows 二进制依赖。GitHub 模型依赖已经随包提供，不需要 Git、GitHub 登录或 token。
- 默认不需要 Rtools：固定模型 wrapper 为 R 源码加预编译模型，不是安装时重新编译 Fortran 求解器。仅在明确允许 CRAN 源包回退且所需包确需编译时才检测 Rtools。
- 用新的空 R 库。安装器拒绝覆盖非空库、不会升级你的旧库。若安装失败，保留该库及输出用于诊断，再选择新的空库重试。

解压至例如 `D:/LER/bundle_v020`。安装器支持空格和 Unicode 路径；为兼容第三方 Fortran 程序，模型项目目录建议使用简短 ASCII 路径，例如 `D:/LER/projects/NamCo`。不要在 ZIP 内直接运行脚本。

## 2. 在 R 或 RStudio 安装

先开启新的 R 会话，然后运行（按实际路径修改）：

```r
source("D:/LER/bundle_v020/install_windows.R", encoding = "UTF-8")
result <- ler_install_windows(
  lib = "D:/LER/library_v020",
  cran = "https://cloud.r-project.org"
)
```

脚本会校验随包源归档的 SHA256、包名和版本，准备 CRAN 依赖，按依赖顺序安装，再记录依赖版本、R 会话信息和激活脚本。任何必需依赖失败都会停止，不用跳过失败来继续率定。

主包安装使用 `src/LakeEnsemblR_1.2.9.9002.tar.gz`，完整可读源码在 `src/LakeEnsemblR-window`。用户安装随包完整版时无需另跑 `apply_patch.R`，也不要在已经修改的源码上重复打补丁。

安装完成后，**重启 R**，再运行：

```r
.libPaths(c("D:/LER/library_v020", .libPaths()))
library(LakeEnsemblR)
stopifnot(as.character(packageVersion("LakeEnsemblR")) == "1.2.9.9002")
source("D:/LER/bundle_v020/windows_preflight.R", encoding = "UTF-8")
check <- ler_windows_preflight(
  lib = "D:/LER/library_v020",
  report_dir = "D:/LER/preflight_001"
)
```

报告目录必须为空或不存在。预检核对固定包版本、加载位置、接口、最低依赖、Windows PE 可执行文件，并执行窗口数值测试。报告包含 `windows-engines.csv`、`sessionInfo.txt`、`numerical-tests.txt`。预检不启动物理模型，不替代模型运行验收。

## 3. 命令行安装

在命令提示符或 PowerShell 中调用当前 R 安装的 `Rscript.exe`。以下为命令提示符示例，R 路径按实际版本修改：

```bat
"C:\Program Files\R\R-current\bin\Rscript.exe" "D:\LER\bundle_v020\install_windows.R" --lib "D:\LER\library_v020"
"C:\Program Files\R\R-current\bin\Rscript.exe" "D:\LER\bundle_v020\windows_preflight.R" --lib "D:\LER\library_v020" --report "D:\LER\preflight_001"
```

`R-current` 是示例占位符。PowerShell 需在带引号的可执行文件路径前添加调用符 `&`。脚本不依赖当前工作目录，也可以用 `--bundle` 明确指定代码包根目录。

## 4. CRAN 二进制不可用和离线安装

默认安装器不会将缺失二进制悄悄改为源包。先核实网络、HTTPS 镜像与当前 R 主次版本是否仍受 CRAN 支持。确需源包时显式运行：

```r
ler_install_windows(lib = "D:/LER/library_v020_source", allow_source_cran = TRUE)
```

只有需要编译的源包才检测 Rtools。Rtools 必须与所用 R 版本匹配；脚本使用 `pkgbuild::has_build_tools()` 检查实际工具链。它不会自动关闭 TLS、包校验或篡改期望摘要。

联网安装会在 `vendor/windows-cran-cache/R-主.次` 中保存下载的二进制包、依赖数据库与 SHA256 清单。离线安装必须已有**完整且与当前 R 主次版本兼容**的缓存：

```r
ler_install_windows(
  lib = "D:/LER/library_v020_offline",
  offline = TRUE,
  cran_cache = "D:/LER/bundle_v020/vendor/windows-cran-cache/R-主.次"
)
```

缺归档、依赖、摘要或兼容版本会直接停止；离线模式不会自行联网。本 ZIP 没有冒充包含所有未来 R 版本的 CRAN 二进制。CRAN 普通依赖初次安装采用当时可用的兼容版本，安装后记录真实版本并缓存归档；固定 GitHub 模型源码则从交付时起由提交 SHA 和归档 SHA256 固定。

## 5. 五模型与科研验收

预检通过后，按主 README 的顺序完成：输入配置及窗口审核、五模型 `ler_window_probe()`、原生输出时间/表层语义确认、同一参数表的串并行核对、最优参数重跑和分开的率定/验证评价。不要将模板中未批准的窗口直接作为正式观测。

四个外部求解器的 Windows 可执行文件路径由固定依赖提供；MyLake 为 R 实现，没有额外 `.exe`。特别注意：**GLM3r wrapper 包版本 3.1.17 不代表 Windows 求解器也是 3.1.17**；该固定版本在 Windows 使用 `extbin/glm-3.0.5_x64/glm.exe`。报告记录实际可执行文件摘要。不同平台的引擎、动态库或输出步长可能不同，应重新确认输出契约，不应直接宣称与 Linux 的模型结果完全一致。

现代 Windows R 的 `.Platform$r_arch` 可能为空。新增窗口分支通过明确的 Windows PE 路径调用求解器；原非窗口接口保留上游行为，其旧 wrapper 是否兼容你的 R 版本仍需要本机检查。

安装/预检通过不能证明观测的冰期、晴空采样、滤波、表面皮肤温度或初始剖面处理正确。科研使用还需要真实项目验收、参数先验说明、搜索稳定性、独立评价以及完整保存配置、观测审核和依赖版本。
