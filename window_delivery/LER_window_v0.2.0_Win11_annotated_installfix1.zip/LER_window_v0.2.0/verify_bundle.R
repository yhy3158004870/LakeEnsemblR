# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# source("D:/LER_window_v0.2.0/verify_bundle.R", encoding="UTF-8")
# ler_verify_bundle("D:/LER_window_v0.2.0")
.ler_verify_source <- local({
  paths <- unlist(lapply(sys.frames(),function(x)if(!is.null(x$ofile))x$ofile else NULL))
  if(length(paths))tail(paths,1L) else {
    args<-commandArgs(FALSE);a<-args[startsWith(args,"--file=")]
    if(length(a))sub("^--file=","",a[1L]) else "verify_bundle.R"
  }
})
.ler_verify_root <- normalizePath(dirname(.ler_verify_source),winslash="/",mustWork=TRUE)
source(file.path(.ler_verify_root,"tools","windows_helpers.R"),local=TRUE,encoding="UTF-8")
ler_verify_bundle <- function(bundle_dir=.ler_verify_root) {
  root <- .ler_path(bundle_dir)
  rows <- readLines(file.path(root,"SHA256SUMS.txt"),encoding="UTF-8",warn=FALSE)
  if(!length(rows)||any(!grepl("^[[:xdigit:]]{64}  .+$",rows)))stop("Invalid SHA256SUMS")
  names <- substring(rows,67L)
  if(anyDuplicated(names))stop("Duplicate checksum paths")
  for(i in seq_along(rows))
    .ler_verify_file(.ler_relative_file(root,names[i]),substring(rows[i],1L,64L))
  message("PASS: ",length(rows)," release files match SHA256SUMS")
  invisible(TRUE)
}
