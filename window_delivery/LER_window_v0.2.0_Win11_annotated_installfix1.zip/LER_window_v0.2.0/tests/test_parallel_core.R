# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Numerical-only PSOCK determinism; DOES NOT run any physical lake model.
# Run from the bundle root: Rscript tests/test_parallel_core.R
local({
path <- normalizePath("R/window_calibration.R", winslash="/")
source(path, local=TRUE, encoding="UTF-8")
sp <- data.frame(name="p",type="model",lower=0,upper=2,initial=1,log=FALSE)
p <- .lw_lhc(sp,20,42)
a <- .lw_utc("2001-01-01 00:00:00")
w <- data.frame(window_id=c("a","b"),window_start=a+c(0,8)*86400,
  window_end=a+c(8,16)*86400,observed=c(1,2))
contract <- data.frame(model="Simstrat",method="sample_mean",step_seconds=10800,
  phase_seconds=0,label_position="point",timestamp_shift_seconds=0,
  temperature_column="wtr_0",confirmed=TRUE,meaning="synthetic test")
run <- function(i,p,w,contract,a) {
  s <- data.frame(datetime=a+seq(0,16*86400-10800,10800),
    temperature=p$p[i]+rep(c(0,1),each=64))
  calc_fit_window(s,w,contract)$metrics$RMSE
}
s <- vapply(seq_len(nrow(p)),run,numeric(1),p=p,w=w,contract=contract,a=a)
cl <- parallel::makePSOCKcluster(2)
on.exit(parallel::stopCluster(cl), add=TRUE)
parallel::clusterCall(cl,function(path) source(path,encoding="UTF-8"),path)
x <- parallel::parLapply(cl=cl,X=seq_len(nrow(p)),fun=run,p=p,w=w,contract=contract,a=a)
stopifnot(identical(s,unlist(x)))
cat("PASS: identical parameter table -> identical serial/PSOCK synthetic scores\n")
})
