# [LER-WINDOW NEW SUPPORT FILE] Regression for localized certutil output.
# Uses the real helper with mocked external command output, not a Win11 engine test.
local({
  fixture <- tempfile("sha256-fixture-")
  writeBin(charToRaw("abc"), fixture)
  on.exit(unlink(fixture), add=TRUE)
  expected <- "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
  env <- new.env(parent=globalenv())
  sys.source("tools/windows_helpers.R",envir=env)
  env$requireNamespace <- function(...) FALSE
  env$.Platform <- list(OS.type="windows")
  env$Sys.which <- function(x) setNames(rep("certutil",length(x)),x)
  output <- character()
  env$system2 <- function(...) output
  invalid_header <- rawToChar(c(charToRaw("SHA256 "),as.raw(c(0xb5,0xc4)),
    charToRaw(" fixture "),as.raw(c(0xb9,0xfe,0xcf,0xa3)),charToRaw(":")))
  Encoding(invalid_header) <- "UTF-8"
  n <- 0L
  ok <- function(label,value) {
    stopifnot(isTRUE(value));n<<-n+1L
    cat(sprintf("PASS S%02d: %s\n",n,label))
  }
  fail <- function(x) inherits(tryCatch(force(x),error=identity),"error")
  output <- c(invalid_header,expected,invalid_header)
  ok("invalid UTF-8 Chinese headings are ignored bytewise",identical(env$.ler_sha256(fixture),expected))
  output <- c("SHA256 hash:",toupper(expected),"CertUtil: completed")
  ok("uppercase digest is normalized",identical(env$.ler_sha256(fixture),expected))
  output <- c(invalid_header,paste(strsplit(expected,"",fixed=TRUE)[[1L]],collapse=" "))
  ok("ASCII space-separated hash remains supported",identical(env$.ler_sha256(fixture),expected))
  output <- c(invalid_header,paste0("\t",expected,"\r"))
  ok("ASCII tab and carriage return are supported",identical(env$.ler_sha256(fixture),expected))
  output <- c(expected,expected)
  ok("multiple hashes are rejected",fail(env$.ler_sha256(fixture)))
  output <- paste0("prefix",expected)
  ok("prefixed hash is rejected",fail(env$.ler_sha256(fixture)))
  output <- substring(expected,1L,63L)
  ok("short hash is rejected",fail(env$.ler_sha256(fixture)))
  output <- paste0(expected,"0")
  ok("long hash is rejected",fail(env$.ler_sha256(fixture)))
  output <- invalid_header
  ok("output without a hash is rejected",fail(env$.ler_sha256(fixture)))
  output <- expected;attr(output,"status") <- 1L
  ok("nonzero exit with a valid-looking hash is rejected",fail(env$.ler_sha256(fixture)))
  output <- expected
  ok("real archive mismatch is rejected",fail(env$.ler_verify_file(fixture,paste(rep("0",64L),collapse=""))))
  env$.Platform <- list(OS.type="unix")
  output <- paste(expected,invalid_header)
  ok("non-Windows filename bytes do not affect ASCII hash",identical(env$.ler_sha256(fixture),expected))
  cat("All",n,"SHA256 encoding and rejection checks passed.\n")
})
