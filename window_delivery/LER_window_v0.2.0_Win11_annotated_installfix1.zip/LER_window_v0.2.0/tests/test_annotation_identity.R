# [LER-WINDOW NEW SUPPORT FILE] Annotation-only equivalence against frozen v0.2.0.
args <- commandArgs(trailingOnly=TRUE)
if (length(args)!=2L) stop("Usage: Rscript test_annotation_identity.R BASELINE ANNOTATED")
base <- normalizePath(args[1L],winslash="/",mustWork=TRUE)
new <- normalizePath(args[2L],winslash="/",mustWork=TRUE)
files <- list.files(base,"[.][Rr]$",recursive=TRUE,all.files=TRUE)
files <- setdiff(files,"apply_patch.R") # Generator intentionally calls annotation helper.
for (p in files) {
  a<-parse(file.path(base,p),keep.source=FALSE)
  b<-parse(file.path(new,p),keep.source=FALSE)
  if (!identical(a,b)) stop("Executable expression changed: ",p)
}
cat("PASS:",length(files),"baseline R scripts have identical executable expressions\n")
pkg <- "src/LakeEnsemblR-window"
a<-parse(file.path(base,pkg,"NAMESPACE"),keep.source=FALSE)
b<-parse(file.path(new,pkg,"NAMESPACE"),keep.source=FALSE)
stopifnot(identical(a,b))
cat("PASS: NAMESPACE executable directives unchanged\n")
a<-read.dcf(file.path(base,pkg,"DESCRIPTION"))
b<-read.dcf(file.path(new,pkg,"DESCRIPTION"))
stopifnot(identical(setdiff(colnames(b),colnames(a)),"X-LER-Modification"),
          identical(a,b[,colnames(a),drop=FALSE]))
cat("PASS: DESCRIPTION changes only add legal annotation metadata\n")
for (p in c("man/cali_ensemble.Rd","man/window_calibration.Rd")) {
  a<-capture.output(tools::Rd2txt(tools::parse_Rd(file.path(base,pkg,p))))
  b<-capture.output(tools::Rd2txt(tools::parse_Rd(file.path(new,pkg,p))))
  stopifnot(identical(a,b))
}
cat("PASS: Rd visible contents unchanged\n")
models<-list.files(file.path(base,"vendor"),"[.]tar[.]gz$")
for (p in models)
  stopifnot(identical(unname(tools::md5sum(file.path(base,"vendor",p))),
                      unname(tools::md5sum(file.path(new,"vendor",p)))))
cat("PASS: all nine supplied dependency archives unchanged\n")
