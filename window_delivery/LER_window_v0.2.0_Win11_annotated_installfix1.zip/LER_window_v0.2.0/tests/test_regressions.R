# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Regression checks for defects identified in the v0.1.0 review.
# Run from the bundle root, after installing the documented R dependencies:
#   Rscript tests/test_regressions.R
# These checks DO NOT simulate a lake, validate Wan observations or establish
# that Windows model binaries work. The FLake output is a synthetic fixture.
local({
  core_path <- normalizePath("R/window_calibration.R", winslash = "/", mustWork = TRUE)
  source(core_path, local = TRUE, encoding = "UTF-8")
  required <- c("configr", "yaml", "digest", "gotmtools", "glmtools", "LakeEnsemblR")
  absent <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
  if (length(absent)) stop("Regression prerequisites are missing: ",
                          paste(absent, collapse = ", "), call. = FALSE)
  ntest <- 0L
  ok <- function(name, value) {
    if (!isTRUE(force(value))) stop("FAIL: ", name, call. = FALSE)
    ntest <<- ntest + 1L
    cat(sprintf("PASS R%02d: %s\n", ntest, name))
  }
  err <- function(expr) inherits(tryCatch(force(expr), error = identity), "error")
  near <- function(a, b) isTRUE(all.equal(as.numeric(a), as.numeric(b), tolerance = 1e-12))
  root <- tempfile("ler-regressions-")
  dir.create(root)
  on.exit(unlink(root, recursive = TRUE), add = TRUE)

  # A real YAML parser and the limited upstream text reader are checked
  # separately. Special paths must be made safe in the snapshot for gotmtools.
  cfg <- list(
    location = list(name = "test lake", depth = 12.5),
    time = list(start = "2010-01-01 06:00:00", stop = "2010-01-02 06:00:00"),
    input = list(init_temp_profile = list(file = "_inputs/0001.csv"),
      meteo = list(file = "_inputs/0002.csv"), ice = list(use = TRUE)),
    observations = list(temperature = list(file = NULL)),
    inflows = list(use = FALSE, file = "NULL"),
    output = list(depths = 0.5, variables = c("temp", "ice_height")),
    scaling_factors = list(all = list(inflow = c(1, 1.25))),
    model_parameters = list(Simstrat = NULL),
    calibration = list(GOTM = list("turb_param/k_min" =
      list(lower = 5e-6, upper = 5e-4, initial = 1e-5, log = TRUE))),
    extra = list(special_path = "D:\\lake files\\temperature #1:raw.csv",
      escaped_text = "quote \"here\", slash \\ and newline\nnext line",
      looks_boolean = "no", looks_numeric = "001", literal_null = "NULL"))
  yaml_file <- file.path(root, "roundtrip.yaml")
  .lw_write_config(cfg, yaml_file)
  back <- .lw_read_config(yaml_file)
  text <- readLines(yaml_file, warn = FALSE, encoding = "UTF-8")
  ok("YAML first-level map uses three-space indentation",
     any(grepl("^   depth:", text)) && !any(grepl("^  depth:", text)))
  ok("YAML logical scalars use true/false spelling",
     any(grepl("^[ ]+use: true$", text)) && any(grepl("^[ ]+use: false$", text)))
  ok("YAML scalar values roundtrip without numeric/boolean coercion",
     near(back$location$depth, cfg$location$depth) &&
       identical(back$extra$looks_boolean, "no") &&
       identical(back$extra$looks_numeric, "001") &&
       identical(back$extra$literal_null, "NULL"))
  ok("YAML special Windows path and escaped string roundtrip",
     identical(back$extra$special_path, cfg$extra$special_path) &&
       identical(back$extra$escaped_text, cfg$extra$escaped_text))
  ok("YAML absent file is the LER NULL sentinel; ordinary NULL remains NULL",
     identical(back$observations$temperature$file, "NULL") &&
       is.null(back$model_parameters$Simstrat))
  ok("YAML numeric sequence and slash-key calibration roundtrip",
     near(unlist(back$scaling_factors$all$inflow), c(1, 1.25)) &&
       near(back$calibration$GOTM[["turb_param/k_min"]]$initial, 1e-5) &&
       isTRUE(back$calibration$GOTM[["turb_param/k_min"]]$log))
  get_yaml <- gotmtools::get_yaml_value
  ok("gotmtools reads a three-space numeric scalar",
     near(get_yaml(yaml_file, "location", "depth"), 12.5))
  ok("gotmtools reads true/false scalars as logical values",
     identical(get_yaml(yaml_file, "ice", "use"), TRUE) &&
       identical(get_yaml(yaml_file, "inflows", "use"), FALSE))
  ok("gotmtools reads NULL file sentinel and safe relative paths",
     identical(get_yaml(yaml_file, "temperature", "file"), "NULL") &&
       identical(get_yaml(yaml_file, "meteo", "file"), "_inputs/0002.csv"))
  ok("gotmtools reads numeric/character YAML sequences",
     near(get_yaml(yaml_file, "all", "inflow"), c(1, 1.25)) &&
       identical(get_yaml(yaml_file, "output", "variables"), c("temp", "ice_height")))
  ok("gotmtools preserves the timestamp scalar",
     identical(get_yaml(yaml_file, "time", "start"), "2010-01-01 06:00:00"))

  # The limited gotmtools reader cannot parse every otherwise valid YAML path.
  # Snapshotting must copy such inputs to safe names without losing bytes or
  # deleting optional file=NULL fields through R's [[<-NULL behavior.
  project <- file.path(root, "project with spaces #1")
  dir.create(file.path(project, "FLake"), recursive = TRUE)
  paths <- c("lake bathymetry #1.csv", "initial profile #1.csv", "met forcing #1.csv")
  for (i in seq_along(paths)) writeLines(paste("known source input", i), file.path(project, paths[i]))
  writeLines(c("&LAKE_PARAMS", "depth_w_lk = 10,", "/"),
             file.path(project, "FLake", "flake.nml"))
  snapshot_cfg <- list(location = list(name = "test", hypsograph = paths[1]),
    time = cfg$time, input = list(init_temp_profile = list(file = paths[2]),
      meteo = list(file = paths[3])), output = list(depths = 1),
    config_files = list(FLake = "FLake/flake.nml"),
    observations = list(ice_height = list(file = NULL)))
  .lw_write_config(snapshot_cfg, file.path(project, "case.yaml"))
  snapshot <- file.path(root, "snapshot")
  snapshot_back <- .lw_snapshot(project, "case.yaml", snapshot, "FLake")
  copied <- c(snapshot_back$location$hypsograph,
              snapshot_back$input$init_temp_profile$file, snapshot_back$input$meteo$file)
  ok("snapshot replaces special input names by gotmtools-safe relative paths",
     length(copied) == 3 && all(grepl("^[A-Za-z0-9_./-]+$", copied)) &&
       all(file.exists(file.path(snapshot, copied))))
  source_hash <- vapply(file.path(project, paths), digest::digest, character(1),
                       file = TRUE, algo = "sha256")
  copied_hash <- vapply(file.path(snapshot, copied), digest::digest, character(1),
                       file = TRUE, algo = "sha256")
  ok("snapshot special-name input copies preserve SHA256 byte checksums",
     identical(unname(source_hash), unname(copied_hash)))
  snapshot_disk <- .lw_read_config(file.path(snapshot, "case.yaml"))
  ok("snapshot retains an optional absent file as the LER NULL sentinel",
     identical(snapshot_disk$observations$ice_height$file, "NULL"))
  ok("gotmtools can read the renamed snapshot input path",
     identical(get_yaml(file.path(snapshot, "case.yaml"), "meteo", "file"), copied[3]))
  manifest <- .lw_file_manifest(snapshot)
  ok("unchanged snapshot passes the complete file manifest check",
     isTRUE(.lw_check_manifest(snapshot, manifest, "test snapshot")))
  altered_file <- file.path(snapshot, copied[3])
  original_bytes <- readBin(altered_file, "raw", n = file.info(altered_file)$size)
  changed_bytes <- original_bytes
  changed_bytes[1] <- as.raw(88L)
  writeBin(changed_bytes, altered_file)
  tampered <- err(.lw_check_manifest(snapshot, manifest, "test snapshot"))
  writeBin(original_bytes, altered_file)
  ok("same-size snapshot input edit is rejected by SHA256 verification", tampered)
  added_file <- file.path(snapshot, "unexpected-file.txt")
  writeLines("unexpected extra snapshot file", added_file)
  added <- err(.lw_check_manifest(snapshot, manifest, "test snapshot"))
  unlink(added_file)
  ok("unrecorded snapshot file is rejected by manifest verification", added)

  # Internal serialization state may change without a change in the program.
  csv_fun <- .lw_write_csv
  before <- .lw_function_hash(csv_fun)
  csv_fun(data.frame(x = c(1, NA_real_), text = c("a", "b")),
          file.path(root, "numeric.csv"))
  ok("function fingerprint is stable after the function is called",
     identical(before, .lw_function_hash(csv_fun)))
  ok("function fingerprint is stable after byte-code compilation",
     identical(before, .lw_function_hash(compiler::cmpfun(csv_fun))))
  reloaded <- eval(parse(text = deparse(csv_fun, width.cutoff = 500L), keep.source = TRUE))
  ok("source-reference metadata does not change the fingerprint",
     identical(before, .lw_function_hash(reloaded)))
  changed_body <- csv_fun
  body(changed_body) <- quote(stop("intentionally changed for the regression test"))
  ok("body change is detected by the fingerprint",
     !identical(before, .lw_function_hash(changed_body)))
  changed_formals <- csv_fun
  formals(changed_formals)$path <- "intentionally changed default"
  ok("formal-argument change is detected by the fingerprint",
     !identical(before, .lw_function_hash(changed_formals)))

  # Candidate RNG control must leave the caller unchanged, including on errors.
  old_kind <- RNGkind()
  had_seed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_seed) old_seed <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    do.call(RNGkind, as.list(old_kind))
    if (had_seed) assign(".Random.seed", old_seed, envir = .GlobalEnv)
    else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
      rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  set.seed(123L)
  caller_seed <- get(".Random.seed", envir = .GlobalEnv)
  candidate_seed <- .lw_seed(42L, "MyLake", "p0000001")
  ok("candidate seed is a valid stable R integer",
     length(candidate_seed) == 1L && is.finite(candidate_seed) &&
       candidate_seed >= 1 && candidate_seed <= .Machine$integer.max &&
       candidate_seed == floor(candidate_seed) &&
       identical(candidate_seed, .lw_seed(42L, "MyLake", "p0000001")))
  ok("candidate seed distinguishes model and parameter identifier",
     candidate_seed != .lw_seed(42L, "GLM", "p0000001") &&
       candidate_seed != .lw_seed(42L, "MyLake", "p0000002"))
  draw <- .lw_with_seed(candidate_seed, stats::runif(8))
  ok("candidate RNG draws repeat and restore caller seed",
     identical(draw, .lw_with_seed(candidate_seed, stats::runif(8))) &&
       identical(caller_seed, get(".Random.seed", envir = .GlobalEnv)))
  saved_kind <- RNGkind()
  thrown <- err(.lw_with_seed(candidate_seed, {
    stats::runif(3)
    stop("intentional RNG-cleanup test error")
  }))
  ok("candidate RNG restores caller state when execution fails",
     thrown && identical(caller_seed, get(".Random.seed", envir = .GlobalEnv)) &&
       identical(saved_kind, RNGkind()))
  rm(".Random.seed", envir = .GlobalEnv)
  .lw_with_seed(candidate_seed, stats::runif(1))
  ok("candidate RNG does not create a persistent seed when caller had none",
     !exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))

  # MyLakeR writes and removes global variables as part of its upstream runner.
  # The extension must restore pre-existing user objects, including on errors.
  global_names <- c("g", "Wt")
  prior_names <- global_names[vapply(global_names, exists, logical(1),
                                    envir = .GlobalEnv, inherits = FALSE)]
  prior_objects <- mget(prior_names, envir = .GlobalEnv, inherits = FALSE)
  on.exit({
    present <- global_names[vapply(global_names, exists, logical(1),
                                   envir = .GlobalEnv, inherits = FALSE)]
    if (length(present)) rm(list = present, envir = .GlobalEnv)
    for (name in prior_names) assign(name, prior_objects[[name]], envir = .GlobalEnv)
  }, add = TRUE)
  if (exists("Wt", envir = .GlobalEnv, inherits = FALSE)) rm("Wt", envir = .GlobalEnv)
  assign("g", list(marker = "preexisting caller object"), envir = .GlobalEnv)
  global_value <- get("g", envir = .GlobalEnv)
  returned <- .lw_mylake_globals({
    assign("g", 9.8, envir = .GlobalEnv)
    assign("Wt", matrix(1), envir = .GlobalEnv)
    "successful result"
  })
  ok("MyLake global guard restores old objects and removes introduced objects",
     identical(returned, "successful result") &&
       identical(get("g", envir = .GlobalEnv), global_value) &&
       !exists("Wt", envir = .GlobalEnv, inherits = FALSE))
  thrown <- err(.lw_mylake_globals({
    rm("g", envir = .GlobalEnv)
    assign("Wt", matrix(1), envir = .GlobalEnv)
    stop("intentional global-cleanup test error")
  }))
  ok("MyLake global guard restores caller objects after an error",
     thrown && identical(get("g", envir = .GlobalEnv), global_value) &&
       !exists("Wt", envir = .GlobalEnv, inherits = FALSE))

  # Real PSOCK processes initialize package data; no physical engine is run.
  cluster <- parallel::makePSOCKcluster(2L)
  on.exit(parallel::stopCluster(cluster), add = TRUE)
  checks <- parallel::clusterCall(cluster, function(path, lib_paths) {
    .libPaths(lib_paths)
    source(path, encoding = "UTF-8")
    .lw_initialize_runtime(lib_paths)
    list(attached = "package:LakeEnsemblR" %in% search(),
      lake_dictionary = exists("lake_var_dic", inherits = TRUE),
      met_dictionary = exists("met_var_dic", inherits = TRUE))
  }, core_path, .libPaths())
  ok("PSOCK runtime attaches LER and exposes both lazy-data dictionaries",
     all(vapply(checks, function(check) all(unlist(check)), logical(1))))
  tasks <- data.frame(model = rep(c("MyLake", "GLM"), each = 8),
    par_id = rep(sprintf("p%07d", 1:8), 2), stringsAsFactors = FALSE)
  candidate_draw <- function(index, tasks, seed) {
    s <- .lw_seed(seed, tasks$model[index], tasks$par_id[index])
    .lw_with_seed(s, stats::runif(10))
  }
  serial <- lapply(seq_len(nrow(tasks)), candidate_draw, tasks = tasks, seed = 42L)
  schedule <- rev(seq_len(nrow(tasks)))
  psock <- parallel::parLapply(cl = cluster, X = schedule, fun = candidate_draw,
                               tasks = tasks, seed = 42L)
  psock <- psock[match(seq_len(nrow(tasks)), schedule)]
  ok("candidate RNG is identical in serial/PSOCK despite reversed scheduling",
     identical(serial, psock))

  # A known-time, known-temperature reader fixture, not a lake simulation.
  fixture <- function(name, native_step, start, stop, met_start) {
    project <- file.path(root, name)
    dir.create(file.path(project, "FLake", "output"), recursive = TRUE)
    times <- seq(.lw_utc(met_start),
                 .lw_utc(met_start) + as.numeric(difftime(.lw_utc(stop), .lw_utc(start), units = "secs")),
                 by = native_step)
    utils::write.table(data.frame(dummy = 1, datetime = .lw_fmt(times)),
      file.path(project, "FLake", "met.dat"), sep = "\t", quote = FALSE,
      row.names = FALSE, col.names = FALSE)
    writeLines(c("&SIMULATION_PARAMS", paste0("del_time_lk = ", native_step, ","), "/",
      "&METEO", "meteofile = 'met.dat',", "/", "&LAKE_PARAMS", "depth_w_lk = 10,", "/"),
      file.path(project, "FLake", "flake.nml"))
    out <- file.path(project, "FLake", "output", "output.dat")
    writeLines(c("# synthetic reader fixture, not a physical simulation", "Ts Tb h_ML C_T"), out)
    utils::write.table(data.frame(Ts = seq_along(times) + 10, Tb = 5,
      h_ML = 5, C_T = 0.5), out, append = TRUE, quote = FALSE,
      row.names = FALSE, col.names = FALSE)
    minimal <- list(time = list(start = start, stop = stop),
      config_files = list(FLake = "FLake/flake.nml"), output = list(depths = 1))
    .lw_write_config(minimal, file.path(project, "case.yaml"))
    contract <- data.frame(model = "FLake", method = "sample_mean",
      step_seconds = native_step, phase_seconds = 0, label_position = "point",
      timestamp_shift_seconds = 0, temperature_column = "wtr_0", confirmed = FALSE,
      meaning = "synthetic reader-only known timestamp fixture", stringsAsFactors = FALSE)
    actual <- ler_read_window_surface("case.yaml", "FLake", contract, folder = project)
    list(actual = actual, expected = .lw_utc(start) +
      seq.int(0, length(times) - 1) * native_step)
  }
  subdaily <- fixture("flake_hourly_0600", 3600,
    "2010-01-01 06:00:00", "2010-01-02 06:00:00", "2010-01-01 06:00:00")
  ok("FLake subdaily absolute timestamps are not shifted twice at 06:00",
     identical(as.numeric(subdaily$actual$datetime), as.numeric(subdaily$expected)) &&
       near(subdaily$actual$temperature, 11:35))
  daily <- fixture("flake_daily_0600", 86400,
    "2010-01-01 06:00:00", "2010-01-04 06:00:00", "2010-01-01 00:00:00")
  ok("FLake daily labels preserve the documented output-hour adjustment",
     identical(as.numeric(daily$actual$datetime), as.numeric(daily$expected)) &&
       near(daily$actual$temperature, 11:14))
  cat(sprintf("\nAll %d v0.1.0-defect regression checks passed.\n", ntest))
  cat("Synthetic reader/RNG tests do not establish physical validity or Windows binary compatibility.\n")
})
