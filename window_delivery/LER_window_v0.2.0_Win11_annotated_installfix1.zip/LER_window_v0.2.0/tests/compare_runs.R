# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Compare real serial and parallel LHC runs AFTER both have completed.
# Rscript tests/compare_runs.R SERIAL_RUN_DIR PARALLEL_RUN_DIR [temperature_tolerance]
a <- commandArgs(trailingOnly=TRUE)
if (length(a)<2L || length(a)>3L) stop("Supply serial and parallel run directories; optional tolerance")
tol <- if(length(a)==3L) as.numeric(a[3]) else 1e-6
if(!is.finite(tol) || tol<0) stop("Invalid tolerance")
rd <- function(p) read.csv(p,stringsAsFactors=FALSE,check.names=FALSE)
x <- rd(file.path(a[1],"calibration_summary.csv")); y <- rd(file.path(a[2],"calibration_summary.csv"))
key <- function(z) paste(z$model,z$par_id,sep="::")
if(anyDuplicated(key(x)) || anyDuplicated(key(y)) || !setequal(key(x),key(y))) stop("Different candidate IDs")
y <- y[match(key(x),key(y)),,drop=FALSE]
if(!identical(x$status,y$status)) stop("Serial and parallel statuses differ")
num_equal <- function(u,v) {
  if(!identical(is.na(u),is.na(v)) || !identical(is.infinite(u),is.infinite(v))) return(FALSE)
  good <- is.finite(u)&is.finite(v)
  if(any(abs(u[good]-v[good])>tol)) return(FALSE)
  inf <- is.infinite(u)&is.infinite(v)
  if(any(u[inf]!=v[inf])) return(FALSE)
  TRUE
}
for(nm in c("N","objective","RMSE","MAE","bias","NSE","r"))
  if(!num_equal(x[[nm]],y[[nm]])) stop("Candidate metric mismatch: ",nm)
for(m in unique(x$model)) {
  p <- rd(file.path(a[1],paste0("params_",m,".csv")))
  q <- rd(file.path(a[2],paste0("params_",m,".csv")))
  if(!setequal(p$par_id,q$par_id) || !identical(names(p),names(q))) stop("Different pools: ",m)
  q <- q[match(p$par_id,q$par_id),,drop=FALSE]
  for(nm in setdiff(names(p),"par_id")) if(!isTRUE(all.equal(p[[nm]],q[[nm]],tolerance=1e-13))) stop("Different parameter values")
}
for(i in which(x$status=="ok")) {
  rel <- file.path("calibration",x$model[i],x$par_id[i],"pairs.csv")
  p <- rd(file.path(a[1],rel)); q <- rd(file.path(a[2],rel))
  if(!identical(p$window_id,q$window_id)) stop("Different window IDs: ",rel)
  for(nm in c("window_start","window_end","method","model"))
    if(!identical(p[[nm]],q[[nm]])) stop("Different window definitions: ",rel)
  for(nm in c("predicted","observed","residual","n_expected","n_used","duration_seconds","step_seconds"))
    if(!num_equal(p[[nm]],q[[nm]])) stop("Window mismatch: ",rel," / ",nm)
}
if(!any(x$status=="ok")) stop("All runs failed: matching failures do not validate the workflow")
cat("PASS: same parameter pools, statuses, fixed windows and numerical scores within tolerance.\n")
if(any(x$status!="ok")) cat("WARNING: some candidates failed in both runs; inspect failure causes separately.\n")
