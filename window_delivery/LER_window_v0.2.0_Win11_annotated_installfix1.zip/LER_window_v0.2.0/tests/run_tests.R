# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Run from the bundle root, or source from the documented Windows preflight.
# Numerical/helper tests only; physical-model acceptance is a separate command.
local({
  source("R/window_calibration.R", local = TRUE, encoding = "UTF-8")
  source("tests/test_core.R", local = TRUE, encoding = "UTF-8")
  source("tests/test_regressions.R", local = TRUE, encoding = "UTF-8")
  source("tests/test_wan_preparation.R", local = TRUE, encoding = "UTF-8")
  source("tests/test_parallel_core.R", local = TRUE, encoding = "UTF-8")
  source("tests/test_upstream_preservation.R", local = TRUE, encoding = "UTF-8")
  source("tests/test_failure_audit.R", local = TRUE, encoding = "UTF-8")
  source("tests/test_windows_sha256_encoding.R", local = TRUE, encoding = "UTF-8")
  cat("\nALL numerical, regression, Wan-contract, and synthetic PSOCK checks completed.\n")
})
