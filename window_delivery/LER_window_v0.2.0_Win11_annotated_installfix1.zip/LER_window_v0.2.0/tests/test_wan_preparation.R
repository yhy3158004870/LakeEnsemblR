# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Synthetic scientific-contract tests; no model package or external data needed.
local({
  source("tools/prepare_wan_windows.R", local = TRUE, encoding = "UTF-8")
  tests <- 0L
  ok <- function(label, expr) {
    if (!isTRUE(force(expr))) stop("FAIL Wan: ", label, call. = FALSE)
    tests <<- tests + 1L; cat(sprintf("PASS Wan %02d: %s\n", tests, label))
  }
  err <- function(expr) inherits(tryCatch(force(expr), error = identity), "error")
  tmp <- tempfile("Wan_中文路径_"); dir.create(tmp)
  on.exit(unlink(tmp, recursive = TRUE), add = TRUE)
  dir.create(file.path(tmp, "daytime")); dir.create(file.path(tmp, "nighttime"))
  d <- seq.int(1L, 361L, 8L)
  base <- data.frame(YEAR = c(2001, 2004, 2001, 2004), NAME_ID = c(1, 1, 2, 2), check.names = FALSE)
  names(base)[1L] <- "%YEAR"
  for (i in seq_along(d)) base[[sprintf("MEAN_%03d", d[i])]] <- as.character(c(10, 11, 30, 31) + i / 100)
  paths <- character()
  for (ch in c("D", "N")) for (level in c("raw", "filled", "filter")) {
    x <- base
    for (nm in names(x)[-(1:2)]) x[[nm]] <- format(as.numeric(x[[nm]]) + if (ch == "N") -2 else 0, trim = TRUE, digits = 15)
    if (level == "raw") x[1L, if (ch == "D") "MEAN_001" else "MEAN_009"] <- "Null"
    if (level == "filled") x$MEAN_017 <- format(as.numeric(x$MEAN_017) + 0.01, trim = TRUE, digits = 15)
    if (level == "filter") for (nm in names(x)[-(1:2)]) x[[nm]] <- format(as.numeric(x[[nm]]) + 0.1, trim = TRUE, digits = 15)
    # Deliberately different file order: joining by row number would be wrong.
    if (ch == "N") x <- x[c(4, 2, 1, 3), ]
    path <- file.path(tmp, if (ch == "D") "daytime" else "nighttime", paste0("LSWT_", ch, "_", level, ".txt"))
    utils::write.table(x, path, sep = "\t", quote = FALSE, row.names = FALSE, na = "Null")
    paths <- c(paths, path)
  }
  utils::write.csv(data.frame(NAME_ID = c(1,2), NAME_EN = c("合成湖泊", "Other"), LAT_NORTH = c(30,31), LONG_EAST = c(90,91)),
                   file.path(tmp, "LAKE_INFO.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  prepared <- wan_prepare_master(tmp, 1, "celsius", calibration_years = 2001, validation_years = 2004)
  m <- prepared$master; r <- prepared$review
  ok("46 windows per year and keyed joins across reordered files", nrow(m) == 92 && m$N_raw_celsius[3] == 8.03)
  ok("raw source token retained and missing source propagated", m$D_raw_source_token[1] == "Null" && is.na(m$D_raw_celsius[1]))
  ok("DN raw requires both channels; no single-channel fallback", is.na(m$DN_raw_proxy_celsius[1]) && is.na(m$DN_raw_proxy_celsius[2]))
  ok("missing raw establishes gap flags, not rounding differences", m$D_gap_filled[1] && m$N_gap_filled[2] && !m$D_gap_filled[3] && m$D_filled_celsius[3] != m$D_raw_celsius[3])
  ok("all six channels and original source checksums retained", all(paste0(c("D_raw", "N_raw", "D_filled", "N_filled", "D_filter", "N_filter"), "_celsius") %in% names(m)) && nrow(prepared$source_manifest) == 7)
  ok("no record receives automatic approval", nrow(wan_export_windows(m, r, "raw")) == 0L && all(r$include == "") && all(r$quality_ok == ""))
  ok("common-year final window lasts 5 days", m$n_days[m$YEAR == 2001 & m$DOY == 361] == 5)
  ok("leap-year final window lasts 6 days", m$n_days[m$YEAR == 2004 & m$DOY == 361] == 6)
  ok("first window resets on Jan 1 rather than a multi-year 8-day grid", m$period_start_UTC[47] == "2004-01-01 00:00:00")
  ok("Celsius source declaration required and no implicit scaling", err(wan_prepare_master(tmp, 1, "kelvin")))
  ok("mixed and duplicate year split assignments rejected", err(wan_prepare_master(tmp, 1, "celsius", calibration_years = 2001, validation_years = 2001)))
  ok("missing NAME_ID fails instead of another lake fallback", err(wan_prepare_master(tmp, 999, "celsius")))
  approve <- function(review, index) {
    review$include[index] <- "TRUE"; review$open_water_ok[index] <- "TRUE"; review$quality_ok[index] <- "TRUE"
    review$open_water_basis[index] <- "Synthetic explicit full-window ice mask, not real data"
    review$quality_basis[index] <- "Synthetic controlled finite-value fixture, not real data"
    review$reviewer[index] <- "unit test"; review$review_date[index] <- "2026-10-13"
    review
  }
  good <- approve(r, c(3,47))
  out <- wan_export_windows(m, good, "raw")
  ok("only approved records exported with disjoint year labels", nrow(out) == 2 && identical(out$split, c("calibration", "validation")) && all(out$use))
  ok("raw two-channel proxy preserved numerically", abs(out$observed[1] - 9.03) < 1e-12 && out$source_column[1] == "DN_raw_proxy_celsius")
  bad <- good; bad$open_water_ok[3] <- ""
  ok("unknown open-water cannot become approved", err(wan_export_windows(m, bad, "raw")))
  bad <- good; bad$quality_basis[3] <- ""
  ok("approval requires recorded scientific basis", err(wan_export_windows(m, bad, "raw")))
  bad <- approve(r, 1)
  ok("raw proxy with a missing channel remains unusable", err(wan_export_windows(m, bad, "raw", allow_gap_filled = TRUE)))
  ok("filled/filter raw gaps cannot enter by default", err(wan_export_windows(m, bad, "filter")))
  ok("global gap permission alone is insufficient", err(wan_export_windows(m, bad, "filled", allow_gap_filled = TRUE)))
  bad$gap_filled_ok[1] <- "TRUE"; bad$gap_fill_basis[1] <- "Synthetic deliberate missing-source sensitivity test"
  filled <- wan_export_windows(m, bad, "filled", allow_gap_filled = TRUE)
  ok("explicit global and row-level permission preserves reconstructed origin", nrow(filled) == 1 && filled$D_gap_filled && filled$allow_gap_filled)
  filtered <- wan_export_windows(m, good, "filter")
  ok("filter use remains labelled even with available raw channels", all(filtered$uses_filtered_product) && all(filtered$D_raw_available))
  bad <- good; bad$split[4] <- "validation"
  ok("splitting adjacent windows in one year is rejected", err(wan_export_windows(m, bad, "raw")))
  leading_zero <- m; leading_zero$YEAR <- as.character(leading_zero$YEAR); leading_zero$YEAR[4] <- "02001"
  ok("alternate year spelling cannot bypass whole-year split", err(wan_export_windows(leading_zero, bad, "raw")))
  ok("review dropping a row is rejected", err(wan_export_windows(m, good[-1, ], "raw")))
  ok("duplicate review keys rejected", err(wan_export_windows(m, rbind(good, good[1,]), "raw")))
  bad <- m; bad$period_end_exclusive_UTC[1] <- "2001-01-10 00:00:00"
  ok("window-boundary tampering rejected", err(wan_export_windows(bad, good, "raw")))
  bad <- m; bad$DN_raw_proxy_celsius[3] <- 99
  ok("proxy tampering rejected independently of review", err(wan_export_windows(bad, good, "raw")))
  bad <- m; bad$D_gap_filled[3] <- TRUE
  ok("fabricated gap provenance rejected", err(wan_export_windows(bad, good, "raw")))
  bad <- good; bad$review_date[3] <- "2026-02-30"
  ok("invalid review dates rejected", err(wan_export_windows(m, bad, "raw")))
  disk <- wan_prepare_master(tmp, 1, "celsius", out_dir = file.path(tmp, "输出_中文"), calibration_years = 2001, validation_years = 2004)
  .wan_write_csv(good, file.path(tmp, "审核_已完成.csv"))
  diskout <- wan_export_windows(disk$paths$master, file.path(tmp, "审核_已完成.csv"), "raw", file.path(tmp, "模型_窗口.csv"))
  ok("Chinese path CSV round trip and manifest verification", nrow(diskout) == 2 && file.exists(file.path(tmp, "模型_窗口.csv.manifest.csv")))
  ok("existing preparation/output files are never overwritten", err(wan_prepare_master(tmp, 1, "celsius", out_dir = file.path(tmp, "输出_中文"))) && err(wan_export_windows(disk$paths$master, file.path(tmp, "审核_已完成.csv"), "raw", file.path(tmp, "模型_窗口.csv"))))
  changed <- readLines(disk$paths$master, encoding = "UTF-8"); writeLines(c(changed, ""), disk$paths$master, useBytes = TRUE)
  ok("edited master file checksum invalidates export", err(wan_export_windows(disk$paths$master, file.path(tmp, "审核_已完成.csv"), "raw")))
  original <- readLines(paths[1], encoding = "UTF-8")
  writeLines(c(original, original[2]), paths[1], useBytes = TRUE)
  ok("duplicate lake/year source row rejected", err(wan_prepare_master(tmp, 1, "celsius")))
  writeLines(original, paths[1], useBytes = TRUE)
  wrong <- readLines(paths[2], encoding = "UTF-8"); writeLines(wrong[-2], paths[2], useBytes = TRUE)
  ok("incomplete source key universe rejected", err(wan_prepare_master(tmp, 1, "celsius")))
  ok("unexpected missing sentinel and infinity fail explicitly", err(.wan_temp("-9999", "sentinel")) && err(.wan_temp("Inf", "infinity")) && err(.wan_temp("bad", "token")))
  cat(sprintf("\nAll %d Wan preprocessing contract tests passed.\n", tests))
})
