# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Source/API preservation, not a proof of equality for every physical run.
local({
  root <- normalizePath(".",winslash="/",mustWork=TRUE)
  manifest <- read.csv("provenance/upstream_R_sha256.csv",stringsAsFactors=FALSE)
  old_rows <- manifest[manifest$file!="R/cali_ensemble.R",,drop=FALSE]
  for (i in seq_len(nrow(old_rows))) {
    path <- file.path("src/LakeEnsemblR-window",old_rows$file[i])
    actual <- digest::digest(file=path,algo="sha256",serialize=FALSE)
    if (!identical(actual,old_rows$sha256[i])) stop("Protected upstream R source changed: ",old_rows$file[i])
  }
  extract <- function(path) {
    parsed <- parse(path,keep.source=FALSE)
    target <- which(vapply(parsed,function(z)is.call(z) && identical(z[[1]],as.name("<-")) &&
      identical(z[[2]],as.name("cali_ensemble")),logical(1)))
    if (length(target)!=1L) stop("Could not uniquely read cali_ensemble")
    eval(parsed[[target]][[3L]],envir=environment())
  }
  old <- extract("provenance/upstream_cali_ensemble.R")
  new <- extract("src/LakeEnsemblR-window/R/cali_ensemble.R")
  canonical <- function(x) parse(text=deparse(x,width.cutoff=500L,
                                             control=c("keepInteger","keepNA")),keep.source=FALSE)[[1L]]
  tail <- as.call(c(list(as.name("{")),as.list(body(new))[-c(1L,2L)]))
  if (!identical(canonical(tail),canonical(body(old)))) stop("Original cali_ensemble body changed")
  if (!identical(names(formals(new)),c(names(formals(old)),"window")))
    stop("window must be named-only after ... to preserve old positional calls")
  if (!identical(as.list(formals(new))[names(formals(old))],as.list(formals(old))))
    stop("Original argument defaults were changed")
  message("PASS: all original R files preserved; cali_ensemble original body/defaults retained; window named-only")
})
