# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Run from the bundle root: Rscript tests/test_failure_audit.R
# Uses genuine LER configuration export with the bundled Feeagh reference inputs,
# then deliberately replaces only the engine invocation by a failing test stub.
# It runs NO physical model and does not validate Wan or Windows executables.
local({
  engine_env <- new.env(parent = .GlobalEnv)
  source("R/window_calibration.R", local = engine_env, encoding = "UTF-8")
  engine_env$.lw_initialize_runtime()
  ntest <- 0L
  ok <- function(name, value) {
    if (!isTRUE(force(value))) stop("FAIL: ", name, call. = FALSE)
    ntest <<- ntest + 1L
    cat(sprintf("PASS F%02d: %s\n", ntest, name))
  }
  root <- tempfile("ler-failure-audit-")
  dir.create(root)
  on.exit(unlink(root, recursive = TRUE), add = TRUE)
  project <- file.path(root, "project")
  dir.create(project)
  template <- system.file("extdata/feeagh", package = "LakeEnsemblR")
  if (!nzchar(template)) stop("Installed LER Feeagh reference fixture is missing")
  if (!all(file.copy(list.files(template, full.names = TRUE), project, recursive = TRUE)))
    stop("Could not copy reference inputs")
  cfg <- engine_env$.lw_read_config(file.path(project, "LakeEnsemblR.yaml"))
  cfg$time$start <- "2010-01-01 00:00:00"
  cfg$time$stop <- "2010-02-01 00:00:00"
  observed <- read.csv(file.path(project, cfg$observations$temperature$file),
                        stringsAsFactors = FALSE)
  initial <- observed[observed$datetime == cfg$time$start,
    c("Depth_meter", "Water_Temperature_celsius"), drop = FALSE]
  if (!nrow(initial)) stop("Feeagh initial profile is missing")
  write.csv(initial, file.path(project, "initial_profile.csv"), row.names = FALSE)
  cfg$input$init_temp_profile$file <- "initial_profile.csv"
  cfg$output$variables <- "temp"
  engine_env$.lw_write_config(cfg, file.path(project, "LakeEnsemblR.yaml"))
  results <- file.path(root, "results")
  dir.create(results)
  snapshot <- file.path(results, "snapshot")
  base <- engine_env$.lw_snapshot(project, "LakeEnsemblR.yaml", snapshot, "FLake")
  spec <- engine_env$.lw_specs(base, "FLake")
  row <- as.data.frame(as.list(setNames(spec$initial, spec$name)), check.names = FALSE)
  row$par_id <- "p0000001"
  contract <- data.frame(model = "FLake", method = "sample_mean", step_seconds = 86400,
    phase_seconds = 0, label_position = "point", timestamp_shift_seconds = 0,
    temperature_column = "wtr_0", confirmed = FALSE,
    meaning = "failure archive fixture; no physical engine or temperature score", stringsAsFactors = FALSE)
  windows <- engine_env$ler_modis_windows(c(2010, 2010), c(9, 17))
  windows$observed <- c(4, 5) # Not scored: the engine is intentionally blocked.
  ctx <- list(base = base, snapshot = snapshot, result_dir = results,
    config_file = "LakeEnsemblR.yaml", control = list(seed = 20261013L,
      allow_constant_Kw_override = FALSE),
    metadata = list(snapshot_files = engine_env$.lw_file_manifest(snapshot)))
  calls <- 0L
  engine_env$.lw_run_engine <- function(model, cfg, verbose = FALSE) {
    calls <<- calls + 1L
    writeLines("INTENTIONAL_TEST_ENGINE_CONSOLE", file.path(model, "engine_console.log"))
    writeLines("incomplete output fixture", file.path(model, "output", "large-output.csv"))
    stop("INTENTIONAL_TEST_ENGINE_FAILURE", call. = FALSE)
  }
  work <- file.path(results, "_work", "worker")
  response <- engine_env$.lw_candidate(ctx, "FLake", spec, row, contract, work,
    "calibration", windows, save_series = TRUE, keep_case = FALSE)
  first <- file.path(results, "calibration", "FLake", row$par_id)
  ok("injected engine failure is reported with its exact stage and failure objective",
    identical(response$status, "failed") && identical(response$stage, "run_engine") &&
      grepl("INTENTIONAL_TEST_ENGINE_FAILURE", response$message, fixed = TRUE) &&
      is.infinite(response$objective) && is.na(response$RMSE))
  archived_row <- read.csv(file.path(first, "parameters.csv"), check.names = FALSE)
  ok("failed candidate permanently retains its requested parameters and contract",
    identical(archived_row$par_id, row$par_id) &&
      isTRUE(all.equal(archived_row, row, check.attributes = FALSE)) &&
      file.exists(file.path(first, "contract.csv")))
  ok("engine console log is copied out of the disposable worker directory",
    identical(readLines(file.path(first, "engine_console.log")), "INTENTIONAL_TEST_ENGINE_CONSOLE"))
  debug <- file.path(first, "debug_config")
  native <- file.path(debug, base$config_files$FLake)
  ok("failed engine case retains exported master YAML and native namelist",
    file.exists(file.path(debug, "LakeEnsemblR.yaml")) && file.exists(native) &&
      abs(as.numeric(suppressWarnings(glmtools::get_nml_value(nml_file = native, arg_name = "c_relax_C"))) -
        row$c_relax_C) < 1e-12)
  debug_files <- list.files(debug, recursive = TRUE, all.files = TRUE, no.. = TRUE)
  ok("debug archive excludes forcing files and failed native outputs",
    !any(grepl("(^|/)output/|\\.(csv|dat)$", debug_files, ignore.case = TRUE)) &&
      !dir.exists(file.path(debug, "_inputs")))

  # Reuse the worker like real candidate chunks. The next failure occurs before
  # a new master YAML is written and must not inherit candidate one's artifacts.
  bad <- ctx
  bad$base$input$light$Kw$FLake <- "existing-time-varying-Kw.csv"
  row2 <- row
  row2$par_id <- "p0000002"
  second_response <- engine_env$.lw_candidate(bad, "FLake", spec, row2, contract, work,
    "calibration", windows, save_series = TRUE, keep_case = FALSE)
  second <- file.path(results, "calibration", "FLake", row2$par_id)
  ok("preparation failure does not invoke the model or use a preceding score",
    calls == 1L && identical(second_response$status, "failed") &&
      identical(second_response$stage, "prepare") && is.infinite(second_response$objective))
  ok("preparation failure retains requested inputs without a stale master/log",
    file.exists(file.path(second, "parameters.csv")) &&
      file.exists(file.path(second, "contract.csv")) &&
      !file.exists(file.path(second, "engine_console.log")) &&
      !file.exists(file.path(second, "debug_config", "LakeEnsemblR.yaml")))

  # A snapshot-integrity rejection happens even earlier, while the reusable
  # worker still contains the preceding case. No artifacts should be mislabeled.
  input <- file.path(snapshot, base$input$meteo$file)
  original <- readBin(input, "raw", n = file.info(input)$size)
  altered <- original
  altered[1] <- as.raw(if (as.integer(original[1]) == 88L) 89L else 88L)
  writeBin(altered, input)
  row3 <- row
  row3$par_id <- "p0000003"
  third_response <- engine_env$.lw_candidate(ctx, "FLake", spec, row3, contract, work,
    "calibration", windows, save_series = TRUE, keep_case = FALSE)
  writeBin(original, input)
  third <- file.path(results, "calibration", "FLake", row3$par_id)
  ok("snapshot corruption is reported before export or engine execution",
    calls == 1L && identical(third_response$status, "failed") &&
      identical(third_response$stage, "prepare") &&
      grepl("Input/configuration snapshot changed", third_response$message, fixed = TRUE))
  ok("snapshot rejection retains parameters without stale case configuration or log",
    file.exists(file.path(third, "parameters.csv")) &&
      file.exists(file.path(third, "contract.csv")) &&
      !file.exists(file.path(third, "engine_console.log")) &&
      !dir.exists(file.path(third, "debug_config")))
  unlink(work, recursive = TRUE)
  ok("failure evidence survives deletion of the entire disposable worker",
    !dir.exists(work) && file.exists(file.path(first, "engine_console.log")) &&
      file.exists(native) && file.exists(file.path(first, "status.csv")) &&
      file.exists(file.path(second, "status.csv")) && file.exists(file.path(third, "status.csv")))
  cat(sprintf("\nAll %d failure-audit checks passed with actual configuration export and an intentionally failing engine stub.\n", ntest))
})
