# Wan LSWT 数据处理与科研配置（v0.2.0）

`tools/prepare_wan_windows.R` 将 Wan 发布的六套湖泊级宽表转换为可追溯的观测主表、人工审核表和窗口率定输入。只使用 base R；在 Win11 的 R/RStudio 中用 `source(..., encoding="UTF-8")` 加载，无须安装 Python。它支持中文路径，但建议给五模型的项目目录使用短英文路径，避免外部模型本身的路径限制。

## 输入与温度定义

解压原始数据，保持以下相对结构：

```text
TPLakes_Temperature/
  LAKE_INFO.csv
  daytime/LSWT_D_raw.txt
  daytime/LSWT_D_filled.txt
  daytime/LSWT_D_filter.txt
  nighttime/LSWT_N_raw.txt
  nighttime/LSWT_N_filled.txt
  nighttime/LSWT_N_filter.txt
```

每个 TXT 是 `%YEAR NAME_ID MEAN_001 MEAN_009 ... MEAN_361` 的制表符分隔宽表。六个文件通过 `NAME_ID + YEAR` 关联，程序检查全文件键一致性和重复键，允许各文件行顺序不同。每次生成一个湖泊的窗口表，并核对 `LAKE_INFO.csv`。不能用行号、湖名相似程度或图形外观替代 `NAME_ID` 对应检查。

这些发布温度已是摄氏度，见 Wan et al. 2017（DOI: [10.1038/sdata.2017.95](https://doi.org/10.1038/sdata.2017.95)）。函数要求调用者明确填写 `source_units="celsius"`，保留原数值，不进行 MODIS 整数缩放或任何偏差订正。单位不能仅从无单位的数字列自动恢复；该声明要求研究者确认使用的是上述湖泊级发布表，而不是另一个整数栅格产品。低于 −273.15 °C、非有限数字或未知文本 token 会被拒绝；程序不把一个研究阈值假设为普遍适用的异常温度界限。

六套通道原数值和原文本 token 都保留：

| 字段 | 含义 |
|---|---|
| `D_raw_celsius`, `N_raw_celsius` | 日/夜 raw，缺失继续为 NA |
| `D_filled_celsius`, `N_filled_celsius` | 发布的填补序列 |
| `D_filter_celsius`, `N_filter_celsius` | 发布的滤波序列 |
| 相应 `*_source_token` | 原 TXT 单元格文本，包括 `Null` |
| `D_raw_available`, `N_raw_available` | 该通道 raw 是否有有限合成值 |
| `D_gap_filled`, `N_gap_filled` | raw 原缺失且 filled 有限，表示缺口来源 |
| `DN_raw_proxy_celsius` 等 | **两通道均有限**时的 `(D+N)/2` |
| `*_source_md5` | 对应原 TXT 的文件 MD5 |

填补来源根据 raw 缺失判定，**不根据 raw 与 filled 是否数值相等判定**；发布表在原有值上也可能出现小数舍入差异。`filter` 是处理过的序列，即使该窗原来有 raw 值也不能称为独立原始测量。输出额外保留 `uses_filtered_product` 标记。

## 第一步：生成主表与空审核表

在 R/RStudio 中执行（替换路径和湖泊 ID）：

```r
bundle <- "D:/LER_window_v0.2.0"
source(file.path(bundle, "tools", "prepare_wan_windows.R"), encoding = "UTF-8")
data_dir <- "D:/数据/TPLakes_Temperature"
output_dir <- "D:/研究/Wan_obs/lake_201"

# 201 仅为与上传数据测试对应的示例；这里填写本湖泊的 NAME_ID。
prepared <- wan_prepare_master(
  data_dir = data_dir, name_id = 201,
  source_units = "celsius", out_dir = output_dir
)
prepared$paths
head(prepared$master)
```

生成四个文件：

- `wan_master_<ID>.csv`：六通道、代理量、缺测/来源标志、显式窗口、湖泊属性。
- `wan_review_<ID>.csv`：与主表完全相同的键，每一行的批准字段均空白。
- `wan_sources_<ID>.csv`：六个 TXT 和 `LAKE_INFO.csv` 的路径及 MD5。
- `wan_master_md5_<ID>.csv`：主表文件校验值。

`out_dir` 已存在但没有上述文件时可以使用；已存在任何同名输出则拒绝覆盖。保留原主表和 MD5 文件，不用 Excel 编辑主表，也不重新保存主表来改变格式。需要改变来源或处理定义时重新生成到另一个目录，保留前一版。审核表可以编辑并保存为一个新文件。

对每一年的 DOY `001,009,...,361`，窗口为 `[当年1月1日+DOY−1天, min(起点+8天, 次年1月1日))`，全部按 UTC 日期表示。平年的最后窗口 5 天，闰年 6 天；每年重置，不能连续多年滚动 `seq(..., by="8 days")`。`label_datetime_UTC` 是窗口中点标签，**不是卫星实际过境时刻**。每个 8 天值仍是一条观测，程序不会复制为 8 个独立日观测。

## 第二步：固定研究规则和时间分期，再完成审核

先写明并固定：主分析采用 raw/filled/filter 中哪一个；无冰期和异常记录判断依据；原始缺口是否允许进入主分析；率定与评价年块；边界缓冲及敏感性分析。不要查看每个模型的拟合结果后再修改观测筛选掩膜。所有模型、所有候选参数应使用同一个固定观测集合。

程序没有硬编码研究年份。可以在生成主表时传入由研究设计决定的 `calibration_years` 和 `validation_years`，这只填写 `split`，仍不会批准任何记录；也可以在审核表中填写 `split`。同一年不能同时赋值为 `calibration` 和 `validation`，任意随机打散相邻窗口的划分将被拒绝。未用于研究的行可保留空白或 `excluded`。

| 审核字段 | 被纳入记录的要求 |
|---|---|
| `include` | 明确 `TRUE`；空白始终未批准 |
| `open_water_ok` | 明确 `TRUE`，指整个窗口满足预定开放水面标准 |
| `quality_ok` | 明确 `TRUE`，符合预先固定的质量规则 |
| `split` | `calibration` 或 `validation`，不同集合用不相交年块 |
| `open_water_basis` | 所用资料、规则或证据；程序不验证证据的科学充分性 |
| `quality_basis` | 所用 QA/异常筛选规则及依据 |
| `reviewer`, `review_date` | 审核人/脚本版本与真实 `YYYY-MM-DD` 日期 |
| `gap_filled_ok`, `gap_fill_basis` | 原 raw 任一通道缺失时，额外逐条批准和记录依据 |
| `notes` | 可选研究备注，保留在审核表 |

`TRUE/FALSE` 或 `1/0` 均可；空白仅表示未批准。不得把所有行直接填 `TRUE` 来通过软件检查。程序只核验格式、逻辑一致性和依据是否记录，**不能认证所写依据在科学上充分**。保存 CSV 为 UTF-8；不要改 `NAME_ID/YEAR/DOY` 或窗口边界。Excel 可能自动改变日期格式，应检查仍为原 `YYYY-MM-DD HH:MM:SS`。推荐用 R 编辑分期、保留所有行并另存审核文件：

```r
review <- read.csv(prepared$paths$review, check.names = FALSE,
                   colClasses = "character", fileEncoding = "UTF-8-BOM")

# 由外部研究设计填入，不用软件替你决定年份。
calibration_years <- integer()
validation_years <- integer()
review$split[review$YEAR %in% as.character(calibration_years)] <- "calibration"
review$split[review$YEAR %in% as.character(validation_years)] <- "validation"

# 完成有依据的逐窗/规则审核后，保存全表；不删除未纳入的行。
reviewed_file <- file.path(output_dir, "wan_review_completed.csv")
if (file.exists(reviewed_file)) stop("请选择一个新的审核文件名")
write.csv(review, reviewed_file, row.names = FALSE, na = "", fileEncoding = "UTF-8")
```

无冰判定优先使用独立冰覆盖/冰物候、湖泊特定非冰期资料；仅有这套 LSWT 时，需要明确它对冰期识别的限制，采用保守且有依据的方案和敏感性检查。程序不会以 `温度>0`、统一 `5 °C` 或固定月份自动认证无冰，也不会把负值截断为 0。负值可能反映冰雪表面或其它情形，不能自动解释为液态水温。

湖泊级表没有逐像元逐日 QA、有效晴空日期、过境时刻和采样权重。raw 缺测位置少只说明合成值少量缺失，**不能据此推算有 8 天有效晴空观测，更不能把它当作 QA 验收**。

## 第三步：只导出已批准窗口

```r
windows_file <- file.path(output_dir, "MODIS_windows_raw_reviewed.csv")
windows <- wan_export_windows(
  master = prepared$paths$master,
  review = reviewed_file,
  proxy = "raw",                  # 显式选择，不能静默混用通道或产品
  output = windows_file,
  allow_gap_filled = FALSE         # 主分析默认不允许原 raw 缺口来源
)
nrow(windows)
```

审核完全空白时，结果是 **0 条批准记录**，CSV 仅有表头；窗口率定将拒绝空输入。填补/滤波主分析或敏感性实验应换新输出名，并明确采用 `proxy="filled"` 或 `"filter"`。如纳入原 raw 缺口，则必须同时设置 `allow_gap_filled=TRUE`、逐行 `gap_filled_ok=TRUE` 并填写 `gap_fill_basis`。这只是显式表达研究选择，不使重建值成为独立观测，也不会使缺通道的 raw 代理量变得可用。

程序核验：完整且唯一的主表/审核键、年度日历、摄氏单位声明、主表 MD5、原始有效性/填补标志、两通道等权代理量、审核逻辑和按年分期。审核可以改变行顺序，但不能删除未批准行。输出按起点排序，并保留六个 LER 必需筛选/分期字段及来源信息；另存 `<窗口文件>.manifest.csv` 记录主表、审核表、输出的 MD5、产品选择及批准数。MD5 用于发现无意改动，不是对科学审核或恶意篡改的认证。正式运行优先使用文件路径参数，使记录能保存真实文件校验值；直接传 data.frame 时也支持测试，但 manifest 明确记为无文件 checksum。

命令行也可运行，参数中的路径加双引号：

```text
Rscript tools/prepare_wan_windows.R prepare "D:/数据/TPLakes_Temperature" 201 "D:/研究/Wan_obs/lake_201" celsius
Rscript tools/prepare_wan_windows.R export "D:/研究/Wan_obs/lake_201/wan_master_201.csv" "D:/研究/Wan_obs/lake_201/wan_review_completed.csv" raw "D:/研究/Wan_obs/lake_201/windows.csv"
```

允许原始缺口时，export 命令最后增加 `allow-gap-filled`。命令行准备阶段不指定科学分期，使用后续审核表完成。

## 科研解释与完整模型工作流的边界

昼夜等权均值是“8 天合成期昼夜 LSWT 代理量”，不是由完整连续观测得到的严格全天均值。卫星具有晴空选择、空间湖面平均、皮肤温度与过境时刻特征；模型均值反映其实际输出层和已声明的时间语义。正确的窗口匹配不能自动消除这些代表性差异。Wan et al. 2018（DOI: [10.1029/2018GL078601](https://doi.org/10.1029/2018GL078601)）的主分析是夜间 LSWT，不能用来证明昼夜代理量等于全天平均。

发布的 filled/filter 可能使用相邻年份信息，特别是分期边界；本工具保持发布值，不重新滤波，不声称其处理在率定/评价之间独立。事先考虑 raw 主分析、处理敏感性和分期缓冲，并记录是否存在共享处理信息。同一遥感产品的时间留出仍可能共享系统偏差，应称“时间留出评价”，而非独立观测系统验证。

模型工作流还需要每湖真实气象驱动、湖盆形态、初始剖面、模型物理配置、充分预热、输出合同与完整模型输出。该转换器不会生成或认证这些输入，不会修正 TPMFD/TPMDF 的单位、时间或空间提取，也不能从 LSWT 认证全水柱热结构或盐度/冰过程适用性。将合格输出窗口交给 `ler_window_control()` 后，先运行模型探测、小规模串行与相同参数表并行对照、最佳重跑一致性，再扩大正式搜索。参数边界、识别性、默认参数基线、搜索稳定性和不确定性分析应另行设计。

## 本次验证

`tests/test_wan_preparation.R` 使用合成数据测试键连接（故意打乱夜间文件顺序）、原值及缺测 token、双通道均值、空白审核、年度5/6天末窗、单位声明、分期、缺口权限、批准依据、窗口/代理量/标志误改、MD5、中文路径与禁止覆盖。真实 R 执行全部通过。

实读用户上传数据的 `NAME_ID=201`（`NAME_EN=Nam Co`）：2001–2015 年，690 窗口；日间 raw 缺 1，夜间 raw 缺 1，发生在同一窗口，所以 DN raw 也缺 1；filled/filter 的 DN 代理量各有 690 个有限值。空白审核导出 0 窗口，平年/闰年末窗分别为5/6天。这只证明格式处理与数值追溯成功；**该湖无冰/QC 未被软件自动审核，也未据此生成真实率定精度结果**。
