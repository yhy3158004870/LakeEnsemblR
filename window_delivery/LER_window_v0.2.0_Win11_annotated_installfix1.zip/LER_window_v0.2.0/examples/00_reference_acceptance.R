# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Reference acceptance fixture only: artificial target temperatures, not Wan data.
# source("D:/LER_window_v0.2.0/examples/00_reference_acceptance.R", encoding="UTF-8")
# ler_reference_acceptance("D:/LER/library_window_v020", "D:/LER/reference_001", num=3)

ler_reference_acceptance <- function(library_dir, run_root, num = 3L, ncores = 2L,
                                     tolerance_celsius = 1e-6) {
  .libPaths(c(normalizePath(library_dir, winslash="/", mustWork=TRUE), .libPaths()))
  library("LakeEnsemblR", character.only=TRUE)
  if (as.character(packageVersion("LakeEnsemblR")) != "1.2.9.9002")
    stop("Restart R and load the dedicated v0.2.0 library first")
  if (file.exists(run_root)) stop("Choose a new nonexistent reference directory")
  dir.create(run_root, recursive=TRUE)
  run_root <- normalizePath(run_root, winslash="/", mustWork=TRUE)
  project <- file.path(run_root,"project")
  dir.create(project)
  template <- system.file("extdata/feeagh", package="LakeEnsemblR")
  if (!nzchar(template)) stop("Feeagh reference inputs are missing")
  if (!all(file.copy(list.files(template,full.names=TRUE), project, recursive=TRUE)))
    stop("Could not copy reference inputs")
  cfg <- configr::read.config(file.path(project,"LakeEnsemblR.yaml"))
  cfg$time$start <- "2010-01-01 00:00:00"
  cfg$time$stop <- "2010-02-03 00:00:00"
  cfg$time$time_step <- 3600
  observed <- read.csv(file.path(project,cfg$observations$temperature$file),
                       stringsAsFactors=FALSE)
  init <- observed[observed$datetime==cfg$time$start,
                   c("Depth_meter","Water_Temperature_celsius"),drop=FALSE]
  if (!nrow(init)) stop("No reference initial temperature profile")
  write.csv(init,file.path(project,"initial_profile.csv"),row.names=FALSE)
  cfg$input$init_temp_profile$file <- "initial_profile.csv"
  cfg$output$variables <- c("temp")
  # Project meteorology is DAILY. FLake follows this cadence; do not invent hours.
  get(".lw_write_config", asNamespace("LakeEnsemblR"))(
    cfg, file.path(project,"LakeEnsemblR.yaml"))
  models <- c("FLake","GLM","GOTM","Simstrat","MyLake")
  windows <- LakeEnsemblR::ler_modis_windows(rep(2010,3),c(9,17,25))
  windows$observed <- c(4.8,4.2,4.5) # Deliberately artificial acceptance targets.
  windows$split <- c("calibration","calibration","validation")
  windows$use <- windows$ice_free <- windows$qc_pass <- TRUE
  contracts <- data.frame(model=models,
    method=c("sample_mean","linear_time_mean","linear_time_mean",
             "linear_time_mean","sample_mean"),
    step_seconds=c(86400,10800,10800,10800,86400),phase_seconds=0,
    label_position="point",timestamp_shift_seconds=0,temperature_column="wtr_0",
    confirmed=FALSE,
    meaning=c("Reference fixture: FLake daily forcing-grid near-surface state",
              "Reference fixture: GLM 3-hour point near-surface output",
              "Reference fixture: GOTM point output selected explicitly",
              "Reference fixture: Simstrat 3-hour state output",
              "Reference fixture: MyLake daily state, not reconstructed diurnal temperature"),
    stringsAsFactors=FALSE)
  control <- LakeEnsemblR::ler_window_control(windows,contracts,seed=20261013L)
  probe <- LakeEnsemblR::ler_window_probe("LakeEnsemblR.yaml",window=control,
    model=models,folder=project,out_dir=file.path(run_root,"probe"))
  print(probe)
  if (any(probe$status!="ok"))
    stop("Reference probe failed. Inspect status.csv and engine logs before calibration")
  # This approval belongs ONLY to the explicitly defined reference fixture above.
  # A user project must independently verify its own native time/depth semantics.
  contracts$confirmed <- TRUE
  control <- LakeEnsemblR::ler_window_control(windows,contracts,seed=20261013L)
  serial <- LakeEnsemblR::cali_ensemble("LakeEnsemblR.yaml",window=control,
    model=models,folder=project,num=num,out_f=file.path(run_root,"serial"),
    parallel=FALSE,ncores=1)
  final <- LakeEnsemblR::evaluate_window_best(serial$run_dir,
                                             tolerance_celsius=tolerance_celsius)
  pools <- setNames(lapply(models,function(m)
    file.path(serial$run_dir,paste0("params_",m,".csv"))),models)
  parallel_fit <- LakeEnsemblR::cali_ensemble("LakeEnsemblR.yaml",window=control,
    model=models,folder=project,param_file=pools,out_f=file.path(run_root,"parallel"),
    parallel=TRUE,ncores=ncores)
  counts <- data.frame(model=models,
    serial_ok=vapply(models,function(m)sum(serial$summary$model==m &
                         serial$summary$status=="ok"),integer(1)),
    parallel_ok=vapply(models,function(m)sum(parallel_fit$summary$model==m &
                         parallel_fit$summary$status=="ok"),integer(1)))
  write.csv(counts,file.path(run_root,"candidate_counts.csv"),row.names=FALSE)
  if (any(counts$serial_ok!=num) || any(counts$parallel_ok!=num))
    stop("Some reference candidates failed; matching partial successes is insufficient")
  # Compare by model + parameter ID + window ID, not only aggregate score.
  for (m in models) for (id in serial$parameters[[m]]$par_id) {
    read_pair <- function(root) read.csv(file.path(root,"calibration",m,id,"pairs.csv"),
                                         stringsAsFactors=FALSE,check.names=FALSE)
    a <- read_pair(serial$run_dir); b <- read_pair(parallel_fit$run_dir)
    if (!identical(a$window_id,b$window_id) ||
        !identical(a$window_start,b$window_start) ||
        !identical(a$window_end,b$window_end) ||
        any(!is.finite(a$predicted)) || any(!is.finite(b$predicted)) ||
        any(abs(a$predicted-b$predicted)>tolerance_celsius))
      stop("Serial/parallel reference mismatch: ",m," / ",id)
  }
  message("PASS: five-model reference probe, calibration, best rerun, separate evaluation, and serial/PSOCK predictions")
  message("Artificial acceptance targets: these scores are not scientific validation of Wan LSWT")
  invisible(list(root=run_root,probe=probe,serial=serial,parallel=parallel_fit,
                 final=final,counts=counts))
}
