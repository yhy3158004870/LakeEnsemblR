# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# After applying/installing the patch, restart R. Edit paths and the two CSV files.
# This workflow never invents observational temperatures or approves ice/QC flags.
.libPaths(c("D:/R/library_LER_window", .libPaths()))
library(LakeEnsemblR)
stopifnot(as.character(packageVersion("LakeEnsemblR")) == "1.2.9.9002")
project <- "D:/lakes/NamCo"  # Existing valid one-lake LER project
windows_file <- file.path(project, "MODIS_windows_reviewed.csv")
contract_file <- file.path(project, "output_contracts.csv")
models <- c("FLake", "GLM", "GOTM", "Simstrat", "MyLake")
w <- read.csv(windows_file, stringsAsFactors=FALSE, check.names=FALSE)
c <- read.csv(contract_file, stringsAsFactors=FALSE, check.names=FALSE)
ctl <- ler_window_control(w, c, seed=20261004L, save_series=TRUE)
# Probe first. Inspect actual native_surface.rds, native_audit.csv and each native model output.
probe_dir <- file.path(project, paste0("probe_", format(Sys.time(), "%Y%m%d_%H%M%S")))
p <- ler_window_probe("LakeEnsemblR.yaml", window=ctl, model=models,
                       folder=project, spin_up=365, out_dir=probe_dir)
print(p)
if (any(p$status != "ok")) stop("Probe failed. Diagnose the logs; do not lower the coverage requirement.")
if (!all(c$confirmed %in% c(TRUE,"TRUE",1,"1")))
  stop("Probe completed. Inspect actual output semantics and only then approve contracts in the CSV.")
# Start small. Do not start with thousands of candidates before checking the complete chain.
fit <- cali_ensemble(config_file="LakeEnsemblR.yaml", folder=project,
  model=models, cmethod="LHC", num=20,
  parallel=FALSE, ncores=1, spin_up=365,
  out_f=paste0("window_trial_", format(Sys.time(), "%Y%m%d_%H%M%S")), window=ctl)
print(fit$best)
# This reruns the selected calibration parameters, verifies calibration predictions,
# and only then reports validation performance using the identical operator.
final_metrics <- evaluate_window_best(fit$run_dir, tolerance_celsius=1e-6)
print(final_metrics)
# Reuse *the same* saved pools to test serial-vs-parallel equivalence:
# pools <- setNames(lapply(models,function(m) file.path(fit$run_dir,paste0("params_",m,".csv"))),models)
# fit_parallel <- cali_ensemble("LakeEnsemblR.yaml",folder=project,model=models,
#   cmethod="LHC",param_file=pools,parallel=TRUE,ncores=4,spin_up=365,
#   out_f="window_trial_parallel_NEW",window=ctl)
# Join by model + par_id and compare status, window pairs and numeric scores.
# After successful checks, start a new run with num=2000 (not an in-place append).
