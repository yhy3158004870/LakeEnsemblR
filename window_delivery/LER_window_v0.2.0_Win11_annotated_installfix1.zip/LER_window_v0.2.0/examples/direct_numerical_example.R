# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# No engines needed: Rscript examples/direct_numerical_example.R
source("R/window_calibration.R", encoding="UTF-8")
w <- ler_modis_windows(c(2001L,2001L),c(1L,9L))
w$observed <- c(10,11)  # SYNTHETIC example, not MODIS data
start <- as.POSIXct("2001-01-01 00:00:00",tz="UTC")
t <- seq(start,start+16*86400,by=10800)
s <- data.frame(datetime=t,temperature=10+as.numeric(difftime(t,start,units="days"))/16)
c <- data.frame(model="Simstrat",method="linear_time_mean",step_seconds=10800,
 phase_seconds=0,label_position="point",timestamp_shift_seconds=0,
 temperature_column="wtr_0",confirmed=TRUE,meaning="synthetic point-state output")
x <- calc_fit_window(s,w,c)
print(x$pairs); print(x$metrics)
