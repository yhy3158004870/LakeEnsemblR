# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# Functions for an existing scientifically prepared one-lake project.
# No observations, ice flags, physical parameters, or output semantics are invented.

ler_load_window_library <- function(library_dir) {
  .libPaths(c(normalizePath(library_dir,winslash="/",mustWork=TRUE),.libPaths()))
  library("LakeEnsemblR",character.only=TRUE)
  if (as.character(packageVersion("LakeEnsemblR"))!="1.2.9.9002")
    stop("Restart R; then load the dedicated v0.2.0 library")
  invisible(TRUE)
}

ler_project_control <- function(project, seed=20261013L, save_series=TRUE) {
  project <- normalizePath(project,winslash="/",mustWork=TRUE)
  windows <- read.csv(file.path(project,"MODIS_windows_reviewed.csv"),
                       stringsAsFactors=FALSE,check.names=FALSE)
  contracts <- read.csv(file.path(project,"output_contracts.csv"),
                         stringsAsFactors=FALSE,check.names=FALSE)
  LakeEnsemblR::ler_window_control(windows,contracts,seed=seed,save_series=save_series)
}

ler_probe_project <- function(project, library_dir, spin_up_days,
                              output_dir, models=c("FLake","GLM","GOTM","Simstrat","MyLake")) {
  ler_load_window_library(library_dir)
  control <- ler_project_control(project)
  LakeEnsemblR::ler_window_probe("LakeEnsemblR.yaml",window=control,model=models,
                                 folder=project,spin_up=spin_up_days,out_dir=output_dir)
}

ler_calibrate_project <- function(project, library_dir, spin_up_days,
                                  output_dir, num=20L, parallel=FALSE,ncores=2L,
                                  seed=20261013L,save_series=TRUE,param_file=NULL,
                                  models=c("FLake","GLM","GOTM","Simstrat","MyLake")) {
  ler_load_window_library(library_dir)
  control <- ler_project_control(project,seed,save_series)
  # Contracts must already be confirmed from native files/metadata and probe evidence.
  fit <- LakeEnsemblR::cali_ensemble("LakeEnsemblR.yaml",window=control,model=models,
    folder=project,spin_up=spin_up_days,out_f=output_dir,num=num,param_file=param_file,
    parallel=parallel,ncores=ncores)
  final <- LakeEnsemblR::evaluate_window_best(fit$run_dir,tolerance_celsius=1e-6)
  invisible(list(fit=fit,final=final))
}
