# v0.2.0 标注版改动边界

详见 `docs/相对官方代码的修改清单.md`、`diff/official_to_window.patch`。搜索 `[LER-WINDOW` 即可定位新增/修改标记。

官方原 `cali_ensemble` 函数体与默认参数保留；其文本经过 deparse 排版，保留检查针对执行表达式。其余官方原 R 文件逐字不变。模型方程、求解器二进制与原输出读取器不变。
