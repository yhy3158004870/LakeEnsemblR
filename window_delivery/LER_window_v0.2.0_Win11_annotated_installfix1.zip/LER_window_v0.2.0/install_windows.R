# [LER-WINDOW NEW SUPPORT FILE] This entire support script is absent from official LER.
# UTF-8. Rscript install_windows.R --lib "D:/LER/library_v020"
# R console: source("D:/LER/bundle/install_windows.R", encoding="UTF-8")
#            ler_install_windows(lib="D:/LER/library_v020")
.ler_install_script_file <- local({
  files <- unlist(lapply(sys.frames(), function(x) if (!is.null(x$ofile)) x$ofile else NULL), use.names = FALSE)
  if (length(files)) tail(files, 1L) else {
    arg <- commandArgs(trailingOnly = FALSE)
    hit <- arg[startsWith(arg, "--file=")]
    if (length(hit)) sub("^--file=", "", hit[1L]) else "install_windows.R"
  }
})
.ler_install_bundle <- normalizePath(dirname(.ler_install_script_file), winslash = "/", mustWork = TRUE)
source(file.path(.ler_install_bundle, "tools", "windows_helpers.R"), local = TRUE, encoding = "UTF-8")

ler_install_windows <- function(lib = NULL, bundle_dir = .ler_install_bundle,
                                cran = "https://cloud.r-project.org", offline = FALSE,
                                allow_source_cran = FALSE, cran_cache = NULL) {
  if (.Platform$OS.type != "windows") .ler_stop("此脚本用于 Windows；Linux 验证不能替代 Win11 本机验收。")
  if (getRversion() < "4.1.0") .ler_stop("需要 R >= 4.1，建议使用当前受 CRAN 二进制支持的 64 位 R。")
  if (.Machine$sizeof.pointer != 8L) .ler_stop("需要 64 位 R。现代 R 的 r_arch 可为空，不用它判断 64 位。")
  if (grepl("aarch64|arm64", R.version$arch, ignore.case = TRUE))
    .ler_stop("本交付尚未验证 Windows ARM64 或 x64 模拟运行，请在 Win11 x64 上使用。")
  if (length(offline) != 1L || is.na(offline) || !is.logical(offline) ||
      length(allow_source_cran) != 1L || is.na(allow_source_cran) || !is.logical(allow_source_cran))
    .ler_stop("offline/allow_source_cran 必须为 TRUE 或 FALSE。")
  if (!grepl("^https://", cran)) .ler_stop("CRAN 镜像必须使用 HTTPS。")
  root <- .ler_path(bundle_dir)
  manifest <- .ler_vendor_manifest(root)
  src_desc <- .ler_read_description(file.path(root, "src", "LakeEnsemblR-window", "DESCRIPTION"))
  if (!identical(src_desc$Package, "LakeEnsemblR")) .ler_stop("随包源码的包名错误。")
  main_archive <- file.path(root, "src", paste0("LakeEnsemblR_", src_desc$Version, ".tar.gz"))
  if (!file.exists(main_archive)) .ler_stop("缺少随包 LakeEnsemblR 安装归档: ", basename(main_archive))
  # The release-wide SHA256SUMS is mandatory; verify only the exact main archive entry here.
  checksum_lines <- readLines(file.path(root, "SHA256SUMS.txt"), warn = FALSE, encoding = "UTF-8")
  checksum_paths <- sub("^[[:xdigit:]]{64}[[:space:]]+[*]?", "", checksum_lines)
  main_relative <- paste0("src/", basename(main_archive))
  hit <- which(checksum_paths == main_relative)
  if (length(hit) != 1L) .ler_stop("SHA256SUMS 中缺少唯一主包归档摘要。")
  .ler_verify_file(main_archive, substr(checksum_lines[hit], 1L, 64L))
  r_minor <- paste(R.version$major, strsplit(R.version$minor, ".", fixed = TRUE)[[1L]][1L], sep = ".")
  if (is.null(lib)) lib <- file.path(Sys.getenv("LOCALAPPDATA", unset = path.expand("~")),
                                    "LakeEnsemblR-window", paste0("R-", r_minor), paste0("library-", src_desc$Version))
  lib <- .ler_path(path.expand(lib), must_work = FALSE)
  if (dir.exists(lib) && length(list.files(lib, all.files = TRUE, no.. = TRUE)))
    .ler_stop("安装库必须为空；为保护原环境不会覆盖已有包。请选择新的 --lib 目录: ", lib)
  if (any(vapply(setdiff(loadedNamespaces(), "base"), function(p) !is.null(getNamespaceInfo(asNamespace(p), "path")) &&
                 startsWith(tolower(getNamespaceInfo(asNamespace(p), "path")), paste0(tolower(lib), "/")), logical(1))))
    .ler_stop("目标库中的包已经加载；请重启 R 并选择空库。")
  if (is.null(cran_cache)) cran_cache <- file.path(root, "vendor", "windows-cran-cache", paste0("R-", r_minor))
  cran_cache <- .ler_path(path.expand(cran_cache), must_work = FALSE)
  temp <- tempfile("LER_windows_install_"); dir.create(temp)
  on.exit(unlink(temp, recursive = TRUE), add = TRUE)
  descriptions <- list(LakeEnsemblR = src_desc)
  archive_paths <- setNames(character(nrow(manifest)), manifest$package)
  for (i in seq_len(nrow(manifest))) {
    path <- .ler_relative_file(root, manifest$archive[i], must_work = FALSE)
    if (!file.exists(path)) {
      if (offline) .ler_stop("离线模式缺少源归档: ", manifest$archive[i])
      dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
      message("下载固定提交: ", manifest$package[i], " @ ", manifest$commit[i])
      status <- utils::download.file(manifest$url[i], path, method = "libcurl", mode = "wb", quiet = FALSE)
      if (status != 0L) .ler_stop("源归档下载失败。")
    }
    .ler_verify_file(path, manifest$sha256[i])
    d <- .ler_archive_description(path, file.path(temp, manifest$package[i]))
    if (!identical(d$Package, manifest$package[i]) || !identical(d$Version, manifest$version[i]))
      .ler_stop("源归档包名/版本不匹配: ", manifest$package[i])
    actual_compile <- if (is.null(d$NeedsCompilation)) "no" else tolower(d$NeedsCompilation)
    if (!identical(actual_compile, manifest$needs_compilation[i])) .ler_stop("NeedsCompilation 与 manifest 不一致。")
    descriptions[[d$Package]] <- d; archive_paths[[d$Package]] <- path
  }
  main_d <- .ler_archive_description(main_archive, file.path(temp, "main"))
  if (!identical(main_d$Package, src_desc$Package) || !identical(main_d$Version, src_desc$Version))
    .ler_stop("完整源码目录与主包归档版本不一致。")
  descriptions$LakeEnsemblR <- main_d
  base_db <- installed.packages(lib.loc = .Library, priority = c("base", "recommended"))
  base_names <- c("R", rownames(base_db))
  direct <- unique(unlist(lapply(descriptions, function(d) .ler_dependencies(d)$package)))
  # testthat supports the unchanged upstream tests; knitr is the declared VignetteBuilder.
  direct <- setdiff(unique(c(direct, "testthat", "knitr")), c(names(descriptions), base_names))
  cache_manifest <- file.path(cran_cache, "binary-manifest.csv")
  if (offline) {
    if (allow_source_cran) .ler_stop("离线模式只支持有摘要记录的 CRAN 二进制缓存；不隐式使用源包。")
    if (!file.exists(cache_manifest)) .ler_stop("离线模式缺少 CRAN 二进制缓存摘要表。先联网安装，或提供同 R 主次版本的完整缓存。")
    cached <- read.csv(cache_manifest, stringsAsFactors = FALSE)
    if (!all(c("package", "version", "file", "sha256") %in% names(cached)) || anyDuplicated(cached$package) || anyNA(cached))
      .ler_stop("CRAN 二进制缓存 manifest 无效。")
    # A plain DCF matrix avoids deserializing arbitrary language objects from an RDS cache.
    dbfile <- file.path(cran_cache, "PACKAGES-binary.dcf")
    if (!file.exists(dbfile)) .ler_stop("离线模式缺少 PACKAGES-binary.dcf。")
    db <- read.dcf(dbfile); rownames(db) <- db[, "Package"]
    source_names <- character()
  } else {
    if (!capabilities("libcurl")) .ler_stop("R 缺少 libcurl，无法用受验证 TLS 下载依赖。")
    db <- utils::available.packages(repos = cran, type = "win.binary")
    if (!nrow(db)) .ler_stop("当前 R 主次版本没有可用 CRAN Windows 二进制索引；请检查镜像或升级 R。")
    source_names <- character()
    if (allow_source_cran) {
      source_db <- utils::available.packages(repos = cran, type = "source")
      source_names <- setdiff(rownames(source_db), rownames(db))
      if (length(source_names)) {
        extra <- matrix(NA_character_, nrow = length(source_names), ncol = ncol(db),
                        dimnames = list(source_names, colnames(db)))
        common <- intersect(colnames(db), colnames(source_db))
        extra[, common] <- source_db[source_names, common, drop = FALSE]
        db <- rbind(db, extra)
      }
    }
  }
  resolve <- function(roots) {
    deps <- tools::package_dependencies(roots, db = db, which = c("Depends", "Imports", "LinkingTo"), recursive = TRUE)
    planned <- setdiff(unique(c(roots, unlist(deps, use.names = FALSE))), c(names(descriptions), base_names))
    missing <- setdiff(planned, rownames(db))
    if (length(missing)) .ler_stop("CRAN 缺少所需兼容包: ", paste(missing, collapse = ", "),
                                 "。默认不改用源包；可升级 R 或显式 allow_source_cran=TRUE。")
    planned
  }
  planned <- resolve(direct)
  source_planned <- intersect(planned, source_names)
  source_compile <- if (length(source_planned)) source_planned[!is.na(db[source_planned, "NeedsCompilation"]) &
                                                               db[source_planned, "NeedsCompilation"] == "yes"] else character()
  vendor_compile <- manifest$package[manifest$needs_compilation == "yes"]
  requires_build <- length(c(source_compile, vendor_compile)) > 0L
  if (offline && requires_build) .ler_stop("离线模式不能准备新增的编译工具链；此依赖组合需要先联网验收。")
  if (requires_build) planned <- resolve(c(direct, "pkgbuild"))
  cran_descriptions <- setNames(lapply(planned, function(p) as.list(db[p, ])), planned)
  all_descriptions <- c(descriptions, cran_descriptions)
  versions <- c(R = as.character(getRversion()), setNames(base_db[, "Version"], rownames(base_db)),
                vapply(all_descriptions, function(d) d$Version, character(1)))
  for (d in all_descriptions) {
    requirements <- .ler_dependencies(d)
    for (j in seq_len(nrow(requirements))) {
      name <- requirements$package[j]
      if (!name %in% names(versions) || !.ler_version_satisfies(versions[[name]], requirements$operator[j], requirements$version[j]))
        .ler_stop("依赖版本不满足 ", d$Package, ": ", name, " ", requirements$operator[j], " ", requirements$version[j])
    }
  }
  order <- .ler_topological_order(all_descriptions, external = base_names)
  # Install VignetteBuilder/test tools as well as Imports before the derived main package.
  order <- c(setdiff(order, "LakeEnsemblR"), "LakeEnsemblR")
  if (offline) {
    missing <- setdiff(planned, cached$package)
    if (length(missing)) .ler_stop("离线缓存不完整: ", paste(missing, collapse = ", "))
    for (p in planned) {
      row <- cached[cached$package == p, ]
      if (!identical(row$version, db[p, "Version"])) .ler_stop("离线缓存版本与索引不一致: ", p)
      .ler_verify_file(.ler_relative_file(cran_cache, row$file), row$sha256)
    }
  }
  dir.create(lib, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(lib) || file.access(lib, 2L) != 0L) .ler_stop("目标库不可写: ", lib)
  old_paths <- .libPaths(); .libPaths(c(lib, .Library), include.site = FALSE)
  on.exit(.libPaths(old_paths), add = TRUE)
  dir.create(cran_cache, recursive = TRUE, showWarnings = FALSE)
  log_dir <- file.path(lib, "_LER_install_records"); dir.create(log_dir)
  message("安装到独立库: ", lib, "\nCRAN 包数: ", length(planned), "；固定源包数: ", nrow(manifest), "。")
  if (requires_build) {
    # Install the binary build-check helper and its dependencies before checking a real C toolchain.
    checker <- unique(c("pkgbuild", unlist(tools::package_dependencies("pkgbuild", db = db,
                      which = c("Depends", "Imports", "LinkingTo"), recursive = TRUE), use.names = FALSE)))
    checker <- intersect(order, checker)
    if (any(checker %in% source_names)) .ler_stop("pkgbuild 本身没有兼容 Windows 二进制，请先升级 R。")
    utils::install.packages(checker, lib = lib, repos = cran, type = "win.binary", dependencies = FALSE,
                            destdir = cran_cache)
    if (!requireNamespace("pkgbuild", quietly = TRUE) || !pkgbuild::has_build_tools(debug = TRUE))
      .ler_stop("确需编译依赖但 Rtools 不可用。安装与 R 版本匹配的 Rtools 后，选择新的空库重试。")
  }
  for (p in order) {
    message("安装: ", p, " ", all_descriptions[[p]]$Version)
    if (p == "LakeEnsemblR") {
      utils::install.packages(main_archive, repos = NULL, lib = lib, type = "source", dependencies = FALSE)
    } else if (p %in% manifest$package) {
      utils::install.packages(archive_paths[[p]], repos = NULL, lib = lib, type = "source", dependencies = FALSE)
    } else if (offline) {
      row <- cached[cached$package == p, ]
      utils::install.packages(.ler_relative_file(cran_cache, row$file), repos = NULL, lib = lib,
                              type = "win.binary", dependencies = FALSE)
    } else {
      type <- if (p %in% source_names) "source" else "win.binary"
      utils::install.packages(p, repos = cran, lib = lib, type = type, dependencies = FALSE, destdir = cran_cache)
    }
    if (!file.exists(file.path(lib, p, "DESCRIPTION")) ||
        !identical(.ler_read_description(file.path(lib, p, "DESCRIPTION"))$Version, all_descriptions[[p]]$Version))
      .ler_stop("包未成功安装或版本与计划不一致: ", p, "。保留独立库供诊断；重试请选新空库。")
  }
  if (!offline) {
    write.dcf(db, file.path(cran_cache, "PACKAGES-binary.dcf"))
    # Keep only Windows binaries; source-fallback caches are intentionally not treated as offline-complete.
    binaries <- setdiff(planned, source_names)
    binary_manifest <- do.call(rbind, lapply(binaries, function(p) {
      file <- paste0(p, "_", db[p, "Version"], ".zip")
      path <- file.path(cran_cache, file)
      if (!file.exists(path)) .ler_stop("已安装依赖的缓存文件缺失: ", file)
      data.frame(package = p, version = db[p, "Version"], file = file, sha256 = .ler_sha256(path), stringsAsFactors = FALSE)
    }))
    write.csv(binary_manifest, cache_manifest, row.names = FALSE, fileEncoding = "UTF-8")
    artifacts <- do.call(rbind, lapply(planned, function(p) {
      type <- if (p %in% source_names) "source" else "win.binary"
      file <- paste0(p, "_", db[p, "Version"], if (type == "source") ".tar.gz" else ".zip")
      path <- file.path(cran_cache, file)
      if (!file.exists(path)) .ler_stop("安装后的 CRAN 归档缺失: ", file)
      data.frame(package = p, version = db[p, "Version"], type = type, file = file,
                 sha256 = .ler_sha256(path), stringsAsFactors = FALSE)
    }))
    write.csv(artifacts, file.path(log_dir, "cran-artifacts.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  } else {
    artifacts <- cached[match(planned, cached$package), c("package", "version", "file", "sha256"), drop = FALSE]
    artifacts$type <- "win.binary"
    write.csv(artifacts, file.path(log_dir, "cran-artifacts.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  }
  write.csv(installed.packages(lib.loc = lib)[, c("Package", "Version", "Built"), drop = FALSE],
            file.path(log_dir, "installed-packages.csv"), row.names = FALSE, fileEncoding = "UTF-8")
  writeLines(capture.output(sessionInfo()), file.path(log_dir, "sessionInfo.txt"), useBytes = TRUE)
  writeLines(c("# Run in a NEW R session:", paste0(".libPaths(c(", deparse(lib), ", .libPaths()))"),
               "library(LakeEnsemblR)", paste0("stopifnot(as.character(packageVersion('LakeEnsemblR')) == '", src_desc$Version, "')")),
             file.path(log_dir, "activate.R"), useBytes = TRUE)
  message("安装完成。请重启 R，运行 _LER_install_records/activate.R，再运行 windows_preflight.R。\n",
          "安装成功不等于五模型及真实项目已通过验收；Win11 本机仍需实际模型小试与串并行核对。")
  invisible(list(lib = lib, version = src_desc$Version, cran_cache = cran_cache, records = log_dir))
}

.ler_install_cli <- commandArgs(trailingOnly = FALSE)
.ler_install_is_cli <- any(startsWith(.ler_install_cli, "--file=")) &&
  identical(normalizePath(sub("^--file=", "", .ler_install_cli[startsWith(.ler_install_cli, "--file=")][1L]),
                          winslash = "/", mustWork = FALSE), normalizePath(.ler_install_script_file, winslash = "/", mustWork = FALSE)) &&
  !length(unlist(lapply(sys.frames(), function(x) if (!is.null(x$ofile)) x$ofile else NULL)))
if (.ler_install_is_cli) {
  args <- .ler_cli_options(commandArgs(trailingOnly = TRUE))
  if (isTRUE(args$help)) {
    cat("Rscript install_windows.R --lib D:/LER/library_v020 [--bundle PATH] [--cran https://cloud.r-project.org]\n",
        "  [--cran-cache PATH] [--offline] [--allow-source-cran]\n",
        "source('install_windows.R', encoding='UTF-8'); ler_install_windows(lib='D:/LER/library_v020')\n", sep = "")
  } else {
    if (!is.null(args$report)) .ler_stop("安装器不接受 --report；该选项用于预检。")
    ler_install_windows(lib = args$lib, bundle_dir = if (is.null(args$bundle)) .ler_install_bundle else args$bundle,
                        cran = if (is.null(args$cran)) "https://cloud.r-project.org" else args$cran,
                        cran_cache = args[["cran-cache"]], offline = isTRUE(args$offline),
                        allow_source_cran = isTRUE(args[["allow-source-cran"]]))
  }
}
