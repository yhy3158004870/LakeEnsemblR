# v0.2.0 (2026-10-13)

Derived package1.2.9.9002. Fixes installer AST/srcref, named-only window formal, legacy YAML reader compatibility, stable SHA256/runtime/snapshot audit, PSOCK data, deterministic candidate seeds, MyLake global state, FLake nonmidnight subdaily reader, Windows same-engine adapters and exit/log checks. Adds permanent failure audits, full Windows installer/source archives, pureR Wan six-table processing and local acceptance tests. No solver equation or engine binary modifications.

Metadata requiresR>=4.1, explicitly declares digest and the pre-existing purrr usage, standardizes originalGPL2 license notation; originalR source/defaults/body retained. Window objectives deliberately differ from old time-label objectives. See reports/VALIDATION_STATUS.md for tests and platform limits.

旧 Python 观测转换入口已由经过审核合约测试的 `tools/prepare_wan_windows.R` 取代，避免绕过新版本的数据摘要、逐行填补许可与审核依据检查。补丁重建器核对完整官方源码清单；常规安装无需重建补丁。
