# Recovery/reproduction utility. Source defines a function; it installs nothing.
# The current research library is read-only. Destination must not exist.
install_ler9003_sources_to_new_library <- function(
  delivery,
  new_library,
  base_library = paste0("D:/Geography/R/dissertation_LakeEnsemblR/LER_window/",
    "MyLake_v121_ordering_isolated_20261029/library_R4_6_mylake_v121_order9002")) {
  need <- function(ok, ...) if (!isTRUE(ok)) stop(..., call. = FALSE)
  delivery <- normalizePath(delivery, winslash = "/", mustWork = TRUE)
  base_library <- normalizePath(base_library, winslash = "/", mustWork = TRUE)
  new_library <- gsub("\\\\", "/", path.expand(new_library))
  need(grepl("^([A-Za-z]:/|/)", new_library) && !grepl("(^|/)\\.\\.(/|$)", new_library),
       "Use an absolute destination without '..' components")
  prospective <- normalizePath(new_library, winslash = "/", mustWork = FALSE)
  need(!startsWith(tolower(paste0(prospective, "/")), tolower(paste0(base_library, "/"))),
       "New library must be outside original library")
  need(!file.exists(new_library) && !dir.exists(new_library), "Use a NEW nonexistent library directory")
  need(!any(grepl("^00LOCK", list.files(base_library))), "Original library has an installation lock")
  need(requireNamespace("digest", quietly = TRUE), "Load the original isolated environment first")
  manifest <- utils::read.csv(file.path(delivery, "package_source_sha256.csv"), stringsAsFactors = FALSE)
  expected <- c(LakeEnsemblR = "1.2.9.9003", MyLakeR = "0.0.1.9002")
  archive <- file.path(delivery, manifest$file)
  sha <- function(p) digest::digest(file = p, algo = "sha256", serialize = FALSE)
  need(all(file.exists(archive)) && identical(unname(vapply(archive, sha, "")), manifest$sha256),
       "Delivered source archive hash mismatch")
  vendor <- utils::read.csv(file.path(delivery, "vendor", "manifest.csv"), stringsAsFactors = FALSE)
  vendor_archives <- file.path(delivery, vendor$archive)
  need(nrow(vendor) == 8L && !any(vendor$package %in% c("LakeEnsemblR", "MyLakeR")) &&
       all(file.exists(vendor_archives)) &&
       identical(unname(vapply(vendor_archives, sha, "")), vendor$sha256),
       "Pinned native-model/utility vendor archive hash mismatch")
  need(identical(as.character(utils::packageVersion("LakeEnsemblR", lib.loc = base_library)), expected[["LakeEnsemblR"]]) &&
       identical(as.character(utils::packageVersion("MyLakeR", lib.loc = base_library)), expected[["MyLakeR"]]),
       "Base library must be the verified current 9003/9002 environment")
  dir.create(new_library, recursive = TRUE)
  new_library <- normalizePath(new_library, winslash = "/", mustWork = TRUE)
  files <- list.files(base_library, full.names = TRUE, recursive = TRUE, all.files = TRUE, no.. = TRUE)
  files <- files[!dir.exists(files)]
  relative <- substring(files, nchar(base_library) + 2L)
  before <- unname(vapply(files, sha, ""))
  for (i in seq_along(files)) {
    target <- file.path(new_library, relative[i])
    dir.create(dirname(target), recursive = TRUE, showWarnings = FALSE)
    need(file.copy(files[i], target, copy.date = TRUE, overwrite = FALSE), "Copy failed: ", files[i])
  }
  need(identical(unname(vapply(file.path(new_library, relative), sha, "")), before), "Copied package bytes differ")
  need(identical(unname(vapply(files, sha, "")), before), "Original library changed during copy")
  records <- paste0(new_library, "_install_records")
  need(dir.create(records), "Cannot create fresh installation records")
  job <- list(library = new_library, archives = archive, expected = expected,
    vendor_archives = vendor_archives, vendor_expected = setNames(vendor$version, vendor$package),
    expected_functions = file.path(delivery, "LakeEnsemblR_9003_source_vs_installed_functions.csv"),
    receipt = file.path(records, "installation_verified.rds"))
  job_file <- file.path(records, "job.rds")
  saveRDS(job, job_file, version = 3L)
  child <- function(job_file) {
    job <- readRDS(job_file)
    .libPaths(c(job$library, .Library), include.site = FALSE)
    utils::install.packages(c(job$vendor_archives, job$archives), repos = NULL,
      type = "source", lib = job$library, dependencies = FALSE)
    versions <- vapply(names(job$expected), function(p) as.character(utils::packageVersion(p, lib.loc = job$library)), "")
    stopifnot(identical(versions, job$expected))
    vendor_versions <- vapply(names(job$vendor_expected), function(p)
      as.character(utils::packageVersion(p, lib.loc = job$library)), "")
    stopifnot(identical(vendor_versions, job$vendor_expected))
    ns <- asNamespace("LakeEnsemblR")
    expected_functions <- utils::read.csv(job$expected_functions, stringsAsFactors = FALSE)
    hash <- get(".lw_function_hash", ns)
    got <- vapply(expected_functions$function_name, function(p) hash(get(p, ns)), "")
    stopifnot(identical(unname(got), expected_functions$source_sha256))
    saveRDS(list(passed = TRUE, versions = versions, R = R.version.string,
      models_started = FALSE, library = job$library), job$receipt, version = 3L)
  }
  child_file <- file.path(records, "install_child.R")
  dump("child", child_file, envir = environment())
  cat("\nchild(commandArgs(trailingOnly=TRUE)[1L])\n", file = child_file, append = TRUE)
  rscript <- file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript")
  log <- file.path(records, "install_console.log")
  code <- system2(rscript, c("--vanilla", shQuote(child_file), shQuote(job_file)), stdout = log, stderr = log)
  need(identical(as.integer(code), 0L) && file.exists(job$receipt) && isTRUE(readRDS(job$receipt)$passed),
       "New-library installation failed; current library unchanged. Inspect: ", log)
  need(identical(unname(vapply(files, sha, "")), before), "Original library changed during installation")
  cat("LER9003_NEW_LIBRARY_SOURCE_INSTALL_VERIFIED_NO_MODELS_STARTED\n", new_library, "\n")
  invisible(new_library)
}
