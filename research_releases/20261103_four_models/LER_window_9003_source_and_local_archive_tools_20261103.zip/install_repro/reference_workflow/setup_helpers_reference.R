load_ler69_driver <-
function (driver_file) 
{
    if (!file.exists(driver_file)) {
        stop("Missing research driver: ", driver_file)
    }
    before <- Sys.getenv("LER69_LOAD_ONLY", unset = NA_character_)
    on.exit({
        if (is.na(before)) {
            Sys.unsetenv("LER69_LOAD_ONLY")
        } else {
            Sys.setenv(LER69_LOAD_ONLY = before)
        }
    }, add = TRUE)
    Sys.setenv(LER69_LOAD_ONLY = "1")
    env <- new.env(parent = .GlobalEnv)
    source(driver_file, local = env, encoding = "UTF-8")
    stopifnot(is.list(env$CFG), is.function(env$r69_main))
    env
}
enhance_acceptance <-
function (R69) 
{
    f <- R69$r69_acceptance
    b <- as.list(body(f))
    save <- quote(ctx$window$save_series <- TRUE)
    if (!identical(b[[2L]], save)) {
        body(f) <- as.call(append(b, list(save), after = 1L))
    }
    g <- R69$r69_compare_runs
    b <- as.list(body(g))
    native <- quote(for (j in seq_along(report)) {
        m <- as.character(report[[j]]$model)
        id <- as.character(report[[j]]$par_id)
        a <- readRDS(file.path(serial_fit$run_dir, "calibration", 
            m, id, "native_surface.rds"))
        z <- readRDS(file.path(parallel_fit$run_dir, "calibration", 
            m, id, "native_surface.rds"))
        r69_need(all(c("datetime", "temperature") %in% names(a)) && 
            identical(names(a), names(z)) && nrow(a) >= 2L, "Invalid full-series acceptance schema")
        times <- as.numeric(a$datetime)
        r69_need(all(is.finite(times)) && all(diff(times) > 0) && 
            identical(times, as.numeric(z$datetime)), paste(m, 
            id, "native times differ"))
        delta <- r69_compare_numeric(a$temperature, z$temperature, 
            tolerance, paste(m, id, "full native temperature"))
        report[[j]]$native_records <- nrow(a)
        report[[j]]$max_native_temperature_difference_celsius <- delta
    })
    if (!any(vapply(b, function(x) identical(x, native), logical(1)))) {
        stopifnot(identical(tail(b, 1L)[[1L]], quote(do.call(rbind, 
            report))))
        body(g) <- as.call(append(b, list(native), after = length(b) - 
            1L))
    }
    R69$r69_acceptance <- f
    R69$r69_compare_runs <- g
    invisible(R69)
}
