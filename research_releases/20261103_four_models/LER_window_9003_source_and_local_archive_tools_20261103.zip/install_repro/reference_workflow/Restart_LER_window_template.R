# Reference loader for the EXISTING verified Windows ISO directory.
# This is not an installer and never starts a model. Preserve the actual
# Restart_LER_window.R from the user's local snapshot when reproducing a run.
PROJECT <- "C:/Geography/R/dissertation_LakeEnsemblR"
ISO <- paste0("D:/Geography/R/dissertation_LakeEnsemblR/LER_window/",
              "MyLake_v121_ordering_isolated_20261029")
LIB <- normalizePath(file.path(ISO, "library_R4_6_mylake_v121_order9002"),
                     winslash = "/", mustWork = TRUE)
.libPaths(c(LIB, .Library), include.site = FALSE)
Sys.unsetenv("GLM_PATH")
library(LakeEnsemblR, lib.loc = LIB)
library(MyLakeR, lib.loc = LIB)
stopifnot(as.character(packageVersion("LakeEnsemblR")) == "1.2.9.9003",
          as.character(packageVersion("MyLakeR")) == "0.0.1.9002")
source(file.path(ISO, "setup_helpers.R"), encoding = "UTF-8")
R69 <- load_ler69_driver(file.path(ISO, "LER69.R"))
enhance_acceptance(R69)
CFG <- readRDS(file.path(ISO, "records", "research_cfg_template.rds"))
stopifnot(is.list(CFG), dir.exists(CFG$windows_dir), dir.exists(CFG$contracts_dir))
cat("REFERENCE_EXISTING_ISOLATED_ENVIRONMENT_READY_NO_MODELS_STARTED\n")
