# MyLake v1.2.1 negative-chemistry ordering backport validation

## Scope and provenance

This work used an independent copy of MyLakeR and did not modify the user
repository or the installed research environment.

- Original MyLakeR: commit
  `ff73fd0da38b9d372f3ff9a940d59a121aa12b88`, version 0.0.1.
- Official MyLake source: commit
  `d882070870bd0bd541376ee8b627282d3ae8d329`.
- Official evidence: `v12/MyLake_v12_1_note.pdf` and
  `v12/v12_1/solvemodel_v12_1b_ut.m`.
- Independent prototype: MyLakeR 0.0.1.9002 in
  `MyLakeR-official-strict` and `R-library-strict`.

The official v1.2.1 note identifies the mechanism: growth limitation was
calculated before convection, convection then changed the profiles, and the
stale rate could generate negative dissolved P and chlorophyll. It prescribes
moving growth-rate calculation after the temperature solution and consequent
convection and recalculating PAR there.

## Implemented change

The backport changes only the negative-chemistry ordering:

1. Keep the first light-extinction calculation because the temperature
   solver needs it.
2. Move PAR and the one-group phytoplankton growth calculation to immediately
   after temperature diffusion and the following convection.
3. Recalculate PAR extinction from the post-convection chlorophyll profile.
4. Use the one-group reduction of the official v1.2.1 conditional P limiter:
   calculate net growth first and replace only layers whose growth demand
   exceeds available P.
5. Materialize the configured constant settling velocity as a depth vector.
   This is algebraically identical to the old R code, which calculated a
   flexible vector and immediately overwrote every element with `Bio_par[9]`.

No earlier independently proposed `pmin`-at-application patch is present.
No other v1.2.1 features are claimed or included. In particular, this is not
a full v1.2.1 port: it does not port the revised convection routine and call
flags, frazil ice, the second phytoplankton group, DOC photodegradation, or
the separate radiation-attenuation correction.

The exact source diff is `Rlake_main_official_strict.diff`.

## Targeted original-failure validation

Each run used an untouched complete source case copied to a new directory.
Only the copied native configuration stop date was changed from 2016-01-01
to 1983-01-01. This gives 1,462 daily records and passes the known daze and
dulishihu failure positions with additional simulation time.

| Lake | Original candidate | Seed | Original error | Result | Minimum P | Minimum Chl |
|---|---:|---:|---|---|---:|---:|
| bangong | p0000003 | 54886741 | invalid polynomial coefficient | passed | 0.001589199 | 0.006791136 |
| daze | p0000001 | 64752573 | missing value where TRUE/FALSE needed | passed | 0.002528967 | 0.005777125 |
| dulishihu | p0000003 | 200171482 | invalid polynomial coefficient | passed | 0.001177816 | 0.004039959 |

All four audited arrays (`Tzt`, `Pzt`, `Chlzt`, and `lambdazt`) were finite
in all three runs. P and Chl contained zero negative cells. The original
three engine errors did not recur. The numerous captured warnings were the
paired Akima interpolation messages “collinear points” followed by
“success: collinearities reduced through jitter”; they were not model-state
failures.

## Targeted default-parameter validation

The same 1979-01-01 to 1983-01-01 validation was run for the three default
cases. All completed with finite arrays and no negative P or Chl cells.

| Lake | Backport P minimum | Backport Chl minimum | Original 1979–2016 P negative cells | Original full-period P minimum |
|---|---:|---:|---:|---:|
| bangong | 0.002081420 | 0.006711423 | 0 | 0.003078534 |
| daze | 0.002157818 | 0.005651121 | 38 | -0.137158682 |
| dulishihu | 0.001512907 | 0.004089053 | 69 | -0.262546273 |

The original values in the last two columns cover 1979–2016, while the
backport values cover the targeted 1979–1983 period. They document the known
original defect and the targeted correction; they are not a like-for-like
full-period performance comparison.

## Limits and next acceptance step

Optional 1979–2016 cloud runs were intentionally terminated before
completion. They produced no validation summary or state audit and are
excluded from the evidence. Their partial logs are retained only as an audit
trail in `validation/strict_full_candidate_*.log`, with status recorded in
`validation/full_runs_terminated_incomplete.txt`.

Before scientific production, the independent source package must be
reviewed and installed into a separate Windows library, then the three full
1979–2016 cases and the 69-lake serial/parallel acceptance workflow must be
completed. This targeted result supports proceeding to that acceptance; it
does not replace it.

## Evidence index

- `validation/targeted_summary.csv`
- `validation/default_targeted_summary.csv`
- `validation/source_package_evidence_manifest.csv`
- `validation/provenance.txt`
- `validation/strict_targeted/<lake>/validation_summary.csv`
- `validation/strict_targeted/<lake>/state_audit.csv`
- `validation/strict_targeted_defaults_retry/<lake>/validation_summary.csv`
- `validation/full_runs_terminated_incomplete.txt`
