# Complete standalone research driver, 2026-10-26. UTF-8.
# Edit the configuration immediately below; then use RStudio Source.
# No automatic installation, package/source repair or contract approval.
# Daily model output is scored against original MODIS observation windows.

# EDIT THIS CONFIGURATION BLOCK. Paths are for the user's Windows computer.
R69_PROJECT <- "C:/Geography/R/dissertation_LakeEnsemblR"
R69_LER_ROOT <- "/workspace/recovery/simstrat7-fix-20261026/isolated-tests-final/LER_window/Simstrat7_isolated_20261026"
R69_PATHS_RECORD <- file.path(R69_LER_ROOT, "records", "window_paths.rds")
R69_RECORDED_LIBRARY <- if (file.exists(R69_PATHS_RECORD)) {
  .r69_paths <- readRDS(R69_PATHS_RECORD)
  if (!is.list(.r69_paths) || is.null(.r69_paths$window_lib) ||
      length(.r69_paths$window_lib) != 1L || !nzchar(.r69_paths$window_lib)) {
    stop("Invalid LER_window installation record: ", R69_PATHS_RECORD, call. = FALSE)
  }
  as.character(.r69_paths$window_lib)
} else {
  # This fallback keeps the script inspectable away from the user's Windows
  # installation. On the user's computer the installation record should exist.
  file.path(R69_LER_ROOT, "library_R4_6_v020")
}
R69_CORES <- parallel::detectCores(logical = FALSE)
if (is.na(R69_CORES)) R69_CORES <- 2L

CFG <- list(
  # First run must be preflight. Use acceptance next; research only after all
  # 69 acceptance rows pass. "all" performs the same gates in one invocation.
  stage = "preflight", # preflight | protocol | acceptance | research | analysis | sensitivity | all
  lake_index = file.path(R69_PROJECT, "lake_joinWan_pts_70L.csv"),
  yaml_dir = file.path(R69_PROJECT, "yaml"),
  windows_dir = file.path(R69_PROJECT, "MODIS_windows_reviewed"),
  contracts_dir = file.path(R69_PROJECT, "output_contracts"),
  results_root = file.path("/workspace/recovery/simstrat7-fix-20261026/isolated-tests-final/LER_window", "runs/research/simstrat7_9003"),
  r_library = R69_RECORDED_LIBRARY,
  unset_external_glm_path = TRUE,
  # Keep the recorded library. Use "" only for a separately audited active RStudio library.
  required_package_version = "1.2.9.9003",
  models = c("FLake", "GLM", "GOTM", "Simstrat", "MyLake"),
  expected_lakes = 69L,
  # This delivery intentionally enforces daily output and the retained
  # two-parameter (wind_speed, swr) design; these are not runtime switches.
  num = 500L, # Baseline, not a claim of convergence. Paper used 2000.
  seed = 20261026L,
  parallel = TRUE,
  ncores = as.integer(max(2L, min(4L, R69_CORES - 1L))),
  spin_up_days = 0,
  use_yaml_spinup_manifest = TRUE,
  save_series = FALSE, # Candidate pairs retained; final best daily series retained by window API.
  min_success_fraction = 0.95,
  tolerance_celsius = 1e-6,
  serial_parallel_required = TRUE,
  serial_parallel_num = 3L,
  run_probe = TRUE, # One set/model, but over the entire YAML simulation period.
  resume = TRUE,
  simstrat_auto_protocol = TRUE,
  make_plots = TRUE,
  make_daily_plots = TRUE,
  plot_formats = c("png", "pdf"),
  dpi = 300,
  diagnostic_bootstrap_B = 0L, # Optional year-block descriptive CI; not parameter uncertainty.
  run_sensitivity = TRUE,
  # EDIT: supply the full path of the Python environment containing SALib.
  # Example: "C:/Users/YOUR_NAME/miniconda3/envs/ler-gsa/python.exe"
  python_exe = unname(Sys.which("python")),
  num_resamples = 100L,
  gsa_min_samples = 500L,
  gsa_metrics = c("RMSE", "NSE", "r", "bias"),
  gsa_failure_policy = "strict",
  gsa_conf_level = 0.95
)

# Embedded Python helper; do not edit this section.
R69_EMBEDDED_PYTHON <- c(
  "#!/usr/bin/env python3",
  "\"\"\"Given-data sensitivity analysis of *calibration* LHC results.",
  "",
  "R drives this helper; it never runs a lake model or reads validation predictions.",
  "Method: SALib delta.analyze(method=\"all\"), an independent U(0,1) dummy,",
  "bootstrap intervals and the Feldbauer-code dummy comparison. This is not a",
  "Saltelli A/B design and does not estimate Sobol total-order indices.",
  "\"\"\"",
  "",
  "from __future__ import annotations",
  "",
  "import argparse",
  "import csv",
  "import hashlib",
  "import importlib.metadata",
  "import json",
  "import math",
  "import os",
  "from pathlib import Path",
  "import sys",
  "import traceback",
  "import warnings",
  "",
  "",
  "SALIB_VERSION = \"1.5.1\"",
  "METRIC_ALIASES = {\"RMSE\": \"RMSE\", \"NSE\": \"NSE\", \"MAE\": \"MAE\",",
  "                  \"R\": \"r\", \"r\": \"r\", \"Bias\": \"bias\", \"bias\": \"bias\"}",
  "RESULT_FIELDS = [",
  "    \"lake\", \"model\", \"metric\", \"parameter\", \"is_dummy\", \"n_total\", \"n_analyzed\",",
  "    \"n_failed\", \"n_nonfinite_metric\", \"analysis_domain\", \"delta\", \"delta_conf\",",
  "    \"delta_lower\", \"delta_upper\", \"delta_filtered\", \"delta_sensitive\",",
  "    \"delta_dummy_upper\", \"S1\", \"S1_conf\", \"S1_lower\", \"S1_upper\", \"S1_filtered\",",
  "    \"S1_sensitive\", \"S1_dummy_upper\", \"estimate_outside_unit_interval\",",
  "    \"num_resamples\", \"conf_level\", \"analysis_seed\", \"dummy_seed\",",
  "]",
  "STATUS_FIELDS = [\"lake\", \"model\", \"metric\", \"status\", \"reason\", \"n_total\", \"n_failed\",",
  "                 \"n_nonfinite_metric\", \"n_analyzed\", \"analysis_domain\"]",
  "SUMMARY_FIELDS = [",
  "    \"lake\", \"model\", \"metric\", \"n_parameters\", \"n_analyzed\", \"analysis_domain\",",
  "    \"sum_real_raw_S1\", \"interaction_real_raw\", \"interaction_real_outside_unit_interval\",",
  "    \"sum_including_dummy_raw_S1\", \"interaction_including_dummy_raw\",",
  "    \"interaction_including_dummy_outside_unit_interval\", \"n_sensitive_delta\",",
  "    \"n_sensitive_S1\", \"top_delta_parameters\", \"n_top_delta_ties\",",
  "    \"essential_75_delta_parameters\", \"n_essential_75_delta\",",
  "    \"top_S1_parameters\", \"n_top_S1_ties\", \"essential_75_S1_parameters\",",
  "    \"n_essential_75_S1\",",
  "]",
  "",
  "",
  "def sha256(path):",
  "    h = hashlib.sha256()",
  "    with open(path, \"rb\") as stream:",
  "        for block in iter(lambda: stream.read(1024 * 1024), b\"\"):",
  "            h.update(block)",
  "    return h.hexdigest()",
  "",
  "",
  "def stable_seed(seed, *labels):",
  "    text = \"|\".join([str(seed), *(str(x) for x in labels)])",
  "    return int.from_bytes(hashlib.sha256(text.encode(\"utf-8\")).digest()[:8], \"big\") % 2147483646 + 1",
  "",
  "",
  "def runtime():",
  "    import numpy as np",
  "    import scipy",
  "    from SALib.analyze import delta",
  "    version = importlib.metadata.version(\"SALib\")",
  "    if version != SALIB_VERSION:",
  "        raise RuntimeError(f\"This reproducible helper requires SALib=={SALIB_VERSION}; found {version}\")",
  "    if not hasattr(np, \"trapezoid\"):",
  "        raise RuntimeError(\"SALib 1.5.1 delta.py requires NumPy>=2.0 (np.trapezoid)\")",
  "    return np, delta, {\"python\": sys.version.split()[0], \"SALib\": version,",
  "                       \"numpy\": np.__version__, \"scipy\": scipy.__version__}",
  "",
  "",
  "def read_csv(path):",
  "    with open(path, encoding=\"utf-8-sig\", newline=\"\") as stream:",
  "        reader = csv.DictReader(stream)",
  "        fields = reader.fieldnames or []",
  "        if not fields or len(fields) != len(set(fields)):",
  "            raise ValueError(f\"Missing/duplicate CSV column names: {path}\")",
  "        return fields, list(reader)",
  "",
  "",
  "def atomic_csv(path, fields, rows):",
  "    temporary = path.with_name(path.name + \".tmp\")",
  "    with open(temporary, \"w\", encoding=\"utf-8-sig\", newline=\"\") as stream:",
  "        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction=\"raise\")",
  "        writer.writeheader()",
  "        writer.writerows(rows)",
  "    os.replace(temporary, path)",
  "",
  "",
  "def atomic_json(path, value):",
  "    temporary = path.with_name(path.name + \".tmp\")",
  "    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding=\"utf-8\")",
  "    os.replace(temporary, path)",
  "",
  "",
  "def numeric(value, required=False):",
  "    try:",
  "        number = float(value)",
  "    except (TypeError, ValueError):",
  "        number = math.nan",
  "    if required and not math.isfinite(number):",
  "        raise ValueError(f\"Expected a finite numeric value, received {value!r}\")",
  "    return number",
  "",
  "",
  "def most_important(rows, index):",
  "    # Negative finite-sample estimates are retained in raw results. An essential",
  "    # group is defined only from positive dummy-filtered importance.",
  "    values = [(r[\"parameter\"], r[index + \"_filtered\"]) for r in rows",
  "              if not r[\"is_dummy\"] and r[index + \"_filtered\"] > 0]",
  "    if not values:",
  "        return \"\", 0, \"\", 0",
  "    values.sort(key=lambda x: (-x[1], x[0]))",
  "    maximum = values[0][1]",
  "    top = [name for name, value in values if value == maximum]",
  "    target = .75 * sum(value for _, value in values)",
  "    total = 0.",
  "    threshold = values[-1][1]",
  "    for _, value in values:",
  "        total += value",
  "        if total >= target:",
  "            threshold = value",
  "            break",
  "    # Include every parameter tied at the cutoff; never break ties arbitrarily.",
  "    essential = [name for name, value in values if value >= threshold]",
  "    return \";\".join(top), len(top), \";\".join(essential), len(essential)",
  "",
  "",
  "def run(args):",
  "    np, delta, versions = runtime()",
  "    metrics = [METRIC_ALIASES.get(x, x) for x in args.metrics.split(\",\") if x]",
  "    if not metrics or len(metrics) != len(set(metrics)):",
  "        raise ValueError(\"metrics must be nonempty and unique after alias mapping\")",
  "    if args.resamples < 2 or args.min_samples < 20 or not 0 < args.conf_level < 1:",
  "        raise ValueError(\"Need resamples>=2, min-samples>=20 and 0<conf-level<1\")",
  "    if args.seed < 1 or args.seed > 2147483646:",
  "        raise ValueError(\"seed must be in 1..2147483646\")",
  "",
  "    inputs = {key: Path(getattr(args, key)).resolve() for key in (\"params\", \"spec\", \"summary\")}",
  "    for path in inputs.values():",
  "        if not path.is_file():",
  "            raise FileNotFoundError(path)",
  "    source_hashes = {key: {\"file\": str(path), \"sha256\": sha256(path)} for key, path in inputs.items()}",
  "    configuration = {\"lake\": args.lake, \"model\": args.model, \"metrics\": metrics,",
  "                     \"resamples\": args.resamples, \"conf_level\": args.conf_level,",
  "                     \"min_samples\": args.min_samples, \"failure_policy\": args.failure_policy,",
  "                     \"seed\": args.seed, \"SALib_method\": \"all\", \"X_coordinates\": \"raw\",",
  "                     \"script_sha256\": sha256(Path(__file__).resolve()), \"versions\": versions,",
  "                     \"sources\": source_hashes}",
  "    fingerprint = hashlib.sha256(json.dumps(configuration, sort_keys=True).encode()).hexdigest()",
  "    out = Path(args.out).resolve()",
  "    receipt_path = out / \"receipt.json\"",
  "    if args.resume and receipt_path.is_file():",
  "        prior = json.loads(receipt_path.read_text(encoding=\"utf-8\"))",
  "        if prior.get(\"fingerprint\") == fingerprint and prior.get(\"complete\") is True:",
  "            products = prior.get(\"products\", {})",
  "            if products and all((out / name).is_file() and sha256(out / name) == value",
  "                                for name, value in products.items()):",
  "                print(json.dumps({\"status\": \"reused\", \"out\": str(out), \"fingerprint\": fingerprint}))",
  "                return",
  "        raise RuntimeError(f\"Existing GSA receipt/input/output mismatch at {out}; use a new research run directory\")",
  "    if out.exists() and any(out.iterdir()):",
  "        raise RuntimeError(f\"Nonempty sensitivity output without a reusable receipt: {out}\")",
  "    out.mkdir(parents=True, exist_ok=True)",
  "",
  "    p_fields, pools = read_csv(inputs[\"params\"])",
  "    s_fields, specs = read_csv(inputs[\"spec\"])",
  "    y_fields, summaries = read_csv(inputs[\"summary\"])",
  "    if not {\"name\", \"lower\", \"upper\", \"initial\", \"log\"}.issubset(s_fields):",
  "        raise ValueError(\"spec CSV lacks name/lower/upper/initial/log\")",
  "    names = [s[\"name\"] for s in specs]",
  "    if not names or len(names) != len(set(names)) or \"dummy\" in names or \"par_id\" in names:",
  "        raise ValueError(\"Invalid, duplicate or reserved sampled parameter names\")",
  "    if set(p_fields) != {\"par_id\", *names}:",
  "        raise ValueError(\"params CSV must contain exactly par_id and the sampled parameter names\")",
  "    if not {\"model\", \"par_id\", \"status\", *metrics}.issubset(y_fields):",
  "        raise ValueError(\"calibration_summary.csv lacks model/par_id/status or requested metric columns\")",
  "    parameter_ids = [row[\"par_id\"] for row in pools]",
  "    if not parameter_ids or any(not x for x in parameter_ids) or len(parameter_ids) != len(set(parameter_ids)):",
  "        raise ValueError(\"Empty/duplicate parameter pool IDs\")",
  "    selected_summary = [s for s in summaries if s[\"model\"] == args.model]",
  "    by_id = {s[\"par_id\"]: s for s in selected_summary}",
  "    if len(by_id) != len(selected_summary) or set(by_id) != set(parameter_ids):",
  "        raise ValueError(\"Parameter IDs and model-specific calibration summary IDs do not match exactly\")",
  "    summary_rows = [by_id[identity] for identity in parameter_ids]",
  "    X_real = np.array([[numeric(row[name], True) for name in names] for row in pools], dtype=float)",
  "    lower = np.array([numeric(s[\"lower\"], True) for s in specs])",
  "    upper = np.array([numeric(s[\"upper\"], True) for s in specs])",
  "    initial = np.array([numeric(s[\"initial\"], True) for s in specs])",
  "    if np.any(lower >= upper) or np.any(initial < lower) or np.any(initial > upper):",
  "        raise ValueError(\"Invalid parameter bounds/initial values\")",
  "    tolerance = 1e-10 * np.maximum(1., np.maximum(np.abs(lower), np.abs(upper)))",
  "    if np.any(X_real < lower - tolerance) or np.any(X_real > upper + tolerance):",
  "        raise ValueError(\"Pool contains values outside declared YAML sampling bounds\")",
  "    if np.any(np.ptp(X_real, axis=0) <= 0):",
  "        raise ValueError(\"A declared sampled parameter is constant; fixed values must not be in the LHC spec\")",
  "    n_total = len(pools)",
  "    success = np.array([s[\"status\"] == \"ok\" for s in summary_rows], dtype=bool)",
  "    n_failed = int((~success).sum())",
  "    dummy_seed = stable_seed(args.seed, args.lake, args.model, \"dummy\")",
  "    dummy = np.random.default_rng(dummy_seed).uniform(0., 1., n_total)",
  "    X_all = np.column_stack((X_real, dummy))",
  "    Y_all = {metric: np.array([numeric(s[metric]) for s in summary_rows]) for metric in metrics}",
  "    audit_fields = [\"par_id\", \"source_status\", *names, \"dummy\", *metrics]",
  "    audit = []",
  "    for i, row in enumerate(pools):",
  "        z = {\"par_id\": row[\"par_id\"], \"source_status\": summary_rows[i][\"status\"], \"dummy\": float(dummy[i])}",
  "        z.update({name: float(X_real[i, j]) for j, name in enumerate(names)})",
  "        z.update({metric: float(Y_all[metric][i]) if math.isfinite(float(Y_all[metric][i])) else \"NA\"",
  "                  for metric in metrics})",
  "        audit.append(z)",
  "    atomic_csv(out / \"inputs_all_candidates.csv\", audit_fields, audit)",
  "",
  "    results, statuses, case_summaries, warning_records = [], [], [], []",
  "    for metric in metrics:",
  "        Y = Y_all[metric]",
  "        finite = np.isfinite(Y)",
  "        n_nonfinite = int((success & ~finite).sum())",
  "        mask = success & finite",
  "        domain = \"full_declared_LHC_domain\" if bool(mask.all()) else \"conditional_on_success_and_finite_metric\"",
  "        status = {\"lake\": args.lake, \"model\": args.model, \"metric\": metric,",
  "                  \"n_total\": n_total, \"n_failed\": n_failed, \"n_nonfinite_metric\": n_nonfinite,",
  "                  \"n_analyzed\": int(mask.sum()), \"analysis_domain\": domain}",
  "        reason = None",
  "        if args.failure_policy == \"strict\" and n_failed:",
  "            reason = \"failed_candidates_present; strict analysis does not condition away model failures\"",
  "        elif args.failure_policy == \"strict\" and n_nonfinite:",
  "            reason = \"nonfinite_metric_present; strict analysis does not silently delete candidates\"",
  "        elif int(mask.sum()) < args.min_samples:",
  "            reason = f\"insufficient_finite_samples; require at least {args.min_samples}\"",
  "        elif np.ptp(Y[mask]) <= np.finfo(float).eps * max(1., float(np.max(np.abs(Y[mask])))) * 100:",
  "            reason = \"constant_or_numerically_constant_output_metric\"",
  "        elif np.any(np.ptp(X_real[mask], axis=0) <= 0):",
  "            reason = \"a_sampled_parameter_is_constant_in_the_retained_domain\"",
  "        if reason:",
  "            status.update(status=\"skipped\", reason=reason)",
  "            statuses.append(status)",
  "            continue",
  "",
  "        seed = stable_seed(args.seed, args.lake, args.model, metric, \"analysis\")",
  "        problem = {\"num_vars\": len(names) + 1, \"names\": names + [\"dummy\"],",
  "                   \"bounds\": [[float(lo), float(hi)] for lo, hi in zip(lower, upper)] + [[0., 1.]]}",
  "        try:",
  "            with warnings.catch_warnings(record=True) as caught:",
  "                warnings.simplefilter(\"always\")",
  "                answer = delta.analyze(problem, X_all[mask], Y[mask], num_resamples=args.resamples,",
  "                                       conf_level=args.conf_level, print_to_console=False, seed=seed,",
  "                                       y_resamples=int(mask.sum()), method=\"all\")",
  "            warning_records.extend({\"metric\": metric, \"message\": str(w.message)} for w in caught)",
  "            values = np.array([answer[k] for k in (\"delta\", \"delta_conf\", \"S1\", \"S1_conf\")], dtype=float)",
  "            if values.shape != (4, len(names) + 1) or not np.isfinite(values).all():",
  "                raise ValueError(\"nonfinite or incorrectly shaped sensitivity estimate\")",
  "            dummy_delta_upper = float(answer[\"delta\"][-1] + answer[\"delta_conf\"][-1])",
  "            dummy_S1_upper = float(answer[\"S1\"][-1] + answer[\"S1_conf\"][-1])",
  "            metric_rows = []",
  "            for j, parameter in enumerate(problem[\"names\"]):",
  "                d, dc, si, sc = (float(answer[k][j]) for k in (\"delta\", \"delta_conf\", \"S1\", \"S1_conf\"))",
  "                is_dummy = parameter == \"dummy\"",
  "                d_pass = (not is_dummy) and d - dc > dummy_delta_upper",
  "                s_pass = (not is_dummy) and si - sc > dummy_S1_upper",
  "                row = {\"lake\": args.lake, \"model\": args.model, \"metric\": metric,",
  "                       \"parameter\": parameter, \"is_dummy\": is_dummy,",
  "                       \"n_total\": n_total, \"n_analyzed\": int(mask.sum()), \"n_failed\": n_failed,",
  "                       \"n_nonfinite_metric\": n_nonfinite, \"analysis_domain\": domain,",
  "                       \"delta\": d, \"delta_conf\": dc, \"delta_lower\": d - dc, \"delta_upper\": d + dc,",
  "                       \"delta_filtered\": d if d_pass else 0., \"delta_sensitive\": d_pass,",
  "                       \"delta_dummy_upper\": dummy_delta_upper,",
  "                       \"S1\": si, \"S1_conf\": sc, \"S1_lower\": si - sc, \"S1_upper\": si + sc,",
  "                       \"S1_filtered\": si if s_pass else 0., \"S1_sensitive\": s_pass,",
  "                       \"S1_dummy_upper\": dummy_S1_upper,",
  "                       \"estimate_outside_unit_interval\": d < 0 or d > 1 or si < 0 or si > 1,",
  "                       \"num_resamples\": args.resamples, \"conf_level\": args.conf_level,",
  "                       \"analysis_seed\": seed, \"dummy_seed\": dummy_seed}",
  "                metric_rows.append(row)",
  "            results.extend(metric_rows)",
  "            real = [r for r in metric_rows if not r[\"is_dummy\"]]",
  "            sum_real = sum(r[\"S1\"] for r in real)",
  "            sum_all = sum(r[\"S1\"] for r in metric_rows)",
  "            top_d, top_dn, essential_d, essential_dn = most_important(metric_rows, \"delta\")",
  "            top_s, top_sn, essential_s, essential_sn = most_important(metric_rows, \"S1\")",
  "            case_summaries.append({",
  "                \"lake\": args.lake, \"model\": args.model, \"metric\": metric,",
  "                \"n_parameters\": len(names), \"n_analyzed\": int(mask.sum()), \"analysis_domain\": domain,",
  "                \"sum_real_raw_S1\": sum_real, \"interaction_real_raw\": 1. - sum_real,",
  "                \"interaction_real_outside_unit_interval\": not 0 <= 1. - sum_real <= 1,",
  "                \"sum_including_dummy_raw_S1\": sum_all, \"interaction_including_dummy_raw\": 1. - sum_all,",
  "                \"interaction_including_dummy_outside_unit_interval\": not 0 <= 1. - sum_all <= 1,",
  "                \"n_sensitive_delta\": sum(int(r[\"delta_sensitive\"]) for r in real),",
  "                \"n_sensitive_S1\": sum(int(r[\"S1_sensitive\"]) for r in real),",
  "                \"top_delta_parameters\": top_d, \"n_top_delta_ties\": top_dn,",
  "                \"essential_75_delta_parameters\": essential_d, \"n_essential_75_delta\": essential_dn,",
  "                \"top_S1_parameters\": top_s, \"n_top_S1_ties\": top_sn,",
  "                \"essential_75_S1_parameters\": essential_s, \"n_essential_75_S1\": essential_sn,",
  "            })",
  "            status.update(status=\"ok\", reason=\"\")",
  "        except (ValueError, np.linalg.LinAlgError, RuntimeError) as error:",
  "            status.update(status=\"failed_estimator\", reason=str(error))",
  "        statuses.append(status)",
  "",
  "    products = {\"sensitivity.csv\": (RESULT_FIELDS, results),",
  "                \"case_summary.csv\": (SUMMARY_FIELDS, case_summaries),",
  "                \"metric_status.csv\": (STATUS_FIELDS, statuses)}",
  "    for filename, (fields, rows) in products.items():",
  "        atomic_csv(out / filename, fields, rows)",
  "    atomic_json(out / \"warnings.json\", warning_records)",
  "    names_written = [*products, \"inputs_all_candidates.csv\", \"warnings.json\"]",
  "    receipt = {\"complete\": True, \"fingerprint\": fingerprint, \"configuration\": configuration,",
  "               \"products\": {name: sha256(out / name) for name in names_written},",
  "               \"method_notes\": [",
  "                   \"Only calibration LHC metrics are analyzed; no validation fit is used.\",",
  "                   \"Successful high-RMSE candidates are retained; no RMSE<20 truncation is imposed.\",",
  "                   \"X uses actual sampled values; rank-based partitioning handles monotone log sampling.\",",
  "                   \"delta_conf and S1_conf are confidence half-widths, not full interval widths.\",",
  "                   \"Dummy comparison is a heuristic noise screen, not a calibrated hypothesis test.\",",
  "                   \"Raw estimates and interaction residuals are not clipped into [0,1].\",",
  "                   \"interaction_real_raw excludes the independent dummy; the literal author R script includes it, also exported.\",",
  "                   \"Essential 75% groups use positive dummy-filtered importance and retain cutoff ties.\",",
  "               ]}",
  "    atomic_json(receipt_path, receipt)",
  "    print(json.dumps({\"status\": \"complete\", \"out\": str(out), \"metrics\": statuses,",
  "                      \"fingerprint\": fingerprint}, ensure_ascii=False))",
  "",
  "",
  "def main():",
  "    parser = argparse.ArgumentParser(description=__doc__)",
  "    parser.add_argument(\"--check\", action=\"store_true\", help=\"Read-only Python/SALib dependency check\")",
  "    for name in (\"params\", \"spec\", \"summary\", \"model\", \"lake\", \"out\"):",
  "        parser.add_argument(\"--\" + name)",
  "    parser.add_argument(\"--metrics\", default=\"RMSE,NSE,r,bias\")",
  "    parser.add_argument(\"--resamples\", type=int, default=100)",
  "    parser.add_argument(\"--conf-level\", type=float, default=.95)",
  "    parser.add_argument(\"--min-samples\", type=int, default=500)",
  "    parser.add_argument(\"--failure-policy\", choices=(\"strict\", \"succeeded_only\"), default=\"strict\")",
  "    parser.add_argument(\"--seed\", type=int, default=20261026)",
  "    parser.add_argument(\"--resume\", action=\"store_true\")",
  "    args = parser.parse_args()",
  "    try:",
  "        if args.check:",
  "            _, _, versions = runtime()",
  "            print(json.dumps({\"status\": \"ok\", \"versions\": versions,",
  "                              \"method\": \"SALib.delta.analyze(method=all)\"}))",
  "            return",
  "        if any(getattr(args, name) is None for name in (\"params\", \"spec\", \"summary\", \"model\", \"lake\", \"out\")):",
  "            parser.error(\"--params --spec --summary --model --lake --out are required\")",
  "        run(args)",
  "    except Exception as error:",
  "        print(f\"Sensitivity job failed: {error}\", file=sys.stderr)",
  "        if os.environ.get(\"LER_GSA_DEBUG\") == \"1\":",
  "            traceback.print_exc()",
  "        raise SystemExit(1) from error",
  "",
  "",
  "if __name__ == \"__main__\":",
  "    main()"
)

# ===== Bundled module: 00_main_support.R =====
# Orchestration only. Does not install packages or edit source/input projects.
r69_main_need <- function(ok, ...) {
  if (!isTRUE(ok)) stop(..., call. = FALSE)
}

r69_main_csv <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(x, path, row.names = FALSE, fileEncoding = "UTF-8", na = "")
  invisible(path)
}

r69_read_index <- function(path, expected = 69L) {
  r69_main_need(file.exists(path), "Lake index missing: ", path)
  raw <- readLines(path, warn = FALSE, encoding = "bytes")
  text <- NULL
  for (enc in c("UTF-8", "GB18030")) {
    z <- iconv(raw, from = enc, to = "UTF-8", sub = NA)
    if (!anyNA(z)) { text <- z; break }
  }
  r69_main_need(!is.null(text), "Cannot decode lake index as UTF-8/GB18030")
  text[1L] <- sub("^\ufeff", "", text[1L])
  con <- textConnection(text); on.exit(close(con), add = TRUE)
  x <- utils::read.csv(con, stringsAsFactors = FALSE, check.names = FALSE,
                       colClasses = "character", na.strings = c("", "NA"))
  r69_main_need(all(c("name", "NAME_ID") %in% names(x)), "Lake index needs name and NAME_ID")
  r69_main_need(nrow(x) == expected, "Expected ", expected, " lakes; index contains ", nrow(x))
  r69_main_need(!anyNA(x$name) && all(grepl("^[A-Za-z0-9][A-Za-z0-9_-]*$", x$name)) &&
                  !anyDuplicated(tolower(x$name)), "Invalid or duplicate lake names")
  id <- suppressWarnings(as.numeric(x$NAME_ID))
  r69_main_need(all(is.finite(id) & id > 0 & id == floor(id)) && !anyDuplicated(id),
                "NAME_ID must contain unique positive integers")
  x$NAME_ID <- as.integer(id)
  x
}

r69_load_runtime <- function(cfg) {
  # Match the user's audited LER_window_open_env.R. An inherited GLM_PATH can
  # silently select a different executable than the one bundled with GLM3r.
  if (isTRUE(cfg$unset_external_glm_path)) Sys.unsetenv("GLM_PATH")
  if (!is.null(cfg$r_library) && nzchar(cfg$r_library)) {
    r69_main_need(dir.exists(cfg$r_library), "R library does not exist: ", cfg$r_library,
                  "; edit CFG$r_library or use an empty string for the active RStudio library")
    wanted <- normalizePath(cfg$r_library, winslash = "/", mustWork = TRUE)
    if (isNamespaceLoaded("LakeEnsemblR")) {
      loaded <- normalizePath(getNamespaceInfo(asNamespace("LakeEnsemblR"), "path"), winslash = "/")
      r69_main_need(identical(tolower(dirname(loaded)), tolower(wanted)),
                    "LakeEnsemblR is already loaded from ", loaded,
                    ". Restart RStudio's R session before changing its library.")
    }
    .libPaths(unique(c(wanted, .libPaths())))
  }
  packages <- c("LakeEnsemblR", "configr", "yaml", "digest", "jsonlite", "ncdf4")
  if (isTRUE(cfg$make_plots)) packages <- c(packages, "ggplot2")
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  r69_main_need(!length(missing), "Missing R packages: ", paste(missing, collapse = ", "),
                ". This workflow does not install packages automatically.")
  actual <- as.character(utils::packageVersion("LakeEnsemblR"))
  r69_main_need(identical(actual, cfg$required_package_version),
                "Expected LakeEnsemblR ", cfg$required_package_version, "; loaded ", actual)
  apis <- c("ler_window_control", "ler_window_probe", "cali_window_ensemble",
            "evaluate_window_best", "calc_fit_window", "ler_window_predict")
  r69_main_need(all(apis %in% getNamespaceExports("LakeEnsemblR")), "Window APIs missing")
  if (.Platform$OS.type == "windows" && !is.null(cfg$r_library) && nzchar(cfg$r_library)) {
    wrappers <- c("FLakeR", "GLM3r", "GOTMr", "SimstratR", "MyLakeR")
    missing_wrappers <- wrappers[!vapply(wrappers, requireNamespace, logical(1), quietly = TRUE)]
    r69_main_need(!length(missing_wrappers), "Missing model wrappers: ",
                  paste(missing_wrappers, collapse = ", "))
    wrapper_roots <- vapply(wrappers, function(p)
      dirname(normalizePath(find.package(p), winslash = "/", mustWork = TRUE)), character(1))
    bad <- wrappers[tolower(wrapper_roots) != tolower(wanted)]
    r69_main_need(!length(bad),
      "Model wrapper(s) loaded/found outside the recorded window library: ",
      paste(paste0(bad, "=", wrapper_roots[bad]), collapse = "; "),
      ". Restart RStudio and source LER_window_open_env.R before LER69.R.")
  }
  invisible(TRUE)
}

r69_prepare_embedded_python <- function(cfg) {
  if (!exists("R69_EMBEDDED_PYTHON", inherits = TRUE)) return(cfg)
  code <- paste(get("R69_EMBEDDED_PYTHON", inherits = TRUE), collapse = "\n")
  hash <- digest::digest(code, algo = "sha256", serialize = FALSE)
  dest <- file.path(cfg$results_root, "_scripts", paste0("delta_analysis_", substr(hash, 1, 16), ".py"))
  dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
  if (!file.exists(dest)) writeLines(code, dest, useBytes = TRUE)
  cfg$gsa_script <- normalizePath(dest, winslash = "/", mustWork = TRUE)
  cfg
}

r69_declared_design <- function(cfg, registry) {
  rows <- list(); errors <- list()
  ns <- asNamespace("LakeEnsemblR")
  for (i in seq_len(nrow(registry))) {
    name <- registry$name[i]
    path <- file.path(cfg$yaml_dir, paste0(name, "_LakeEnsemblR.yaml"))
    tryCatch({
      r69_main_need(file.exists(path), "Missing YAML: ", path)
      y <- configr::read.config(path)
      units <- c(second = 1, minute = 60, hour = 3600, day = 86400)
      unit <- as.character(y$output$time_unit)
      r69_main_need(length(unit) == 1L && unit %in% names(units), "Unsupported output time unit")
      requested <- as.numeric(y$output$time_step) * units[[unit]]
      r69_main_need(length(requested) == 1L && is.finite(requested) && requested == 86400,
                    "This research design requests daily model output; YAML does not request 86400 s")
      for (m in cfg$models) {
        spec <- get(".lw_specs", ns)(y, m)
        r69_main_need(nrow(spec) == 2L && setequal(spec$name, c("wind_speed", "swr")) &&
                        all(spec$type == "met"),
                      "Current design keeps Kw fixed and native calibration disabled; ", m,
                      " declares: ", paste(spec$name, collapse = ", "))
        for (j in seq_len(nrow(spec))) {
          specrow <- spec[j, , drop = FALSE]
          names(specrow)[names(specrow) == "name"] <- "parameter"
          rows[[length(rows) + 1L]] <- data.frame(name = name, model = m, specrow,
            yaml = normalizePath(path, winslash = "/"), requested_output_seconds = requested,
            stringsAsFactors = FALSE, check.names = FALSE)
        }
      }
      forbidden <- c("mixing/coef_mix_shreq", "sediment/sed_temp_mean", "sediment/sed_temp_amplitude")
      r69_main_need(!any(names(y$model_parameters$GLM) %in% forbidden),
                    "Three deferred GLM parameters are present as fixed model_parameters")
    }, error = function(e) {
      errors[[length(errors) + 1L]] <<- data.frame(name = name, error = conditionMessage(e))
    })
  }
  design_table <- if (length(rows)) do.call(rbind, rows) else data.frame(
    name = character(), model = character(), parameter = character(), type = character(),
    lower = numeric(), upper = numeric(), initial = numeric(), log = logical(),
    yaml = character(), requested_output_seconds = numeric())
  r69_main_csv(design_table, file.path(cfg$results_root, "current_input_parameter_design.csv"))
  error_table <- if (length(errors)) do.call(rbind, errors) else data.frame(name = character(), error = character())
  r69_main_csv(error_table, file.path(cfg$results_root, "declared_design_errors.csv"))
  if (length(errors)) {
    return(FALSE)
  }
  TRUE
}

r69_runtime_record <- function(cfg, registry) {
  directory <- file.path(cfg$results_root, "runtime")
  dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  stamp <- format(Sys.time(), "%Y%m%dT%H%M%SZ", tz = "UTC")
  capture.output(sessionInfo(), file = file.path(directory, paste0("session_", stamp, ".txt")))
  packages <- c("LakeEnsemblR", "FLakeR", "GLM3r", "GOTMr", "SimstratR", "MyLakeR",
                "digest", "ggplot2", "configr", "yaml")
  versions <- lapply(packages, function(p) data.frame(package = p,
    version = if (requireNamespace(p, quietly = TRUE)) as.character(utils::packageVersion(p)) else NA_character_,
    path = if (requireNamespace(p, quietly = TRUE)) find.package(p) else NA_character_))
  r69_main_csv(do.call(rbind, versions), file.path(directory, paste0("packages_", stamp, ".csv")))
  saveRDS(list(config = cfg, registry = registry, library_paths = .libPaths(), started_UTC = stamp),
          file.path(directory, paste0("invocation_", stamp, ".rds")))
}

r69_main <- function(cfg) {
  stages <- c("preflight", "protocol", "acceptance", "research", "analysis", "sensitivity", "all")
  r69_main_need(cfg$stage %in% stages, "CFG$stage must be one of ", paste(stages, collapse = ", "))
  dir.create(cfg$results_root, recursive = TRUE, showWarnings = FALSE)
  cfg$results_root <- normalizePath(cfg$results_root, winslash = "/", mustWork = TRUE)
  attempt_status <- "failed_or_interrupted"
  started_UTC <- format(Sys.time(), "%Y-%m-%d %H:%M:%S", tz = "UTC")
  attempt_file <- file.path(cfg$results_root, "workflow_latest_attempt.csv")
  r69_main_csv(data.frame(stage = cfg$stage, status = "running", started_UTC = started_UTC), attempt_file)
  on.exit(try(r69_main_csv(data.frame(stage = cfg$stage, status = attempt_status,
    started_UTC = started_UTC, finished_UTC = format(Sys.time(), "%Y-%m-%d %H:%M:%S", tz = "UTC")),
    attempt_file), silent = TRUE), add = TRUE)
  r69_load_runtime(cfg)
  cfg <- r69_prepare_embedded_python(cfg)
  registry <- r69_read_index(cfg$lake_index, cfg$expected_lakes)
  registry$spin_up_days <- cfg$spin_up_days
  manifest <- file.path(cfg$yaml_dir, "_yaml_manifest.csv")
  if (isTRUE(cfg$use_yaml_spinup_manifest) && file.exists(manifest)) {
    z <- utils::read.csv(manifest, stringsAsFactors = FALSE, fileEncoding = "UTF-8-BOM")
    r69_main_need(all(c("name", "spin_up_days") %in% names(z)) && !anyDuplicated(z$name),
                  "Invalid _yaml_manifest.csv")
    k <- match(registry$name, z$name)
    r69_main_need(!anyNA(k), "YAML manifest does not contain all selected lakes")
    spin <- suppressWarnings(as.numeric(z$spin_up_days[k]))
    r69_main_need(all(is.finite(spin) & spin >= 0), "Invalid spin-up days in YAML manifest")
    registry$spin_up_days <- spin
  }
  r69_runtime_record(cfg, registry)
  cat("LakeEnsemblR: ", as.character(utils::packageVersion("LakeEnsemblR")),
      "\nPackage path: ", find.package("LakeEnsemblR"),
      "\nLake count: ", nrow(registry), "\nStage: ", cfg$stage,
      "\nResults: ", cfg$results_root, "\n", sep = "")
  design_ok <- r69_declared_design(cfg, registry)
  if (cfg$stage == "protocol") {
    r69_main_need(exists("r69_simstrat_protocol_check", mode = "function"), "Protocol module missing")
    result <- r69_simstrat_protocol_check(cfg, list(name = registry$name[1L]))
    print(result)
    attempt_status <- if (isTRUE(result$passed)) "protocol_passed" else "protocol_failed"
    return(invisible(result))
  }
  global_issues <- character()
  if (!design_ok) global_issues <- c(global_issues,
    "Current YAML parameter/output design failed; see declared_design_errors.csv")
  if (cfg$stage %in% c("preflight", "research", "all") && isTRUE(cfg$run_sensitivity)) {
    gsa_error <- tryCatch({r69_gsa_preflight(cfg); ""}, error = function(e) conditionMessage(e))
    if (nzchar(gsa_error)) global_issues <- c(global_issues, paste("Sensitivity dependency:", gsa_error))
  }
  r69_main_csv(data.frame(problem = global_issues),
    file.path(cfg$results_root, "preflight", "global_issues.csv"))
  if (cfg$stage %in% c("preflight", "acceptance", "research", "all")) {
    if (length(global_issues) && cfg$stage != "preflight") {
      check_cfg <- cfg; check_cfg$stage <- "preflight"
      index <- r69_batch(check_cfg, registry)
      stop("Global checks failed; individual-lake checks were also recorded. No calibration started.\n",
           paste(global_issues, collapse = "\n"),
           "\nSee preflight/global_issues.csv and preflight/issues.csv.", call. = FALSE)
    }
    index <- r69_batch(cfg, registry)
    if (cfg$stage %in% c("preflight", "acceptance")) {
      attempt_status <- if (cfg$stage == "preflight" &&
                            (length(global_issues) || any(!index$preflight_passed)))
        "preflight_has_issues" else paste0(cfg$stage, "_finished")
      return(invisible(index))
    }
  } else {
    index_path <- file.path(cfg$results_root, "run_index.csv")
    r69_main_need(file.exists(index_path), "No run_index.csv; perform the research stage first")
    index <- utils::read.csv(index_path, stringsAsFactors = FALSE, check.names = FALSE)
  }
  diagnostic_result <- sensitivity_result <- daily_result <- NULL
  if (cfg$stage %in% c("research", "analysis", "all"))
    diagnostic_result <- collect_research_results(cfg, registry, index)
  if (is.list(diagnostic_result) && isTRUE(cfg$make_daily_plots))
    daily_result <- r69_daily_plots(cfg, registry, index, diagnostic_result)
  if (cfg$stage == "sensitivity" || (cfg$stage %in% c("research", "all") && isTRUE(cfg$run_sensitivity))) {
    r69_gsa_preflight(cfg)
    sensitivity_result <- r69_run_sensitivity(cfg, registry, index)
  }
  evaluations <- if ("evaluation_status" %in% names(index)) sum(index$evaluation_status == "ok", na.rm = TRUE) else 0L
  diagnostics_accepted <- if (is.list(diagnostic_result) && is.data.frame(diagnostic_result$coverage))
    sum(diagnostic_result$coverage$accepted_for_analysis %in% TRUE) else NA_integer_
  gsa_state <- if (is.list(sensitivity_result)) sensitivity_result$status else "not_requested"
  daily_state <- if (is.list(daily_result)) daily_result$status else "not_requested"
  status <- if (evaluations == nrow(registry) &&
    (is.na(diagnostics_accepted) || diagnostics_accepted == nrow(registry)) &&
    daily_state %in% c("complete", "not_requested") &&
    gsa_state %in% c("complete", "not_requested")) "requested_stages_complete" else "partial_or_skipped"
  r69_main_csv(data.frame(stage = cfg$stage, status = status, expected_lakes = nrow(registry),
    evaluation_ok_lakes = evaluations, diagnostics_accepted_lakes = diagnostics_accepted,
    sensitivity_status = gsa_state,
    daily_diagnostic_status = daily_state,
    diagnostic_report = if (is.list(diagnostic_result)) diagnostic_result$output_dir else "",
    sensitivity_report = if (is.list(sensitivity_result)) sensitivity_result$output_dir else "",
    UTC = format(Sys.time(), "%Y-%m-%d %H:%M:%S", tz = "UTC")),
    file.path(cfg$results_root, "workflow_summary.csv"))
  cat("Requested stages finished with status: ", status,
      ". Inspect workflow_summary.csv, run_index.csv and coverage tables.\n", sep = "")
  attempt_status <- status
  invisible(index)
}


# ===== Bundled module: 01_simstrat_protocol.R =====
# Simstrat native-initialization protocol diagnostic only.
# No package/source edits, no user-lake forcing, no calibration or contract approval.
# Called by the research driver; uses only private result directories.

r69_sim_need <- function(ok, ...) {
  if (!isTRUE(ok)) stop(..., call. = FALSE)
}

r69_sim_sha <- function(file) digest::digest(file = file, algo = "sha256")

r69_sim_manifest <- function(root) {
  root <- normalizePath(root, winslash = "/", mustWork = TRUE)
  files <- list.files(root, recursive = TRUE, full.names = TRUE,
                      all.files = TRUE, no.. = TRUE)
  files <- files[!dir.exists(files)]
  rel <- substring(files, nchar(root) + 2L)
  data.frame(file = rel, sha256 = unname(vapply(files, r69_sim_sha, character(1))),
             stringsAsFactors = FALSE)
}

r69_sim_cache_valid <- function(root, recorded) {
  if (!is.data.frame(recorded) || !all(c("file", "sha256") %in% names(recorded))) return(FALSE)
  all(vapply(seq_len(nrow(recorded)), function(i) {
    path <- file.path(root, recorded$file[i])
    file.exists(path) && identical(r69_sim_sha(path), recorded$sha256[i])
  }, logical(1)))
}

r69_sim_fixture <- function(folder) {
  dir.create(folder, recursive = TRUE, showWarnings = FALSE)
  # Geometry and forcing are synthetic diagnostic choices, not research priors.
  z_hyp <- -c(seq(0, 46, by = 1), 46.8)
  hyp <- data.frame(z = z_hyp, area = 1e6 * (pmax(0, 1 + z_hyp / 46.8)^2 + 1e-6))
  write.table(hyp, file.path(folder, "hypsograph.dat"), sep = "\t",
              row.names = FALSE, col.names = c("Depth [m]", "Area [m^2]"), quote = FALSE)
  z <- -c(0, 0.9, 2.5, 5, 8, 11, 14, 17, 20, 23, 27, 31, 35, 39, 43, 46.8)
  ini <- data.frame(Depth = z, U = 0, V = 0, T = 12,
                    S = 0, k = 3e-6, eps = 5e-10)
  met <- data.frame(time = seq(-1, 2, by = 1 / 24), U = 2, V = 0,
                    Tair = 10, SW = 100, vapour_hPa = 12, LW = 300, precip_m_h = 0)
  write.table(met, file.path(folder, "meteo_file.dat"), sep = "\t",
              row.names = FALSE, quote = FALSE)
  writeLines(c("Time [d] (1.col) z [m] (1.row) Absorption [m-1] (rest)",
               "1", "-1 -1.00", "-1 0.3", "2 0.3"),
             file.path(folder, "light_absorption.dat"))
  for (file in c("Qin.dat", "Qout.dat", "Tin.dat", "Sin.dat")) {
    writeLines(c("Time [d] diagnostic zero boundary", "0\t2", "-1\t-1.00\t0.00",
                 "-1\t0\t0", "2\t0\t0"), file.path(folder, file))
  }
  par <- list(
    Input = list("Initial conditions" = "init_cond.dat", Grid = 94,
                 Morphology = "hypsograph.dat", Forcing = "meteo_file.dat",
                 Absorption = "light_absorption.dat", Inflow = "Qin.dat",
                 Outflow = "Qout.dat", "Inflow temperature" = "Tin.dat",
                 "Inflow salinity" = "Sin.dat"),
    Output = list(Path = "output", Depths = 0.5, Times = 24,
                  OutputDepthReference = "surface", All = TRUE, Variables = list("T")),
    ModelConfig = list(MaxLengthInputData = 1000, CoupleAED2 = FALSE,
                       TurbulenceModel = 1, SplitSeicheParameter = FALSE,
                       StabilityFunction = 2, FluxCondition = 1, Forcing = 5,
                       UserDefinedWaterAlbedo = FALSE, UseFilteredWind = FALSE,
                       SeicheNormalization = 2, WindDragModel = 3, InflowMode = 0,
                       PressureGradients = 0, IceModel = 0, SnowModel = 0),
    Simulation = list("Timestep s" = 300, "Start year" = 2010, "Start d" = 0,
                      "End d" = 1, DisplaySimulation = 0,
                      "Continue from last snapshot" = FALSE),
    ModelParameters = list(lat = 45, p_air = 1013, a_seiche = 0.001,
                           a_seiche_w = 0, strat_sumr = 0, q_nn = 1,
                           f_wind = 1, c10 = 1, cd = 0.002, hgeo = 0.1,
                           k_min = 1e-9, p_sw_water = 1, p_lw = 1,
                           p_windf = 1, beta_sol = 0.3, wat_albedo = 0.08,
                           p_sw_ice = 1, freez_temp = 0, snow_temp = 1))
  jsonlite::write_json(par, file.path(folder, "simstrat.par"),
                       auto_unbox = TRUE, pretty = TRUE, digits = NA)
  ini
}

r69_sim_read <- function(file) {
  r69_sim_need(file.exists(file), "Missing protocol output: ", file)
  x <- utils::read.csv(file, check.names = FALSE, stringsAsFactors = FALSE)
  r69_sim_need(nrow(x) >= 2L && ncol(x) >= 6L, "Too little protocol output: ", file)
  times <- suppressWarnings(as.numeric(x[[1]]))
  depths <- suppressWarnings(as.numeric(names(x)[-1]))
  values <- suppressWarnings(as.matrix(data.frame(lapply(x[-1], as.numeric))))
  r69_sim_need(all(is.finite(times)) && all(is.finite(depths)) && all(is.finite(values)),
               "Nonfinite protocol data: ", file)
  r69_sim_need(abs(times[1]) <= 1e-8 && all(diff(times) > 0) &&
                 tail(times, 1) >= 1 - 1e-4,
               "Output must retain t=0 and cover the diagnostic day: ", file)
  list(times = times, depths = depths, values = values)
}

r69_sim_assess <- function(cases, run_status) {
  variables <- c("S", "k", "eps", "T", "U", "V")
  out <- list(); rows <- list(); six_read_error <- ""
  for (case in names(cases)) {
    status <- run_status$exit_status[run_status$case == case]
    if (length(status) != 1L || is.na(status) || status != 0L) next
    parsed <- tryCatch(setNames(lapply(variables, function(v)
      r69_sim_read(file.path(cases[[case]], "output", paste0(v, "_out.dat")))), variables),
      error = function(e) e)
    if (inherits(parsed, "error")) {
      if (case != "A_six") stop(parsed)
      six_read_error <- conditionMessage(parsed)
      next
    }
    out[[case]] <- parsed
    for (v in variables) {
      x <- out[[case]][[v]]; first <- x$values[1, ]; interior <- first[2:(length(first) - 1L)]
      rows[[length(rows) + 1L]] <- data.frame(case = case, variable = v,
        first_time_days = x$times[1], first_min = min(first), first_max = max(first),
        first_interior_min = min(interior), first_interior_max = max(interior),
        records = length(x$times), last_time_days = tail(x$times, 1),
        stringsAsFactors = FALSE)
    }
  }
  r69_sim_need(all(c("B_seven_zero", "C_seven_markers") %in% names(out)),
               "Seven-column diagnostic cases did not both finish successfully")
  interior <- function(case, v) {
    x <- out[[case]][[v]]$values[1, ]; x[2:(length(x) - 1L)]
  }
  close <- function(x, y, atol = 1e-14, rtol = 2e-4)
    length(x) > 0 && all(abs(x - y) <= atol + rtol * abs(y))
  expect <- list(B_seven_zero = c(S = 0, k = 3e-6, eps = 5e-10),
                 C_seven_markers = c(S = 0.125, k = 8e-6, eps = 2e-9))
  checks <- list()
  add <- function(test, passed, detail = "") {
    checks[[length(checks) + 1L]] <<- data.frame(test = test, passed = isTRUE(passed),
                                               detail = detail, stringsAsFactors = FALSE)
  }
  for (case in names(expect)) {
    for (v in names(expect[[case]]))
      add(paste(case, "t0", v), close(interior(case, v), expect[[case]][v]))
    for (v in c("U", "V")) add(paste(case, "t0", v), close(out[[case]][[v]]$values[1, ], 0))
    t <- out[[case]]$T
    add(paste(case, "t0 temperature profile"),
        close(t$values[1, ], 12, atol = 0.002, rtol = 0))
  }
  b <- out$B_seven_zero$T; c <- out$C_seven_markers$T
  same_grid <- identical(b$depths, c$depths) && identical(b$times, c$times)
  add("B/C comparable output grid and times", same_grid)
  add("B/C identical earliest temperature", same_grid &&
        close(b$values[1, ], c$values[1, ], atol = 1e-10, rtol = 0))
  a_status <- run_status$exit_status[run_status$case == "A_six"]
  if (length(a_status) == 1L && !is.na(a_status) && a_status != 0L) {
    add("Six-column negative control", TRUE,
        "Six-column file rejected. Acceptance still requires actual B/C t=0 field mapping above.")
  } else if (nzchar(six_read_error)) {
    add("Six-column negative control", TRUE,
        paste("Six-column run returned invalid/incomplete output:", six_read_error,
              "Acceptance still requires actual B/C t=0 field mapping."))
  } else if ("A_six" %in% names(out)) {
    shifted <- close(interior("A_six", "S"), 3e-6) &&
      close(interior("A_six", "k"), 5e-10)
    add("Six-column negative control", shifted,
        "Expected column shift: input column5 is read as S; column6 as k. Inspect eps and temperature outputs.")
  } else add("Six-column negative control", FALSE, "Six-column case result unavailable")
  checks <- do.call(rbind, checks)
  temp <- if (same_grid) data.frame(
    comparison = "B_zero_vs_C_markers", t0_max_abs_celsius = max(abs(b$values[1, ] - c$values[1, ])),
    final_max_abs_celsius = max(abs(tail(b$values, 1) - tail(c$values, 1))),
    all_max_abs_celsius = max(abs(b$values - c$values))) else data.frame()
  list(passed = all(checks$passed), checks = checks,
       summary = if (length(rows)) do.call(rbind, rows) else data.frame(),
       temperature_comparison = temp)
}

r69_simstrat_protocol_check <- function(cfg, ctx = NULL) {
  # This is independent of any user's output_contracts.csv or observation review.
  fail <- function(message, files = character())
    list(passed = FALSE, message = message, evidence_files = files)
  if (!isTRUE(cfg$simstrat_auto_protocol))
    return(fail("Automatic Simstrat protocol diagnostic is disabled"))
  for (p in c("LakeEnsemblR", "SimstratR", "digest", "jsonlite"))
    if (!requireNamespace(p, quietly = TRUE)) return(fail(paste("Missing protocol dependency", p)))
  if (.Platform$OS.type != "windows")
    return(fail("This protocol acceptance is for the actual Win11 engine; no Windows run was performed here"))
  exe <- system.file("extbin/win/simstrat_windows_301.exe", package = "SimstratR")
  if (!nzchar(exe) || !file.exists(exe)) return(fail("Bundled Windows Simstrat executable is missing"))
  ns <- asNamespace("LakeEnsemblR")
  if (!exists(".lw_run_engine", envir = ns, inherits = FALSE)) return(fail("Window engine adapter is missing"))
  adapter <- get(".lw_run_engine", ns)
  adapter_source <- paste(deparse(adapter, width.cutoff = 100L), collapse = "\n")
  if (!grepl("extbin/win/simstrat_windows_301.exe", adapter_source, fixed = TRUE))
    return(fail("Active window adapter has a different Simstrat path; protocol fixture needs review"))
  funs <- c("r69_sim_need", "r69_sim_sha", "r69_sim_manifest", "r69_sim_cache_valid",
            "r69_sim_fixture", "r69_sim_read", "r69_sim_assess", "r69_simstrat_protocol_check")
  code <- setNames(vapply(funs, function(n)
    digest::digest(paste(deparse(get(n, mode = "function")), collapse = "\n"),
                   algo = "sha256", serialize = FALSE), character(1)), funs)
  desc <- utils::packageDescription("SimstratR")
  getdesc <- function(n) if (is.null(desc[[n]])) NA_character_ else as.character(desc[[n]])
  identity <- list(schema = "research69-simstrat-seven-fields-v1", R = R.version.string,
    LakeEnsemblR_version = as.character(utils::packageVersion("LakeEnsemblR")),
    LakeEnsemblR_path = normalizePath(find.package("LakeEnsemblR"), winslash = "/"),
    SimstratR_version = as.character(utils::packageVersion("SimstratR")),
    SimstratR_path = normalizePath(find.package("SimstratR"), winslash = "/"),
    SimstratR_remote_sha = getdesc("RemoteSha"), SimstratR_remote_ref = getdesc("RemoteRef"),
    exe_path = normalizePath(exe, winslash = "/"), exe_sha256 = r69_sim_sha(exe),
    adapter_sha256 = digest::digest(adapter_source, algo = "sha256", serialize = FALSE),
    diagnostic_function_hashes = code)
  fingerprint <- digest::digest(identity, algo = "sha256")
  root <- file.path(cfg$results_root, "_protocol", "simstrat", identity$exe_sha256,
                    substr(fingerprint, 1, 16))
  receipt_path <- file.path(root, "protocol_receipt.rds")
  receipt_seal <- paste0(receipt_path, ".sha256")
  if (file.exists(receipt_path) && !isTRUE(cfg$protocol_force)) {
    if (!file.exists(receipt_seal) || !identical(
        trimws(readLines(receipt_seal, warn = FALSE)), r69_sim_sha(receipt_path)))
      return(fail("Simstrat protocol receipt checksum failed; preserve it and use a new research result root"))
    old <- tryCatch(readRDS(receipt_path), error = function(e) NULL)
    if (!is.null(old) && identical(old$identity_sha256, fingerprint) &&
        r69_sim_cache_valid(root, old$manifest)) {
      return(list(passed = isTRUE(old$passed), message = old$message,
                  evidence_files = file.path(root, c("protocol_receipt.rds", "protocol_receipt.rds.sha256",
                                                    old$manifest$file)),
                  engine_sha256 = identity$exe_sha256, identity_sha256 = fingerprint))
    }
    return(fail("Existing Simstrat protocol evidence was changed; preserve it and use a new research result root"))
  }
  if (dir.exists(root)) {
    if (!isTRUE(cfg$protocol_force)) return(fail("Incomplete protocol folder exists; use protocol_force or a new result root"))
    root <- paste0(root, "_retry_", format(Sys.time(), "%Y%m%dT%H%M%S"))
    receipt_path <- file.path(root, "protocol_receipt.rds")
    receipt_seal <- paste0(receipt_path, ".sha256")
  }
  dir.create(root, recursive = TRUE, showWarnings = FALSE)
  oldwd <- getwd(); on.exit(setwd(oldwd), add = TRUE)
  result <- tryCatch({
    jsonlite::write_json(identity, file.path(root, "engine_identity.json"),
                         auto_unbox = TRUE, pretty = TRUE, na = "null")
    writeLines(adapter_source, file.path(root, "actual_window_engine_adapter.R.txt"))
    for (n in c("run_simstrat", "run_simstratWin"))
      if (exists(n, asNamespace("SimstratR"), inherits = FALSE))
        writeLines(deparse(get(n, asNamespace("SimstratR"))),
                   file.path(root, paste0(n, ".R.txt")))
    capture.output(utils::sessionInfo(), file = file.path(root, "sessionInfo.txt"))
    writeLines(c("SYNTHETIC ONE-DAY NATIVE PROTOCOL DIAGNOSTIC ONLY",
      "No user-lake research forcing; no calibration; no output-contract approval.",
      "Only init_cond.dat differs between A/B/C. S=0 and marker S are diagnostic, not a research salinity policy.",
      "Times=24 is a recorded native setting. Actual output times are checked from files, not assumed."),
      file.path(root, "scope.txt"))
    common <- file.path(root, "common"); ini <- r69_sim_fixture(common)
    case_names <- c("A_six", "B_seven_zero", "C_seven_markers")
    cases <- setNames(character(length(case_names)), case_names)
    inputs <- list(); statuses <- list()
    for (case in case_names) {
      parent <- file.path(root, "cases", case); dir.create(parent, recursive = TRUE)
      native <- file.path(parent, "Simstrat"); dir.create(native)
      for (f in list.files(common, full.names = TRUE))
        r69_sim_need(file.copy(f, native, overwrite = FALSE), "Cannot copy diagnostic input ", f)
      x <- ini
      if (case == "A_six") x <- x[c("Depth", "U", "V", "T", "k", "eps")]
      if (case == "C_seven_markers") { x$S <- 0.125; x$k <- 8e-6; x$eps <- 2e-9 }
      write.table(x, file.path(native, "init_cond.dat"), sep = "\t", row.names = FALSE, quote = FALSE)
      m <- r69_sim_manifest(native); m$case <- case; inputs[[case]] <- m
      dir.create(file.path(native, "output"))
      cases[case] <- native
    }
    input_manifest <- do.call(rbind, inputs)
    utils::write.csv(input_manifest, file.path(root, "input_sha256.csv"), row.names = FALSE)
    shared <- lapply(inputs, function(m) m[m$file != "init_cond.dat", c("file", "sha256")])
    for (m in shared[-1]) r69_sim_need(identical(shared[[1]], m), "Non-init diagnostic inputs differ")
    for (case in case_names) {
      parent <- dirname(cases[[case]]); setwd(parent); started <- Sys.time(); err <- ""
      status <- tryCatch({
        adapter("Simstrat", list(config_files = list(Simstrat = "Simstrat/simstrat.par")))
        0L
      }, error = function(e) {
        err <<- conditionMessage(e)
        match <- regmatches(err, regexec("engine exit status (-?[0-9]+)", err))[[1]]
        if (length(match) >= 2L) as.integer(match[2]) else NA_integer_
      })
      statuses[[case]] <- data.frame(case = case, exit_status = status,
        elapsed_seconds = as.numeric(difftime(Sys.time(), started, units = "secs")),
        message = err, stringsAsFactors = FALSE)
      setwd(root)
    }
    run_status <- do.call(rbind, statuses)
    utils::write.csv(run_status, file.path(root, "run_status.csv"), row.names = FALSE)
    console <- unlist(lapply(cases, function(n) {
      file <- file.path(n, "engine_console.log")
      if (file.exists(file)) readLines(file, warn = FALSE) else character()
    }), use.names = FALSE)
    writeLines(unique(grep("version|simstrat", console, value = TRUE, ignore.case = TRUE)),
               file.path(root, "available_version_banner.txt"))
    assessment <- r69_sim_assess(cases, run_status)
    utils::write.csv(assessment$checks, file.path(root, "field_mapping_checks.csv"), row.names = FALSE)
    utils::write.csv(assessment$summary, file.path(root, "earliest_output_summary.csv"), row.names = FALSE)
    utils::write.csv(assessment$temperature_comparison,
                     file.path(root, "temperature_comparison.csv"), row.names = FALSE)
    list(passed = isTRUE(assessment$passed), message = if (isTRUE(assessment$passed))
      "Actual Windows engine seven-field mapping confirmed with one-day A/B/C outputs; per-lake seven-column export and output contracts still required"
      else "Simstrat t=0 marker mapping or negative-control checks failed; inspect protocol evidence")
  }, error = function(e) list(passed = FALSE, message = conditionMessage(e)))
  setwd(oldwd)
  writeLines(result$message, file.path(root, "protocol_result.txt"))
  record <- r69_sim_manifest(root)
  receipt <- c(result, list(identity_sha256 = fingerprint, identity = identity,
                            manifest = record, completed_UTC = format(Sys.time(), tz = "UTC", usetz = TRUE)))
  saveRDS(receipt, receipt_path)
  writeLines(r69_sim_sha(receipt_path), receipt_seal)
  list(passed = result$passed, message = result$message,
       evidence_files = file.path(root, c("protocol_receipt.rds", "protocol_receipt.rds.sha256", record$file)),
       engine_sha256 = identity$exe_sha256, identity_sha256 = fingerprint)
}


# ===== Bundled module: 02_runner.R =====
# Research69 runner for the installed LER_window 0.2.0 API.
# No package installation, source patching, input rewriting, or repository writes.
# The only engine work performed by these functions is explicitly requested
# probe / serial-parallel acceptance / calibration / final rerun work.

r69_opt <- function(cfg, key, default = NULL) {
  value <- cfg[[key]]
  if (is.null(value)) default else value
}
r69_need <- function(ok, ...) {
  if (!isTRUE(ok)) stop(..., call. = FALSE)
}
r69_private <- function(name) get(name, asNamespace("LakeEnsemblR"))
r69_sha <- function(path) digest::digest(file = path, algo = "sha256", serialize = FALSE)
r69_hash <- function(x) digest::digest(x, algo = "sha256", serialize = TRUE)
r69_csv <- function(path) {
  r69_need(file.exists(path) && !dir.exists(path), "Missing CSV: ", path)
  out <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE,
                         fileEncoding = "UTF-8-BOM")
  r69_need(!anyDuplicated(names(out)), "Duplicate CSV column names: ", path)
  out
}
r69_write_csv <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(x, path, row.names = FALSE, na = "NA", fileEncoding = "UTF-8")
  invisible(path)
}
r69_save_sealed <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  saveRDS(x, path, version = 3L)
  writeLines(r69_sha(path), paste0(path, ".sha256"), useBytes = TRUE)
  invisible(path)
}
r69_read_sealed <- function(path) {
  seal <- paste0(path, ".sha256")
  r69_need(file.exists(path) && file.exists(seal), "Missing stage receipt/seal: ", path)
  recorded <- readLines(seal, warn = FALSE)
  r69_need(length(recorded) == 1L && identical(recorded, r69_sha(path)),
           "Changed/incomplete stage receipt: ", path)
  readRDS(path)
}
r69_abs <- function(path) grepl("^(/|[A-Za-z]:[/\\\\]|\\\\\\\\)", path)
r69_resolve <- function(value, root, label, required = TRUE) {
  absent <- is.null(value) || length(value) != 1L || is.na(value) ||
    !nzchar(as.character(value)) || identical(as.character(value), "NULL")
  if (absent) {
    r69_need(!required, "Missing input: ", label)
    return(NULL)
  }
  r69_need(is.character(value), "Expected filename at ", label)
  path <- if (r69_abs(value)) value else file.path(root, value)
  r69_need(file.exists(path) && !dir.exists(path), "Missing ", label, ": ", path)
  normalizePath(path, winslash = "/", mustWork = TRUE)
}
r69_utc <- function(x, label = "UTC datetime") {
  r69_need(is.character(x) && length(x) == 1L && !is.na(x), label, " must be text")
  value <- as.POSIXct(strptime(x, "%Y-%m-%d %H:%M:%S", tz = "UTC"))
  r69_need(!is.na(value) && identical(format(value, "%Y-%m-%d %H:%M:%S", tz = "UTC"), x),
           label, " must use YYYY-mm-dd HH:MM:SS in UTC")
  value
}
r69_number <- function(x, label, positive = FALSE) {
  x <- suppressWarnings(as.numeric(x))
  r69_need(length(x) == 1L && is.finite(x) && (!positive || x > 0), "Invalid ", label)
  x
}
r69_seed <- function(seed, id) {
  # Stable by the actual Wan NAME_ID, never by incidental CSV row order.
  as.integer((as.double(seed) + 104729 * as.double(id)) %% 2147483646 + 1)
}

r69_runtime_fingerprint <- function(cfg) {
  required <- r69_opt(cfg, "required_package_version", "1.2.9.9003")
  r69_need(requireNamespace("LakeEnsemblR", quietly = TRUE), "LakeEnsemblR is not installed")
  r69_need(identical(as.character(utils::packageVersion("LakeEnsemblR")), required),
           "Expected LakeEnsemblR ", required, "; loaded ",
           as.character(utils::packageVersion("LakeEnsemblR")))
  apis <- c("ler_window_control", "ler_window_probe", "cali_window_ensemble",
            "evaluate_window_best", "calc_fit_window")
  r69_need(all(apis %in% getNamespaceExports("LakeEnsemblR")) &&
             "window" %in% names(formals(LakeEnsemblR::cali_ensemble)),
           "The loaded LakeEnsemblR package does not expose the window API")
  suppressPackageStartupMessages(library("LakeEnsemblR", character.only = TRUE))
  packages <- c("LakeEnsemblR", "FLakeR", "GLM3r", "GOTMr", "SimstratR", "MyLakeR",
                "glmtools", "gotmtools", "configr", "digest", "yaml")
  state <- r69_private(".lw_package_state")(packages)
  code <- vapply(c("export_init_cond", "cali_ensemble", "cali_window_ensemble",
                    "evaluate_window_best", ".lw_specs", ".lw_apply_native", ".lw_run_engine"),
                 function(n) r69_private(".lw_function_hash")(r69_private(n)), character(1))
  own_names <- c("r69_preflight", "r69_check_exported_sim_init", "r69_compare_runs",
                 "r69_acceptance", "r69_run_lake", "r69_verify_final", "r69_input_manifest",
                 "r69_batch")
  own_code <- vapply(own_names, function(n) r69_private(".lw_function_hash")(
    get(n, mode = "function", inherits = TRUE)), character(1))
  list(signature = r69_hash(list(state = state, functions = code, workflow_functions = own_code)), state = state,
       functions = code, workflow_functions = own_code,
       package_path = normalizePath(find.package("LakeEnsemblR"),
                                                       winslash = "/", mustWork = TRUE),
       library_paths = .libPaths(), schema = "research69-runner-20261026-v1")
}

r69_input_manifest <- function(ctx) {
  files <- ctx$input_files
  for (m in ctx$models) {
    directory <- file.path(ctx$project_dir, m)
    if (!dir.exists(directory)) next
    rel <- list.files(directory, recursive = TRUE, full.names = FALSE,
                      all.files = TRUE, no.. = TRUE)
    rel <- rel[!grepl("^output(/|$)", rel)]
    files <- c(files, file.path(directory, rel))
  }
  files <- sort(unique(files[file.exists(files) & !dir.exists(files)]))
  data.frame(file = normalizePath(files, winslash = "/", mustWork = TRUE),
             sha256 = vapply(files, r69_sha, character(1)), stringsAsFactors = FALSE)
}

r69_check_exported_sim_init <- function(cfg, ctx) {
  # This exports initialization only. It never starts the Simstrat engine and
  # never changes an original YAML, native template, or installed package.
  audit <- file.path(cfg$results_root, "preflight", "native_exports", ctx$name)
  dir.create(audit, recursive = TRUE, showWarnings = FALSE)
  work <- tempfile("installed_export_", tmpdir = audit)
  dir.create(work); dir.create(file.path(work, "Simstrat"))
  initial <- r69_resolve(ctx$config$input$init_temp_profile$file,
                         ctx$project_dir, "independent initial profile")
  r69_need(file.copy(initial, file.path(work, "initial_profile.csv")), "Could not copy diagnostic profile")
  invisible(LakeEnsemblR::get_template("Simstrat_config", folder = file.path(work, "Simstrat"),
    filename = "simstrat.par", overwrite = FALSE))
  native <- file.path(work, "Simstrat", "simstrat.par")
  r69_need(file.exists(native), "Cannot obtain the installed Simstrat template")
  master <- ctx$config
  master$input$init_temp_profile$file <- "initial_profile.csv"
  master$config_files$Simstrat <- "Simstrat/simstrat.par"
  config_file <- "installed_export_check.yaml"
  r69_private(".lw_write_config")(master, file.path(work, config_file))
  console <- file.path(work, "export_console.txt")
  capture.output(suppressMessages(LakeEnsemblR::export_init_cond(
    config_file, model = "Simstrat", print = FALSE, folder = work)), file = console)
  path <- file.path(work, "Simstrat", "init_cond.dat")
  r69_need(file.exists(path), "Installed export_init_cond did not create Simstrat/init_cond.dat")
  text <- readLines(path, warn = FALSE)
  header <- trimws(gsub("[[:space:]]*\\[.*$", "",
                       strsplit(text[1L], "\t", fixed = TRUE)[[1L]]))
  values <- utils::read.table(path, skip = 1L, header = FALSE, sep = "\t", check.names = FALSE)
  identity <- list(header = header, columns = ncol(values),
    initial_file_sha256 = r69_sha(path),
    export_init_cond_sha256 = r69_private(".lw_function_hash")(LakeEnsemblR::export_init_cond),
    evidence_file = normalizePath(path, winslash = "/", mustWork = TRUE))
  r69_save_sealed(identity, file.path(work, "export_identity.rds"))
  r69_need(identical(header, c("Depth", "U", "V", "T", "S", "k", "eps")) && ncol(values) == 7L,
    "Installed delivery exports ", ncol(values), " columns (", paste(header, collapse = ","),
    "); Simstrat requires Depth,U,V,T,S,k,eps. This is an installed-package initialization-export defect, ",
    "not a MODIS observation-processing error. No research run is started. Evidence: ", path)
  a <- as.matrix(values)
  r69_need(is.numeric(a) && all(is.finite(a)) && all(a[, 5L] == 0) &&
             all(a[, 6L] > 0) && all(a[, 7L] > 0),
           "Seven-column initialization must retain the declared freshwater S=0 and positive k/eps")
  profile <- r69_csv(initial)
  z <- signif(as.numeric(profile[[1L]]), 4L)
  temp <- signif(as.numeric(profile[[2L]]), 4L)
  if (z[1L] > 0.001) { z <- c(0, z); temp <- c(temp[1L], temp) }
  r69_compare_numeric(a[, 1L], -z, 1e-10, "Exported Simstrat depths")
  r69_compare_numeric(a[, 4L], temp, 1e-10, "Exported Simstrat temperatures")
  r69_need(all(a[, 2L] == 0) && all(a[, 3L] == 0), "Unexpected initial U/V; investigate before research")
  identity$passed <- TRUE
  identity
}

r69_preflight <- function(cfg, row, paths = NULL, require_confirmed = TRUE) {
  # Only project inputs are read. Audit files and any explicit protocol test
  # generated by the Simstrat hook live under cfg$results_root.
  r69_need(is.data.frame(row) && nrow(row) == 1L, "Supply one registry row")
  r69_need(all(c("name", "NAME_ID") %in% names(row)), "Registry needs name and NAME_ID")
  name <- as.character(row$name)
  r69_need(length(name) == 1L && !is.na(name) && grepl("^[A-Za-z0-9][A-Za-z0-9_-]*$", name),
           "Invalid lake name")
  id <- r69_number(row$NAME_ID, paste(name, "NAME_ID"), TRUE)
  r69_need(id == floor(id), "NAME_ID must be an integer: ", name)
  models <- as.character(cfg$models)
  r69_need(length(models) > 0L && !anyDuplicated(models) &&
             all(models %in% c("FLake", "GLM", "GOTM", "Simstrat", "MyLake")), "Invalid model list")
  project <- normalizePath(cfg$yaml_dir, winslash = "/", mustWork = TRUE)
  config_file <- paste0(name, "_LakeEnsemblR.yaml")
  yaml_path <- r69_resolve(config_file, project, "master YAML")
  master <- configr::read.config(yaml_path)
  r69_need(is.list(master) && all(c("location", "time", "input", "output", "config_files") %in% names(master)),
           name, ": not the expected LER master YAML schema")
  r69_need(identical(as.character(master$location$name), name), name, ": YAML location.name mismatch")
  start <- r69_utc(master$time$start, "time.start")
  end <- r69_utc(master$time$stop, "time.stop")
  r69_need(start < end, "time.start must precede time.stop")
  spin <- if ("spin_up_days" %in% names(row) && !is.na(row$spin_up_days) && nzchar(as.character(row$spin_up_days)))
    r69_number(row$spin_up_days, "spin_up_days") else r69_number(r69_opt(cfg, "spin_up_days", 0), "spin_up_days")
  r69_need(spin >= 0, "spin_up_days cannot be negative")
  depth <- r69_number(master$location$depth, "location.depth", TRUE)
  h <- r69_number(master$time$time_step, "time.time_step", TRUE)
  r69_need(as.character(master$output$time_unit) == "second" &&
             r69_number(master$output$time_step, "output.time_step", TRUE) == 86400,
           name, ": this workflow requests daily output: time_unit=second,time_step=86400")
  files <- c(yaml_path,
    r69_resolve(master$location$hypsograph, project, "hypsograph"),
    r69_resolve(master$input$init_temp_profile$file, project, "independent initial profile"),
    r69_resolve(master$input$meteo$file, project, "meteorological forcing"))
  walk <- function(x, prefix) {
    if (!is.list(x)) return(invisible(NULL))
    for (key in names(x)) {
      if (key == "file") {
        p <- r69_resolve(x[[key]], project, paste0(prefix, ".file"), required = FALSE)
        if (!is.null(p)) files <<- c(files, p)
      } else if (is.list(x[[key]])) walk(x[[key]], paste(prefix, key, sep = "."))
    }
  }
  walk(master$input, "input"); walk(master$observations, "observations")
  for (section in c("inflows", "outflows")) {
    p <- r69_resolve(master[[section]]$file, project, paste0(section, ".file"),
                    required = isTRUE(master[[section]]$use))
    if (!is.null(p)) files <- c(files, p)
  }
  kw <- master$input$light$Kw
  r69_need(!is.null(kw), "Missing input.light.Kw")
  check_kw <- function(value) {
    if (is.character(value)) files <<- c(files, r69_resolve(value, project, "Kw file"))
    else r69_number(value, "Kw", TRUE)
  }
  if (is.list(kw)) for (value in kw) check_kw(value) else check_kw(kw)
  init <- r69_csv(files[3L])
  r69_need(identical(names(init), c("Depth_meter", "Water_Temperature_celsius")) && nrow(init) >= 2L,
           name, ": initial profile must be the standard two-column profile")
  z <- suppressWarnings(as.numeric(init[[1L]])); temp <- suppressWarnings(as.numeric(init[[2L]]))
  r69_need(all(is.finite(z)) && all(is.finite(temp)) && all(z >= 0) && all(diff(z) > 0) && max(z) <= depth,
           name, ": invalid initial depths/temperatures")
  for (m in models) {
    cf <- master$config_files[[m]]
    r69_need(is.character(cf) && length(cf) == 1L && startsWith(cf, paste0(m, "/")) &&
               !grepl("(^|/)\\.\\.(/|$)", cf), "Unsafe/missing config_files.", m)
  }
  windows_file <- r69_resolve(paste0(name, "_MODIS_windows_reviewed.csv"), cfg$windows_dir, "reviewed windows")
  contracts_file <- r69_resolve(paste0(name, "_output_contracts.csv"), cfg$contracts_dir, "output contracts")
  seed <- r69_seed(r69_opt(cfg, "seed", 20261026L), id)
  window <- LakeEnsemblR::ler_window_control(windows_file, contracts_file, seed = seed,
                                             save_series = isTRUE(r69_opt(cfg, "save_series", FALSE)))
  w <- window$windows
  if ("name" %in% names(w)) r69_need(all(w$name == name), name, ": windows name mismatch")
  if ("NAME_ID" %in% names(w)) r69_need(all(as.numeric(w$NAME_ID) == id), name, ": windows NAME_ID mismatch")
  cal <- w[w$use & w$split == "calibration", , drop = FALSE]
  val <- w[w$use & w$split == "validation", , drop = FALSE]
  r69_need(nrow(cal) >= 2L && nrow(val) >= 2L, name, ": need at least two selected windows in each split")
  r69_need(all(cal$window_start >= r69_utc("2001-01-01 00:00:00") &
                 cal$window_end <= r69_utc("2011-01-01 00:00:00")), name, ": calibration windows must be 2001--2010")
  r69_need(all(val$window_start >= r69_utc("2011-01-01 00:00:00") &
                 val$window_end <= r69_utc("2016-01-01 00:00:00")), name, ": validation windows must be 2011--2015")
  selected <- rbind(cal, val)
  r69_need(all(selected$window_start >= start + spin * 86400 & selected$window_end <= end),
           name, ": selected windows exceed simulation/spin-up bounds")
  issues <- character()
  collect <- function(label, expr) tryCatch(expr, error = function(e) {
    issues <<- c(issues, paste0(label, ": ", conditionMessage(e))); NULL
  })
  contracts <- collect("contracts", r69_private(".lw_contracts")(
    window$contracts, models, require_confirmed = require_confirmed))
  if (!is.null(contracts)) {
    r69_need(!any(grepl("UNCONFIRMED|PROPOSED|TODO|待确认|未确认", contracts$meaning,
                        ignore.case = TRUE)),
             name, ": a confirmed contract still has provisional/unfinished meaning text")
    r69_need(all(contracts$step_seconds == 86400), name, ": confirmed contracts must describe daily output in this workflow")
    for (m in intersect(models, c("GLM", "Simstrat"))) {
      ratio <- contracts$step_seconds[contracts$model == m] / h
      r69_need(is.finite(ratio) && ratio >= 1 && abs(ratio - round(ratio)) <= 1e-8,
               name, ": daily output is not an integer multiple of integration step for ", m)
    }
  }
  expected <- r69_opt(cfg, "expected_parameter_names", c("wind_speed", "swr"))
  specs <- setNames(vector("list", length(models)), models)
  for (m in models) {
    specs[[m]] <- collect(paste0("parameters/", m), {
      spec <- r69_private(".lw_specs")(master, m)
      r69_need(setequal(spec$name, expected) && nrow(spec) == length(expected),
               "YAML calibration differs from the retained configuration; expected ", paste(expected, collapse = ","))
      r69_need(!any(spec$name %in% c("mixing/coef_mix_shreq", "sediment/sed_temp_mean", "sediment/sed_temp_amplitude")),
               "The three deferred GLM parameters must remain absent")
      spec
    })
  }
  collect("legacy YAML", r69_private(".lw_check_legacy_yaml")(master, yaml_path, models))
  wrappers <- c(FLake = "FLakeR", GLM = "GLM3r", GOTM = "GOTMr", Simstrat = "SimstratR", MyLake = "MyLakeR")
  for (m in models) collect(paste0("wrapper/", m), {
    r69_need(requireNamespace(wrappers[[m]], quietly = TRUE), "Missing installed wrapper ", wrappers[[m]])
  })
  if (isTRUE(r69_opt(cfg, "parallel", TRUE))) {
    cores <- r69_number(r69_opt(cfg, "ncores", 2L), "ncores", TRUE)
    r69_need(cores == floor(cores) && cores >= 2L, "Parallel production requires explicit ncores >= 2")
  }
  ctx <- list(name = name, NAME_ID = id, project_dir = project, project = project,
              config_file = config_file, yaml_path = yaml_path, config = master, cfg = master,
              start = start, end = end, spin_up_days = spin, spin = spin, models = models,
              windows_file = windows_file, contracts_file = contracts_file, window = window,
              contracts = contracts, seed = seed, specs = specs,
              calibration_windows = nrow(cal), validation_windows = nrow(val),
              input_files = unique(c(files, windows_file, contracts_file)))
  if ("Simstrat" %in% models) {
    exported <- collect("Simstrat installed export", r69_check_exported_sim_init(cfg, ctx))
    ctx$simstrat_export <- exported
    protocol <- collect("Simstrat initialization protocol", {
      r69_need(!is.null(exported) && isTRUE(exported$passed),
               "Executable protocol test is deferred until the installed exporter produces valid seven-column freshwater initialization")
      r69_need(exists("r69_simstrat_protocol_check", mode = "function", inherits = TRUE),
               "The installed-export / executable protocol checker is unavailable; no five-model run is permitted")
      result <- get("r69_simstrat_protocol_check", mode = "function", inherits = TRUE)(cfg, ctx)
      r69_need(is.list(result) && isTRUE(result$passed),
               if (is.list(result) && !is.null(result$message)) result$message else "Protocol check failed")
      result
    })
    ctx$simstrat_protocol <- protocol
  }
  if (exists("r69_validate_contract_evidence", mode = "function", inherits = TRUE) && !is.null(contracts))
    collect("contract evidence", get("r69_validate_contract_evidence", mode = "function", inherits = TRUE)(cfg, ctx))
  ctx$input_manifest <- r69_input_manifest(ctx)
  runtime <- r69_opt(cfg, ".runtime", NULL)
  if (is.null(runtime)) runtime <- r69_runtime_fingerprint(cfg)
  ctx$runtime <- runtime
  protocol_identity <- if ("Simstrat" %in% models) list(
    export = if (is.null(ctx$simstrat_export)) NULL else
      ctx$simstrat_export[c("header", "columns", "initial_file_sha256", "export_init_cond_sha256")],
    checker_sha256 = if (exists("r69_simstrat_protocol_check", mode = "function", inherits = TRUE))
      r69_private(".lw_function_hash")(get("r69_simstrat_protocol_check", mode = "function", inherits = TRUE)) else "MISSING",
    executable_assessment_sha256 = if (is.list(ctx$simstrat_protocol)) ctx$simstrat_protocol$identity_sha256 else NULL,
    executable_sha256 = if (is.list(ctx$simstrat_protocol)) ctx$simstrat_protocol$engine_sha256 else NULL,
    passed = is.list(ctx$simstrat_protocol) && isTRUE(ctx$simstrat_protocol$passed)) else NULL
  ctx$signature <- r69_hash(list(schema = runtime$schema, manifest = ctx$input_manifest,
    runtime = runtime$signature, name = name, NAME_ID = id, models = models, seed = seed,
    spin_up_days = spin, num = as.integer(cfg$num), parallel = isTRUE(cfg$parallel),
    ncores = as.integer(cfg$ncores), save_series = isTRUE(r69_opt(cfg, "save_series", FALSE)),
    run_probe = isTRUE(r69_opt(cfg, "run_probe", TRUE)),
    serial_parallel_required = isTRUE(r69_opt(cfg, "serial_parallel_required", TRUE)),
    serial_parallel_num = as.integer(r69_opt(cfg, "serial_parallel_num", 3L)),
    tolerance = r69_opt(cfg, "tolerance_celsius", 1e-6),
    protocol = protocol_identity))
  ctx$issues <- issues
  ctx$passed <- !length(issues)
  ctx
}

r69_compare_numeric <- function(a, b, tolerance, label, allow_na = FALSE) {
  a <- suppressWarnings(as.numeric(a)); b <- suppressWarnings(as.numeric(b))
  r69_need(length(a) == length(b), "Length mismatch: ", label)
  if (allow_na) {
    r69_need(identical(is.na(a), is.na(b)), "NA mismatch: ", label)
    keep <- !is.na(a); a <- a[keep]; b <- b[keep]
  }
  r69_need(all(is.finite(a)) && all(is.finite(b)), "Nonfinite comparison: ", label)
  delta <- if (length(a)) max(abs(a - b)) else 0
  r69_need(delta <= tolerance, label, ": max difference ", format(delta, digits = 17), " exceeds ", tolerance)
  delta
}

r69_compare_runs <- function(serial_fit, parallel_fit, models, tolerance = 1e-6) {
  a <- serial_fit$summary; b <- parallel_fit$summary
  r69_need(all(a$status == "ok") && all(b$status == "ok"),
           "Every serial/parallel acceptance candidate must succeed")
  ka <- paste(a$model, a$par_id, sep = "/"); kb <- paste(b$model, b$par_id, sep = "/")
  r69_need(!anyDuplicated(ka) && !anyDuplicated(kb) && setequal(ka, kb), "Serial/parallel candidate keys differ")
  report <- list()
  for (m in models) {
    pa <- r69_csv(file.path(serial_fit$run_dir, paste0("params_", m, ".csv")))
    pb <- r69_csv(file.path(parallel_fit$run_dir, paste0("params_", m, ".csv")))
    r69_need(identical(names(pa), names(pb)) && setequal(pa$par_id, pb$par_id), "Parameter pool schema/IDs differ: ", m)
    pb <- pb[match(pa$par_id, pb$par_id), , drop = FALSE]
    for (key in setdiff(names(pa), "par_id")) {
      aa <- as.numeric(pa[[key]]); bb <- as.numeric(pb[[key]])
      r69_need(all(is.finite(aa)) && all(is.finite(bb)) &&
                 all(abs(aa - bb) / pmax(abs(aa), abs(bb), .Machine$double.xmin) <= 1e-12),
               "Serialized candidate parameter mismatch: ", m, "/", key)
    }
    for (id in pa$par_id) {
      left <- r69_csv(file.path(serial_fit$run_dir, "calibration", m, id, "pairs.csv"))
      right <- r69_csv(file.path(parallel_fit$run_dir, "calibration", m, id, "pairs.csv"))
      r69_need(!anyDuplicated(left$window_id) && !anyDuplicated(right$window_id) &&
                 setequal(left$window_id, right$window_id), "Window IDs differ: ", m, "/", id)
      right <- right[match(left$window_id, right$window_id), , drop = FALSE]
      r69_need(identical(left$window_start, right$window_start) && identical(left$window_end, right$window_end),
               "Window boundaries differ: ", m, "/", id)
      r69_compare_numeric(left$observed, right$observed, 1e-12, "observed input")
      delta <- r69_compare_numeric(left$predicted, right$predicted, tolerance, paste(m, id, "prediction"))
      report[[length(report) + 1L]] <- data.frame(model = m, par_id = id,
        windows = nrow(left), max_absolute_difference_celsius = delta,
        tolerance_celsius = tolerance, passed = TRUE, validation_consulted = FALSE)
    }
  }
  do.call(rbind, report)
}

r69_acceptance <- function(ctx, cfg, lake_root) {
  serial_parallel_required <- isTRUE(r69_opt(cfg, "serial_parallel_required", TRUE))
  if (serial_parallel_required)
    r69_need(isTRUE(r69_opt(cfg, "parallel", TRUE)),
             "serial_parallel_required=TRUE requires parallel=TRUE")
  root <- file.path(lake_root, "acceptance")
  receipt_file <- file.path(root, "acceptance_receipt.rds")
  if (isTRUE(r69_opt(cfg, "resume", TRUE)) && file.exists(receipt_file)) {
    old <- r69_read_sealed(receipt_file)
    r69_need(identical(old$signature, ctx$signature),
             "Acceptance inputs/runtime/settings changed; use a new research root for ", ctx$name)
    r69_need(isTRUE(old$passed), "Recorded acceptance did not pass")
    return(old)
  }
  dir.create(root, recursive = TRUE, showWarnings = FALSE)
  attempt <- tempfile("attempt_", tmpdir = root)
  dir.create(attempt)
  if (isTRUE(r69_opt(cfg, "run_probe", TRUE))) {
    # API probe uses one initial set over the ENTIRE YAML period. It only scores
    # calibration windows; it does not select against validation temperatures.
    probe <- LakeEnsemblR::ler_window_probe(ctx$config_file, window = ctx$window,
      model = ctx$models, folder = ctx$project_dir, spin_up = ctx$spin_up_days,
      out_dir = file.path(attempt, "probe"))
    r69_need(all(probe$status == "ok"), "Initial probe failed: ", ctx$name, "; inspect ", attempt)
  } else r69_need(isTRUE(r69_opt(cfg, "probe_already_accepted", FALSE)),
                  "Do not skip the initial model probe without a separately recorded acceptance")
  parallel_accepted <- FALSE
  if (isTRUE(r69_opt(cfg, "parallel", TRUE))) {
    n <- as.integer(r69_opt(cfg, "serial_parallel_num", 3L))
    r69_need(length(n) == 1L && is.finite(n) && n >= 2L, "serial_parallel_num must be >=2")
    serial <- LakeEnsemblR::cali_ensemble(ctx$config_file, window = ctx$window,
      cmethod = "LHC", num = n, model = ctx$models, folder = ctx$project_dir,
      spin_up = ctx$spin_up_days, out_f = file.path(attempt, "serial"), parallel = FALSE, ncores = 1L)
    pools <- setNames(lapply(ctx$models, function(m)
      file.path(serial$run_dir, paste0("params_", m, ".csv"))), ctx$models)
    parallel <- LakeEnsemblR::cali_ensemble(ctx$config_file, window = ctx$window,
      cmethod = "LHC", param_file = pools, model = ctx$models, folder = ctx$project_dir,
      spin_up = ctx$spin_up_days, out_f = file.path(attempt, "parallel"),
      parallel = TRUE, ncores = as.integer(cfg$ncores))
    report <- r69_compare_runs(serial, parallel, ctx$models,
                              r69_opt(cfg, "tolerance_celsius", 1e-6))
    r69_write_csv(report, file.path(attempt, "serial_parallel_comparison.csv"))
    parallel_accepted <- TRUE
  }
  if (serial_parallel_required)
    r69_need(isTRUE(parallel_accepted), "Required serial/parallel acceptance was not completed")
  result <- list(signature = ctx$signature, passed = TRUE, parallel_accepted = parallel_accepted,
                  attempt_dir = normalizePath(attempt, winslash = "/", mustWork = TRUE),
                  UTC = format(Sys.time(), "%Y-%m-%d %H:%M:%S", tz = "UTC"))
  r69_save_sealed(result, receipt_file)
  result
}

r69_check_calibration_integrity <- function(run_dir) {
  r69_need(dir.exists(run_dir), "Missing calibration run: ", run_dir)
  seal <- r69_csv(file.path(run_dir, "context_integrity.csv"))
  r69_need(nrow(seal) == 1L && identical(as.character(seal$file), "context.rds") &&
             identical(as.character(seal$sha256), r69_sha(file.path(run_dir, "context.rds"))),
           "Calibration context integrity mismatch: ", run_dir)
  ctx <- readRDS(file.path(run_dir, "context.rds"))
  r69_need(identical(ctx$result_dir, normalizePath(run_dir, winslash = "/", mustWork = TRUE)),
           "Calibration directory was moved; restore its original path")
  r69_private(".lw_verify_runtime")(ctx)
  r69_need(!is.null(ctx$calibration_files), "Missing completed-calibration integrity record")
  for (i in seq_len(nrow(ctx$calibration_files))) {
    p <- file.path(run_dir, ctx$calibration_files$file[i])
    r69_need(file.exists(p) && identical(r69_sha(p), ctx$calibration_files$sha256[i]),
             "Changed calibration artifact: ", p)
  }
  ctx
}

r69_verify_final <- function(run_dir, tolerance = 1e-6) {
  ctx <- r69_check_calibration_integrity(run_dir)
  metrics <- r69_csv(file.path(run_dir, "final_metrics.csv"))
  expected <- as.vector(outer(ctx$models, c("calibration", "validation"), paste, sep = "/"))
  actual <- paste(metrics$model, metrics$split, sep = "/")
  r69_need(nrow(metrics) == length(expected) && !anyDuplicated(actual) && setequal(actual, expected),
           "Incomplete final_metrics.csv")
  best <- r69_csv(file.path(run_dir, "best_by_calibration_RMSE.csv"))
  val <- r69_private(".lw_select")(ctx$windows, ctx$control$validation_split,
                                   ctx$allowed_start, ctx$allowed_end)
  for (m in ctx$models) {
    id <- best$par_id[best$model == m]
    r69_need(length(id) == 1L, "Missing unique selected parameter ID: ", m)
    directory <- file.path(run_dir, "final", m, id)
    native <- readRDS(file.path(directory, "native_surface.rds"))
    contract <- ctx$contracts[ctx$contracts$model == m, , drop = FALSE]
    for (split in c("calibration", "validation")) {
      windows <- if (split == "calibration") ctx$cal else val
      recalculated <- LakeEnsemblR::calc_fit_window(native, windows, contract)
      recorded <- r69_csv(file.path(directory, paste0("pairs_", split, ".csv")))
      r69_need(setequal(recorded$window_id, recalculated$pairs$window_id), "Final window IDs changed")
      recorded <- recorded[match(recalculated$pairs$window_id, recorded$window_id), , drop = FALSE]
      r69_compare_numeric(recorded$observed, recalculated$pairs$observed, 1e-12, "Final observations")
      r69_compare_numeric(recorded$predicted, recalculated$pairs$predicted, tolerance, "Final predictions")
      live_metrics <- recalculated$metrics
      row <- metrics[metrics$model == m & metrics$split == split, , drop = FALSE]
      for (key in names(live_metrics))
        r69_compare_numeric(row[[key]], live_metrics[[key]], 1e-9,
                            paste(m, split, key), allow_na = TRUE)
      if (split == "calibration") {
        old <- r69_csv(file.path(run_dir, "calibration", m, id, "pairs.csv"))
        old <- old[match(recorded$window_id, old$window_id), , drop = FALSE]
        r69_need(!anyNA(old$window_id), "Selected calibration pairs are incomplete")
        r69_compare_numeric(old$predicted, recorded$predicted, tolerance, "Selected/calibration rerun")
      }
    }
  }
  list(metrics = metrics, files = r69_private(".lw_file_manifest")(file.path(run_dir, "final")))
}

r69_run_lake <- function(cfg, row, paths = NULL, ctx = NULL) {
  if (is.null(ctx)) ctx <- r69_preflight(cfg, row, paths)
  r69_need(isTRUE(ctx$passed), "Preflight failed: ", ctx$name, ": ", paste(ctx$issues, collapse = " | "))
  root <- file.path(cfg$results_root, "lakes", ctx$name)
  dir.create(root, recursive = TRUE, showWarnings = FALSE)
  r69_write_csv(ctx$input_manifest, file.path(root, "live_input_manifest.csv"))
  acceptance <- r69_acceptance(ctx, cfg, root)
  stage <- r69_opt(cfg, "stage", "research")
  empty <- data.frame(name = ctx$name, NAME_ID = ctx$NAME_ID, run_dir = "",
    calibration_status = "not_run", evaluation_status = "not_run", error = "",
    input_signature = ctx$signature, request_num = as.integer(cfg$num),
    success_count = NA_integer_, failure_count = NA_integer_, stringsAsFactors = FALSE)
  if (stage == "acceptance") return(empty)
  attempts <- list.dirs(file.path(root, "attempts"), full.names = TRUE, recursive = FALSE)
  attempts <- sort(attempts, decreasing = TRUE)
  selected <- NULL
  if (isTRUE(r69_opt(cfg, "resume", TRUE))) for (attempt in attempts) {
    receipt <- file.path(attempt, "calibration_receipt.rds")
    if (!file.exists(receipt)) next
    old <- r69_read_sealed(receipt)
    r69_need(identical(old$signature, ctx$signature),
             "Completed calibration inputs/settings changed; use a NEW results root rather than reusing ", ctx$name)
    r69_check_calibration_integrity(old$run_dir)
    selected <- old; break
  }
  if (is.null(selected)) {
    directory <- file.path(root, "attempts")
    dir.create(directory, recursive = TRUE, showWarnings = FALSE)
    used <- list.dirs(directory, full.names = FALSE, recursive = FALSE)
    number <- 1L
    repeat {
      attempt <- file.path(directory, sprintf("A%04d", number))
      if (!file.exists(attempt)) break
      number <- number + 1L
    }
    dir.create(attempt)
    r69_save_sealed(list(signature = ctx$signature, name = ctx$name, NAME_ID = ctx$NAME_ID,
                         num = cfg$num, seed = ctx$seed, acceptance = acceptance),
                    file.path(attempt, "request.rds"))
    fit <- LakeEnsemblR::cali_ensemble(ctx$config_file, window = ctx$window, cmethod = "LHC",
      num = as.integer(cfg$num), model = ctx$models, folder = ctx$project_dir,
      spin_up = ctx$spin_up_days, out_f = file.path(attempt, "calibration"),
      parallel = isTRUE(cfg$parallel), ncores = as.integer(cfg$ncores))
    minimum <- r69_number(r69_opt(cfg, "min_success_fraction", 0.95), "min_success_fraction")
    r69_need(minimum > 0 && minimum <= 1, "min_success_fraction must be in (0,1]")
    for (m in ctx$models) {
      part <- fit$summary[fit$summary$model == m, , drop = FALSE]
      r69_need(nrow(part) == as.integer(cfg$num), "Incomplete candidate count: ", ctx$name, "/", m)
      success <- mean(part$status == "ok" & is.finite(part$RMSE))
      r69_need(success >= minimum, ctx$name, "/", m, ": successful candidate fraction ", success,
               " is below ", minimum, "; no final evaluation is accepted")
    }
    selected <- list(signature = ctx$signature, run_dir = fit$run_dir,
      attempt_dir = attempt, success_count = sum(fit$summary$status == "ok"),
      failure_count = sum(fit$summary$status != "ok"), num = as.integer(cfg$num), seed = ctx$seed)
    r69_save_sealed(selected, file.path(attempt, "calibration_receipt.rds"))
  }
  result <- empty
  result$run_dir <- selected$run_dir
  result$calibration_status <- "ok"
  result$success_count <- selected$success_count
  result$failure_count <- selected$failure_count
  evaluation_receipt <- file.path(selected$attempt_dir, "evaluation_receipt.rds")
  if (file.exists(evaluation_receipt) && isTRUE(r69_opt(cfg, "resume", TRUE))) {
    receipt <- r69_read_sealed(evaluation_receipt)
    r69_need(identical(receipt$signature, ctx$signature), "Final receipt context changed")
    r69_private(".lw_check_manifest")(file.path(selected$run_dir, "final"), receipt$final_files, "Final results")
    r69_need(identical(r69_sha(file.path(selected$run_dir, "final_metrics.csv")), receipt$metrics_sha256),
             "Final metric file changed")
    result$evaluation_status <- "ok"
    return(result)
  }
  # Recover an interrupted wrapper after the public API already wrote its final
  # metrics, without rerunning or selecting against validation again.
  final_metrics <- file.path(selected$run_dir, "final_metrics.csv")
  if (!file.exists(final_metrics)) {
    final_dir <- file.path(selected$run_dir, "final")
    if (dir.exists(final_dir)) {
      archive <- tempfile("_incomplete_final_", tmpdir = selected$run_dir)
      r69_need(file.rename(final_dir, archive), "Could not preserve incomplete final rerun: ", final_dir)
    }
    LakeEnsemblR::evaluate_window_best(selected$run_dir,
      tolerance_celsius = r69_opt(cfg, "tolerance_celsius", 1e-6))
  }
  checked <- r69_verify_final(selected$run_dir, r69_opt(cfg, "tolerance_celsius", 1e-6))
  receipt <- list(signature = ctx$signature, final_files = checked$files,
    metrics_sha256 = r69_sha(final_metrics),
    UTC = format(Sys.time(), "%Y-%m-%d %H:%M:%S", tz = "UTC"))
  r69_save_sealed(receipt, evaluation_receipt)
  result$evaluation_status <- "ok"
  result
}

r69_batch <- function(cfg, registry, paths = NULL) {
  r69_need(is.data.frame(registry) && all(c("name", "NAME_ID") %in% names(registry)),
           "Registry needs name and NAME_ID")
  expected_lakes <- r69_opt(cfg, "expected_n_lakes", r69_opt(cfg, "expected_lakes", 69L))
  r69_need(nrow(registry) == as.integer(expected_lakes),
           "Expected exactly ", expected_lakes, " selected lakes")
  r69_need(!anyNA(registry$name) && !anyDuplicated(registry$name) &&
             !anyNA(registry$NAME_ID) && !anyDuplicated(registry$NAME_ID), "Duplicate/missing registry keys")
  dir.create(cfg$results_root, recursive = TRUE, showWarnings = FALSE)
  cfg$.runtime <- r69_runtime_fingerprint(cfg)
  r69_save_sealed(cfg$.runtime, file.path(cfg$results_root, "runtime_identity.rds"))
  capture.output(utils::sessionInfo(), file = file.path(cfg$results_root, "sessionInfo.txt"))
  contexts <- vector("list", nrow(registry)); errors <- vector("list", nrow(registry))
  for (i in seq_len(nrow(registry))) {
    message("Preflight ", i, "/", nrow(registry), ": ", registry$name[i])
    contexts[i] <- list(tryCatch(r69_preflight(cfg, registry[i, , drop = FALSE], paths),
      error = function(e) {
        errors[[i]] <<- conditionMessage(e)
        NULL
      }))
    if (!is.null(contexts[[i]]) && !isTRUE(contexts[[i]]$passed)) errors[[i]] <- contexts[[i]]$issues
  }
  passed <- vapply(seq_len(nrow(registry)), function(i) !is.null(contexts[[i]]) &&
                      isTRUE(contexts[[i]]$passed), logical(1))
  summary <- data.frame(name = registry$name, NAME_ID = registry$NAME_ID, passed = passed,
    calibration_windows = vapply(contexts, function(x) if (is.null(x)) NA_integer_ else x$calibration_windows, integer(1)),
    validation_windows = vapply(contexts, function(x) if (is.null(x)) NA_integer_ else x$validation_windows, integer(1)),
    error = vapply(errors, function(x) paste(x, collapse = " | "), character(1)), stringsAsFactors = FALSE)
  r69_write_csv(summary, file.path(cfg$results_root, "preflight", "preflight_summary.csv"))
  issue_rows <- lapply(seq_along(errors), function(i) {
    if (!length(errors[[i]])) return(NULL)
    text <- errors[[i]]
    action <- vapply(text, function(x) {
      if (grepl("Installed delivery exports|installed exporter|initialization-export defect", x))
        return("Installed Simstrat initialization export must be repaired and verified separately; do not alter MODIS observations or auto-add a column in this runner.")
      if (grepl("contract|Output time semantics|step_seconds|phase_seconds|timestamp_shift_seconds|aggregation method|label_position|physical time meaning", x, ignore.case = TRUE))
        return("Complete and verify the model output cadence, timestamp meaning, phase/shift and surface definition. Keep unverified contracts confirmed=FALSE; never bulk-change to TRUE.")
      if (grepl("protocol", x, ignore.case = TRUE))
        return("Inspect the retained actual exporter/executable protocol evidence before a five-model research run.")
      "Resolve the named input/runtime/configuration problem and rerun preflight; no source or raw input is modified automatically."
    }, character(1))
    data.frame(name = registry$name[i], problem = text, next_action = action,
               issue = text, stringsAsFactors = FALSE)
  })
  issues <- if (any(lengths(issue_rows))) do.call(rbind, issue_rows) else
    data.frame(name = character(), problem = character(), next_action = character(), issue = character())
  r69_write_csv(issues, file.path(cfg$results_root, "preflight", "issues.csv"))
  index <- data.frame(name = registry$name, NAME_ID = registry$NAME_ID, run_dir = "",
    calibration_status = "not_run", evaluation_status = "not_run", error = summary$error,
    input_signature = vapply(contexts, function(x) if (is.null(x)) "" else x$signature, character(1)),
    request_num = as.integer(cfg$num), success_count = NA_integer_, failure_count = NA_integer_,
    stringsAsFactors = FALSE)
  index_path <- file.path(cfg$results_root, "run_index.csv")
  stage <- r69_opt(cfg, "stage", "research")
  if (file.exists(index_path)) {
    previous <- r69_csv(index_path)
    r69_write_csv(previous, tempfile("run_index_previous_", tmpdir = cfg$results_root, fileext = ".csv"))
    r69_need("name" %in% names(previous) && !anyDuplicated(previous$name), "Existing run_index has invalid name keys")
    for (i in seq_len(nrow(index))) {
      old <- match(index$name[i], previous$name)
      if (is.na(old)) next
      same <- "input_signature" %in% names(previous) &&
        identical(as.character(previous$input_signature[old]), as.character(index$input_signature[i]))
      # A readiness-only run must not erase an existing completed research index.
      # Likewise a failed global preflight leaves historical accepted results
      # addressable; the new live-input failure is recorded in separate columns.
      if (stage == "preflight" || !all(passed) || same) {
        common <- intersect(names(index), names(previous))
        index[i, common] <- previous[old, common, drop = FALSE]
      }
    }
  }
  index$preflight_passed <- passed
  index$preflight_error <- summary$error
  index$preflight_input_signature <- vapply(contexts, function(x) if (is.null(x)) "" else x$signature, character(1))
  # Acceptance has a dedicated cohort summary below. It must not replace a
  # previously completed research index, even when live inputs have changed.
  if (stage != "acceptance") r69_write_csv(index, index_path)
  if (stage == "preflight") return(index)
  if (!all(passed)) {
    for (i in which(!passed)) message(registry$name[i], ": ", summary$error[i])
    stop(sum(!passed), " lake(s) failed preflight; no long model task was started. See preflight/issues.csv", call. = FALSE)
  }
  # Acceptance is a cohort-level gate. Complete it for every lake before any
  # 500-member calibration starts, so an untested later lake cannot be hidden
  # behind expensive results already produced for earlier lakes.
  if (stage %in% c("acceptance", "research", "all")) {
    acceptance_rows <- vector("list", nrow(registry))
    for (i in seq_len(nrow(registry))) {
      message("Acceptance ", i, "/", nrow(registry), ": ", registry$name[i])
      lake_root <- file.path(cfg$results_root, "lakes", registry$name[i])
      dir.create(lake_root, recursive = TRUE, showWarnings = FALSE)
      accepted <- tryCatch(r69_acceptance(contexts[[i]], cfg, lake_root), error = identity)
      if (inherits(accepted, "error")) {
        acceptance_rows[[i]] <- data.frame(
          name = registry$name[i], NAME_ID = registry$NAME_ID[i],
          input_signature = contexts[[i]]$signature,
          probe_status = "failed_or_not_reached",
          serial_parallel_status = "failed_or_not_reached", passed = FALSE,
          error = conditionMessage(accepted), acceptance_receipt = "",
          attempt_dir = "", UTC = format(Sys.time(), "%Y-%m-%d %H:%M:%S", tz = "UTC"),
          stringsAsFactors = FALSE)
      } else {
        acceptance_rows[[i]] <- data.frame(
          name = registry$name[i], NAME_ID = registry$NAME_ID[i],
          input_signature = contexts[[i]]$signature,
          probe_status = if (isTRUE(r69_opt(cfg, "run_probe", TRUE))) "passed" else "separately_accepted",
          serial_parallel_status = if (isTRUE(r69_opt(cfg, "parallel", TRUE)) &&
                                         isTRUE(accepted$parallel_accepted)) "passed" else "not_requested",
          passed = isTRUE(accepted$passed), error = "",
          acceptance_receipt = normalizePath(file.path(lake_root, "acceptance", "acceptance_receipt.rds"),
                                             winslash = "/", mustWork = TRUE),
          attempt_dir = as.character(accepted$attempt_dir), UTC = as.character(accepted$UTC),
          stringsAsFactors = FALSE)
      }
    }
    acceptance_summary <- do.call(rbind, acceptance_rows)
    r69_write_csv(acceptance_summary,
                  file.path(cfg$results_root, "acceptance", "acceptance_summary.csv"))
    if (!all(acceptance_summary$passed)) {
      stop(sum(!acceptance_summary$passed),
           " lake(s) failed acceptance; no formal calibration was started. See acceptance/acceptance_summary.csv",
           call. = FALSE)
    }
    # Acceptance has its own summary and must never replace an existing
    # research run_index with calibration_status/evaluation_status=not_run.
    if (stage == "acceptance") return(index)
  }
  for (i in seq_len(nrow(registry))) {
    message("Research ", i, "/", nrow(registry), ": ", registry$name[i])
    result <- tryCatch(r69_run_lake(cfg, registry[i, , drop = FALSE], paths, contexts[[i]]),
      error = function(e) {
        out <- index[i, , drop = FALSE]
        out$run_dir <- ""; out$calibration_status <- "failed"; out$evaluation_status <- "not_run"
        out$success_count <- NA_integer_; out$failure_count <- NA_integer_
        out$error <- conditionMessage(e)
        # Preserve discoverable completed calibration for downstream training-only
        # sensitivity analysis even when this lake's independent rerun failed.
        attempt_root <- file.path(cfg$results_root, "lakes", registry$name[i], "attempts")
        receipts <- list.files(attempt_root, pattern = "^calibration_receipt[.]rds$", recursive = TRUE, full.names = TRUE)
        if (length(receipts)) {
          receipt <- tryCatch(r69_read_sealed(tail(sort(receipts), 1L)), error = function(e) NULL)
          intact <- if (!is.null(receipt) && identical(receipt$signature, contexts[[i]]$signature))
            tryCatch({ r69_check_calibration_integrity(receipt$run_dir); TRUE }, error = function(e) FALSE) else FALSE
          if (isTRUE(intact)) {
            out$run_dir <- receipt$run_dir; out$calibration_status <- "ok"
            out$success_count <- receipt$success_count; out$failure_count <- receipt$failure_count
            out$evaluation_status <- "failed"
          }
        }
        if (!nzchar(out$run_dir)) {
          requests <- list.files(attempt_root, pattern = "^request[.]rds$", recursive = TRUE, full.names = TRUE)
          if (length(requests)) {
            request_path <- tail(sort(requests), 1L)
            request <- tryCatch(r69_read_sealed(request_path), error = function(e) NULL)
            partial <- file.path(dirname(request_path), "calibration")
            if (!is.null(request) && identical(request$signature, contexts[[i]]$signature) && dir.exists(partial)) {
              out$run_dir <- normalizePath(partial, winslash = "/", mustWork = TRUE)
              summary_file <- file.path(partial, "calibration_summary.csv")
              if (file.exists(summary_file)) {
                partial_summary <- r69_csv(summary_file)
                out$success_count <- sum(partial_summary$status == "ok")
                out$failure_count <- sum(partial_summary$status != "ok")
              }
            }
          }
        }
        message("Lake failed; retained output and continuing: ", registry$name[i], ": ", out$error)
        out
      })
    index[i, names(result)] <- result
    r69_write_csv(index, index_path)
  }
  index
}


# ===== Bundled module: 03_diagnostics.R =====
# Comparisons for accepted LER_window best-parameter reruns.
# Observations remain MODIS half-open windows, NOT replicated daily values.
# This module never invokes a lake model, fits a parameter, or selects on holdout.

r69d_or <- function(x, value) if (is.null(x)) value else x
r69d_need <- function(ok, ...) if (!isTRUE(ok)) stop(..., call. = FALSE)
r69d_read <- function(path) {
  r69d_need(file.exists(path), "Missing diagnostic input: ", path)
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE,
                  fileEncoding = "UTF-8-BOM")
}
r69d_write <- function(x, path) {
  if (!ncol(x)) x <- data.frame(status = character(), stringsAsFactors = FALSE)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  temporary <- tempfile("table_", tmpdir = dirname(path), fileext = ".csv")
  on.exit(unlink(temporary), add = TRUE)
  utils::write.csv(x, temporary, row.names = FALSE, na = "", fileEncoding = "UTF-8")
  r69d_need(file.copy(temporary, path, overwrite = TRUE), "Cannot write ", path)
  invisible(path)
}
r69d_bind <- function(x) {
  x <- Filter(function(z) is.data.frame(z) && nrow(z) > 0L, x)
  if (!length(x)) return(data.frame())
  fields <- unique(unlist(lapply(x, names), use.names = FALSE))
  x <- lapply(x, function(z) {
    for (n in setdiff(fields, names(z))) z[[n]] <- NA
    z[fields]
  })
  rownames_result <- do.call(rbind, x)
  rownames(rownames_result) <- NULL
  rownames_result
}
r69d_time <- function(x) {
  if (inherits(x, "POSIXt")) return(as.POSIXct(x, tz = "UTC"))
  t <- as.POSIXct(strptime(as.character(x), "%Y-%m-%d %H:%M:%S", tz = "UTC"))
  r69d_need(!anyNA(t), "Unparseable UTC time in final pairs")
  t
}

r69d_metrics <- function(observed, predicted) {
  r69d_need(length(observed) == length(predicted) && length(observed) > 0L &&
              all(is.finite(observed)) && all(is.finite(predicted)),
            "Metrics require equal, nonempty, finite paired vectors; no na.rm")
  e <- predicted - observed
  vo <- sum((observed - mean(observed))^2)
  vp <- sum((predicted - mean(predicted))^2)
  rr <- if (vo > 0 && vp > 0) sum((observed - mean(observed)) *
                    (predicted - mean(predicted))) / sqrt(vo * vp) else NA_real_
  extent <- diff(range(observed))
  flag <- c(if (vo == 0) "constant_observations_NSE_r_undefined",
            if (vp == 0) "constant_predictions_r_undefined",
            if (length(observed) < 3L) "fewer_than_3_pairs")
  data.frame(N = length(observed), RMSE = sqrt(mean(e^2)), MAE = mean(abs(e)),
             bias = mean(e), NSE = if (vo > 0) 1 - sum(e^2) / vo else NA_real_,
             r = rr, r_squared = rr^2,
             nMAE_range_percent = if (extent > 0) 100 * mean(abs(e)) / extent else NA_real_,
             nRMSE_range_percent = if (extent > 0) 100 * sqrt(mean(e^2)) / extent else NA_real_,
             metric_flags = paste(flag, collapse = ";"), stringsAsFactors = FALSE)
}

r69d_sealed <- function(path) {
  if (exists("r69_read_sealed", mode = "function", inherits = TRUE))
    return(get("r69_read_sealed", mode = "function", inherits = TRUE)(path))
  seal_path <- paste0(path, ".sha256")
  r69d_need(file.exists(path) && file.exists(seal_path), "Missing accepted stage receipt/seal: ", path)
  recorded <- readLines(seal_path, warn = FALSE)
  actual <- digest::digest(file = path, algo = "sha256", serialize = FALSE)
  r69d_need(length(recorded) == 1L && identical(recorded, actual),
            "Changed/incomplete accepted stage receipt: ", path)
  readRDS(path)
}

r69d_manifest <- function(root) {
  r69d_need(dir.exists(root), "Missing accepted final directory: ", root)
  files <- sort(list.files(root, recursive = TRUE, full.names = FALSE,
                            all.files = TRUE, no.. = TRUE))
  full <- file.path(root, files)
  links <- Sys.readlink(full)
  r69d_need(!any(!is.na(links) & nzchar(links)), "Symlink in accepted final results")
  data.frame(file = files, bytes = as.numeric(file.info(full)$size),
    sha256 = vapply(full, function(path) digest::digest(file = path, algo = "sha256", serialize = FALSE), character(1)),
    stringsAsFactors = FALSE, row.names = NULL)
}

r69d_verify_context <- function(run_dir, models, expected_signature) {
  r69d_need(requireNamespace("digest", quietly = TRUE), "digest is required")
  r69d_need(is.character(expected_signature) && length(expected_signature) == 1L &&
              !is.na(expected_signature) && grepl("^[a-f0-9]{64}$", expected_signature),
            "Missing/invalid run_index input_signature")
  attempt <- dirname(normalizePath(run_dir, winslash = "/", mustWork = TRUE))
  evaluation <- r69d_sealed(file.path(attempt, "evaluation_receipt.rds"))
  calibration <- r69d_sealed(file.path(attempt, "calibration_receipt.rds"))
  request <- r69d_sealed(file.path(attempt, "request.rds"))
  r69d_need(identical(evaluation$signature, expected_signature) &&
              identical(calibration$signature, expected_signature) &&
              identical(request$signature, expected_signature),
            "Stage receipt/input-index signatures disagree")
  r69d_need(is.character(calibration$run_dir) && length(calibration$run_dir) == 1L &&
      identical(normalizePath(calibration$run_dir, winslash = "/", mustWork = TRUE),
                normalizePath(run_dir, winslash = "/", mustWork = TRUE)),
    "Calibration receipt points to another run directory")
  r69d_need(is.data.frame(evaluation$final_files) &&
      identical(r69d_manifest(file.path(run_dir, "final")), evaluation$final_files),
    "Accepted final files changed since evaluation receipt")
  metrics_hash <- digest::digest(file = file.path(run_dir, "final_metrics.csv"),
                                 algo = "sha256", serialize = FALSE)
  r69d_need(identical(metrics_hash, evaluation$metrics_sha256),
            "Accepted final_metrics.csv changed since evaluation receipt")
  path <- file.path(run_dir, "context.rds")
  seal <- r69d_read(file.path(run_dir, "context_integrity.csv"))
  r69d_need(nrow(seal) == 1L && identical(as.character(seal$file), "context.rds"),
            "Invalid context seal in ", run_dir)
  actual <- digest::digest(file = path, algo = "sha256", serialize = FALSE)
  r69d_need(identical(tolower(as.character(seal$sha256)), tolower(actual)),
            "Calibration context digest changed: ", run_dir)
  ctx <- readRDS(path)
  r69d_need(identical(as.character(ctx$models), as.character(models)),
            "Accepted run model order differs from cfg$models")
  if (!is.null(ctx$result_dir)) r69d_need(
    identical(normalizePath(run_dir, winslash = "/", mustWork = TRUE),
              normalizePath(ctx$result_dir, winslash = "/", mustWork = TRUE)),
    "Run directory moved since acceptance")
  r69d_need(is.list(ctx$specs) && is.list(ctx$pools), "Missing native specs or parameter pools")
  recorded <- ctx$calibration_files
  r69d_need(is.data.frame(recorded) && all(c("file", "sha256") %in% names(recorded)),
            "Missing sealed calibration-result manifest")
  for (rel in c("best_by_calibration_RMSE.csv", "calibration_summary.csv")) {
    rec <- recorded[recorded$file == rel, , drop = FALSE]
    r69d_need(nrow(rec) == 1L && identical(tolower(as.character(rec$sha256)),
      tolower(digest::digest(file = file.path(run_dir, rel), algo = "sha256", serialize = FALSE))),
      "Sealed calibration result changed: ", rel)
  }
  ctx
}

r69d_read_pairs <- function(run_dir, model, id, split) {
  path <- file.path(run_dir, "final", model, id, paste0("pairs_", split, ".csv"))
  x <- r69d_read(path)
  required <- c("window_id", "window_start", "window_end", "observed", "predicted")
  r69d_need(all(required %in% names(x)) && nrow(x) > 0L,
            "Final pairs missing fields/rows: ", path)
  x$window_id <- as.character(x$window_id)
  r69d_need(!anyNA(x$window_id) && !anyDuplicated(x$window_id),
            "Final window IDs are missing or duplicated: ", path)
  x$observed <- as.numeric(x$observed); x$predicted <- as.numeric(x$predicted)
  r69d_need(all(is.finite(x$observed)) && all(is.finite(x$predicted)),
            "Nonfinite accepted final pairs: ", path)
  x$window_start <- r69d_time(x$window_start)
  x$window_end <- r69d_time(x$window_end)
  r69d_need(all(x$window_end > x$window_start), "Invalid final window lengths: ", path)
  if ("split" %in% names(x)) r69d_need(all(as.character(x$split) == split),
                                                   "Mixed final pair splits: ", path)
  x$split <- split
  x <- x[order(x$window_start, x$window_id), , drop = FALSE]
  x$label_datetime <- x$window_start +
    as.numeric(difftime(x$window_end, x$window_start, units = "secs")) / 2
  x$year <- as.integer(format(x$label_datetime, "%Y", tz = "UTC"))
  x$month <- as.integer(format(x$label_datetime, "%m", tz = "UTC"))
  x$DOY <- as.integer(format(x$label_datetime, "%j", tz = "UTC"))
  x$residual <- x$predicted - x$observed
  x$model <- model
  x$par_id <- id
  x
}

r69d_align_ensemble <- function(pairs, models) {
  # An accepted all-model rerun must contain the SAME approved windows.
  # No silent intersection, dropped failed model, or na.rm ensemble is allowed.
  reference <- pairs[[models[1L]]]
  predicted <- matrix(NA_real_, nrow(reference), length(models),
                      dimnames = list(reference$window_id, models))
  for (m in models) {
    z <- pairs[[m]]
    r69d_need(setequal(z$window_id, reference$window_id),
              "Approved final window sets differ across models; cannot form fair comparison")
    z <- z[match(reference$window_id, z$window_id), , drop = FALSE]
    r69d_need(all(as.numeric(z$window_start) == as.numeric(reference$window_start)) &&
                all(as.numeric(z$window_end) == as.numeric(reference$window_end)) &&
                all(abs(z$observed - reference$observed) <= 1e-10),
              "Window bounds or observations differ across accepted models")
    predicted[, m] <- z$predicted
  }
  r69d_need(all(is.finite(predicted)), "Incomplete model ensemble")
  ensemble <- reference
  ensemble$model <- "Ensemble_mean"
  ensemble$par_id <- "equal_weight_of_training_selected_members"
  ensemble$predicted <- rowMeans(predicted)
  ensemble$residual <- ensemble$predicted - ensemble$observed
  ensemble$model_spread_sd_celsius <- if (length(models) > 1L)
    apply(predicted, 1L, stats::sd) else rep(NA_real_, nrow(predicted))
  ensemble$model_min_celsius <- apply(predicted, 1L, min)
  ensemble$model_max_celsius <- apply(predicted, 1L, max)
  # Across-model spread is NOT a probabilistic confidence interval.
  ensemble
}

r69d_parameter_tables <- function(name, ctx, best, boundary_fraction) {
  out <- list()
  for (m in ctx$models) {
    spec <- ctx$specs[[m]]
    pool <- ctx$pools[[m]]
    id <- as.character(best$par_id[best$model == m])
    r69d_need(length(id) == 1L && sum(as.character(pool$par_id) == id) == 1L,
              "Best candidate missing/duplicated in parameter pool: ", name, "/", m)
    row <- pool[as.character(pool$par_id) == id, , drop = FALSE]
    for (j in seq_len(nrow(spec))) {
      key <- as.character(spec$name[j]); value <- as.numeric(row[[key]])
      lo <- as.numeric(spec$lower[j]); hi <- as.numeric(spec$upper[j])
      lg <- isTRUE(as.logical(spec$log[j]))
      r69d_need(length(value) == 1L && is.finite(value) && lo < hi && value >= lo && value <= hi,
                "Invalid selected parameter: ", name, "/", m, "/", key)
      u <- if (lg) (log10(value) - log10(lo)) / (log10(hi) - log10(lo)) else (value - lo)/(hi - lo)
      kw0 <- suppressWarnings(as.numeric(ctx$base$input$light$Kw$all))
      if (length(kw0) != 1L || !is.finite(kw0) || kw0 <= 0) kw0 <- NA_real_
      out[[length(out) + 1L]] <- data.frame(
        name = name, model = m, par_id = id, parameter = key, type = as.character(spec$type[j]),
        value = value, lower = lo, upper = hi, log_sampling = lg,
        position_linear = (value - lo)/(hi - lo), position_sampling = u,
        boundary_fraction = boundary_fraction,
        near_lower_boundary = u <= boundary_fraction,
        near_upper_boundary = u >= 1 - boundary_fraction,
        Kw0_m_inverse = kw0,
        Kw_multiplier = if (identical(key, "Kw") && is.finite(kw0)) value/kw0 else NA_real_,
        stringsAsFactors = FALSE)
    }
  }
  r69d_bind(out)
}

r69d_convergence <- function(name, ctx, summary) {
  out <- list()
  for (m in ctx$models) {
    ids <- as.character(ctx$pools[[m]]$par_id)
    z <- summary[summary$model == m, , drop = FALSE]
    r69d_need(!anyDuplicated(z$par_id) && setequal(as.character(z$par_id), ids),
              "Candidate summary/pool mismatch: ", name, "/", m)
    z <- z[match(ids, as.character(z$par_id)), , drop = FALSE]
    good <- z$status == "ok" & is.finite(z$objective)
    objectives <- ifelse(good, as.numeric(z$objective), Inf)
    best <- cummin(objectives)
    n <- length(ids)
    prefixes <- sort(unique(c(1L, pmin(c(25L, 50L, 100L, 200L, 500L, 1000L, 2000L), n), n)))
    full <- tail(best, 1L)
    out[[length(out) + 1L]] <- data.frame(
      name = name, model = m, attempted_prefix = prefixes,
      successful_prefix = cumsum(good)[prefixes],
      best_calibration_RMSE = ifelse(is.finite(best[prefixes]), best[prefixes], NA_real_),
      final_best_calibration_RMSE = full,
      relative_gap_to_full_search = if (is.finite(full) && full > 0)
        (best[prefixes] - full)/full else NA_real_,
      interpretation = "Training-only prefixes of the SAME LHC pool; not independent sample-size convergence proof",
      stringsAsFactors = FALSE)
  }
  r69d_bind(out)
}

r69d_group_metrics <- function(pairs, fields) {
  if (!nrow(pairs)) return(data.frame())
  keys <- do.call(paste, c(pairs[fields], sep = "\r"))
  chunks <- split(seq_len(nrow(pairs)), keys)
  r69d_bind(lapply(chunks, function(ii) cbind(pairs[ii[1L], fields, drop = FALSE],
    r69d_metrics(pairs$observed[ii], pairs$predicted[ii]))))
}

r69d_year_bootstrap <- function(pairs, B, seed) {
  if (!B || !nrow(pairs)) return(data.frame())
  r69d_need(B == as.integer(B) && B >= 100, "diagnostic_bootstrap_B must be 0 or integer >=100")
  groups <- split(seq_len(nrow(pairs)), paste(pairs$name, pairs$model, pairs$split, sep = "\r"))
  old <- if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
    get(".Random.seed", envir = .GlobalEnv) else NULL
  on.exit(if (is.null(old)) {
    if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)) rm(".Random.seed", envir = .GlobalEnv)
  } else assign(".Random.seed", old, envir = .GlobalEnv), add = TRUE)
  set.seed(seed)
  r69d_bind(lapply(groups, function(ii) {
    x <- pairs[ii, , drop = FALSE]; years <- sort(unique(x$year))
    if (length(years) < 3L) return(cbind(x[1L, c("name", "model", "split"), drop = FALSE],
      data.frame(n_years = length(years), bootstrap_B = B, RMSE_low = NA_real_, RMSE_high = NA_real_,
                 bias_low = NA_real_, bias_high = NA_real_, note = "Fewer than 3 years; interval not estimated")))
    block <- split(seq_len(nrow(x)), x$year)
    estimates <- replicate(B, {
      sampled <- sample(as.character(years), length(years), replace = TRUE)
      jj <- unlist(block[sampled], use.names = FALSE)
      e <- x$predicted[jj] - x$observed[jj]
      c(RMSE = sqrt(mean(e^2)), bias = mean(e))
    })
    q <- apply(estimates, 1L, stats::quantile, probs = c(.025, .975), names = FALSE)
    cbind(x[1L, c("name", "model", "split"), drop = FALSE],
      data.frame(n_years = length(years), bootstrap_B = B, RMSE_low = q[1L, "RMSE"],
                 RMSE_high = q[2L, "RMSE"], bias_low = q[1L, "bias"], bias_high = q[2L, "bias"],
                 note = "Year-block resampling of fixed selected predictions; not parameter/predictive uncertainty"))
  }))
}

r69d_metric_long <- function(x, fields = c("RMSE", "MAE", "bias", "NSE", "r")) {
  keep <- intersect(c("name", "model", "split"), names(x))
  r69d_bind(lapply(fields, function(nm) {
    z <- x[keep]; z$metric <- nm; z$value <- x[[nm]]; z
  }))
}

r69d_plot_save <- function(plot, stem, cfg, width = 10, height = 6) {
  dir.create(dirname(stem), recursive = TRUE, showWarnings = FALSE)
  formats <- r69d_or(cfg$plot_formats, c("png", "pdf"))
  r69d_need(length(formats) > 0 && all(formats %in% c("png", "pdf")), "Only png/pdf plot formats supported")
  for (format in formats) ggplot2::ggsave(paste0(stem, ".", format), plot = plot,
    width = width, height = height, units = "in", dpi = r69d_or(cfg$dpi, 300),
    limitsize = FALSE, bg = "white")
}

r69d_plot_all <- function(cfg, output_dir, pairs, metrics, parameters, convergence, selection) {
  if (!nrow(metrics)) return(invisible(NULL))
  r69d_need(requireNamespace("ggplot2", quietly = TRUE), "ggplot2 required for make_plots=TRUE")
  figures <- file.path(output_dir, "figures")
  model_order <- c(cfg$models, "Ensemble_mean")
  metrics$model <- factor(metrics$model, levels = model_order)
  long <- r69d_metric_long(metrics)
  long <- long[is.finite(long$value), , drop = FALSE]
  # Each point/boxplot contribution is ONE lake, not one observation window.
  p <- ggplot2::ggplot(long, ggplot2::aes(x = model, y = value, fill = model)) +
    ggplot2::geom_boxplot(outlier.shape = NA, width = .65) +
    ggplot2::geom_point(position = ggplot2::position_jitter(width = .12, height = 0, seed = 1),
                        alpha = .35, size = .8) +
    ggplot2::facet_grid(metric ~ split, scales = "free_y") +
    ggplot2::labs(x = NULL, y = "Lake-level metric", title = "Accepted models: calibration and independent validation",
                  subtitle = "One point per lake; same approved windows for every model and equal-weight ensemble") +
    ggplot2::theme_bw() + ggplot2::theme(legend.position = "none", axis.text.x = ggplot2::element_text(angle = 40, hjust = 1))
  r69d_plot_save(p, file.path(figures, "performance_by_lake_boxplots"), cfg, 12, 12)

  p <- ggplot2::ggplot(long, ggplot2::aes(x = value, fill = model)) +
    ggplot2::geom_histogram(bins = 15, colour = "white") +
    ggplot2::facet_grid(metric ~ model + split, scales = "free") +
    ggplot2::labs(x = "Lake-level metric", y = "Number of accepted lakes",
                  title = "Metric distributions (Feldbauer-style descriptive comparison)") + ggplot2::theme_bw()
  r69d_plot_save(p, file.path(figures, "performance_distributions"), cfg, 20, 11)

  validation <- metrics[metrics$split == "validation", , drop = FALSE]
  if (nrow(validation)) {
    order_lakes <- names(sort(tapply(validation$RMSE, validation$name, mean)))
    validation$name <- factor(validation$name, levels = rev(order_lakes))
    p <- ggplot2::ggplot(validation, ggplot2::aes(x = model, y = name, fill = RMSE)) +
      ggplot2::geom_tile() + ggplot2::scale_fill_viridis_c() +
      ggplot2::labs(x = NULL, y = "Lake", fill = "RMSE (C)", title = "Independent-validation RMSE by lake and model") +
      ggplot2::theme_bw()
    r69d_plot_save(p, file.path(figures, "validation_RMSE_lake_model_matrix"), cfg,
                   8, max(5, .17 * length(order_lakes) + 2))
  }

  if (nrow(selection)) {
    shares <- as.data.frame(table(factor(selection$selected_model, levels = cfg$models)), stringsAsFactors = FALSE)
    names(shares) <- c("model", "lakes")
    shares$label <- paste0(shares$model, "\n", shares$lakes)
    p <- ggplot2::ggplot(shares, ggplot2::aes(x = "", y = lakes, fill = model)) +
      ggplot2::geom_col(width = 1, colour = "white") + ggplot2::coord_polar(theta = "y") +
      ggplot2::labs(x = NULL, y = NULL, title = "Model selected by CALIBRATION RMSE only",
                    subtitle = "Validation is not used to select a model or candidate") + ggplot2::theme_void()
    r69d_plot_save(p, file.path(figures, "training_selected_model_shares"), cfg, 7, 6)
  }

  if (nrow(parameters)) {
    scaling <- parameters[parameters$parameter %in% c("wind_speed", "swr", "Kw"), , drop = FALSE]
    if (nrow(scaling)) {
      scaling$plot_value <- ifelse(scaling$parameter == "Kw", scaling$Kw_multiplier, scaling$value)
      scaling$plot_parameter <- ifelse(scaling$parameter == "Kw", "Kw / input Kw0", scaling$parameter)
      scaling <- scaling[is.finite(scaling$plot_value), , drop = FALSE]
      if (nrow(scaling)) {
        p <- ggplot2::ggplot(scaling, ggplot2::aes(x = model, y = plot_value, fill = model)) +
          ggplot2::geom_hline(yintercept = 1, linetype = 2, colour = "grey40") +
          ggplot2::geom_boxplot(outlier.shape = NA) +
          ggplot2::geom_point(position = ggplot2::position_jitter(width = .12, height = 0, seed = 1), alpha = .35, size = .8) +
          ggplot2::facet_wrap(~ plot_parameter, scales = "free_y") +
          ggplot2::labs(x = NULL, y = "Selected multiplier", title = "Best parameters selected using calibration RMSE",
                        subtitle = "Feldbauer Fig. 7 style; fixed parameters have no fitted distribution") +
          ggplot2::theme_bw() + ggplot2::theme(legend.position = "none", axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
        r69d_plot_save(p, file.path(figures, "best_scaling_parameter_distributions"), cfg, 11, 6)
      }
    }
    p <- ggplot2::ggplot(parameters, ggplot2::aes(x = model, y = position_sampling, fill = model)) +
      ggplot2::geom_hline(yintercept = c(0, 1), colour = "grey40") +
      ggplot2::geom_boxplot(outlier.shape = NA) +
      ggplot2::geom_point(position = ggplot2::position_jitter(width = .1, height = 0, seed = 1), alpha = .4, size = .8) +
      ggplot2::facet_wrap(~ parameter) + ggplot2::coord_cartesian(ylim = c(0, 1)) +
      ggplot2::labs(x = NULL, y = "Fractional position in sampling domain",
                    title = "Supplemental search-boundary diagnostic",
                    subtitle = "Log coordinates for log-sampled parameters; not the definition of Feldbauer Fig. 7") +
      ggplot2::theme_bw() + ggplot2::theme(legend.position = "none", axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
    r69d_plot_save(p, file.path(figures, "best_parameters_search_domain_positions"), cfg, 11, 7)
  }

  if (nrow(convergence)) {
    p <- ggplot2::ggplot(convergence, ggplot2::aes(x = attempted_prefix, y = best_calibration_RMSE,
                    group = name, colour = model)) + ggplot2::geom_line(alpha = .25) +
      ggplot2::facet_wrap(~ model, scales = "free_y") +
      ggplot2::labs(x = "Prefix of original LHC candidate order (failed attempts included)", y = "Best calibration RMSE (C)",
                    title = "Training-only search progress",
                    subtitle = "Prefixes of one pool are not independent convergence experiments") +
      ggplot2::theme_bw() + ggplot2::theme(legend.position = "none")
    r69d_plot_save(p, file.path(figures, "training_LHC_prefix_progress"), cfg, 11, 7)
  }

  if (!isFALSE(cfg$plot_per_lake)) for (name in unique(pairs$name)) {
    z <- pairs[pairs$name == name, , drop = FALSE]
    z$model <- factor(z$model, levels = model_order)
    root <- file.path(output_dir, "per_lake", name)
    p <- ggplot2::ggplot(z, ggplot2::aes(x = label_datetime)) +
      ggplot2::geom_line(ggplot2::aes(y = predicted), colour = "steelblue", linewidth = .35) +
      ggplot2::geom_point(ggplot2::aes(y = observed), colour = "black", size = .45) +
      ggplot2::facet_grid(model ~ split, scales = "free_x") +
      ggplot2::labs(x = "UTC observation-window midpoint", y = "Window LSWT (C)",
                    title = paste(name, "- selected prediction and observed window LSWT"),
                    subtitle = "Black: observed; blue: model window prediction. Midpoints are plotting labels, not satellite overpass times.") +
      ggplot2::theme_bw()
    r69d_plot_save(p, file.path(root, "window_LSWT_time_series"), cfg, 13, 11)
    p <- ggplot2::ggplot(z, ggplot2::aes(x = observed, y = predicted, colour = split)) +
      ggplot2::geom_abline(intercept = 0, slope = 1, linetype = 2, colour = "grey40") +
      ggplot2::geom_point(alpha = .45, size = .7) + ggplot2::facet_wrap(~ model) +
      ggplot2::coord_equal() + ggplot2::labs(x = "Observed window LSWT (C)", y = "Predicted window LSWT (C)", title = name) + ggplot2::theme_bw()
    r69d_plot_save(p, file.path(root, "observed_predicted_scatter"), cfg, 11, 7)
    p <- ggplot2::ggplot(z, ggplot2::aes(x = predicted, y = residual, colour = split)) +
      ggplot2::geom_hline(yintercept = 0, linetype = 2) + ggplot2::geom_point(alpha = .4, size = .6) +
      ggplot2::facet_wrap(~ model) + ggplot2::labs(x = "Predicted window LSWT (C)", y = "Prediction - observation (C)", title = paste(name, "- residuals")) + ggplot2::theme_bw()
    r69d_plot_save(p, file.path(root, "residual_vs_prediction"), cfg, 11, 7)
    p <- ggplot2::ggplot(z, ggplot2::aes(x = DOY, y = residual, colour = split)) +
      ggplot2::geom_hline(yintercept = 0, linetype = 2) + ggplot2::geom_point(alpha = .4, size = .6) +
      ggplot2::facet_wrap(~ model) + ggplot2::labs(x = "DOY of UTC window midpoint", y = "Prediction - observation (C)", title = paste(name, "- seasonal residuals")) + ggplot2::theme_bw()
    r69d_plot_save(p, file.path(root, "residual_vs_DOY"), cfg, 11, 7)
    p <- ggplot2::ggplot(z, ggplot2::aes(x = residual, fill = split)) +
      ggplot2::geom_histogram(bins = 25, position = "identity", alpha = .55) +
      ggplot2::geom_vline(xintercept = 0, linetype = 2) + ggplot2::facet_wrap(~ model, scales = "free_y") +
      ggplot2::labs(x = "Prediction - observation (C)", y = "Number of windows", title = paste(name, "- residual distribution")) + ggplot2::theme_bw()
    r69d_plot_save(p, file.path(root, "residual_histograms"), cfg, 11, 7)
  }
  invisible(TRUE)
}

collect_research_results <- function(cfg, lakes, run_index = NULL) {
  r69d_need(is.character(cfg$results_root) && length(cfg$results_root) == 1L,
            "cfg$results_root is required")
  r69d_need(is.character(cfg$models) && length(cfg$models) >= 1L && !anyDuplicated(cfg$models),
            "cfg$models must identify the actual accepted model ensemble")
  r69d_need(is.data.frame(lakes) && "name" %in% names(lakes) && !anyDuplicated(lakes$name),
            "lakes needs unique name identifiers")
  if (is.null(run_index)) run_index <- r69d_read(file.path(cfg$results_root, "run_index.csv"))
  r69d_need(all(c("name", "run_dir", "evaluation_status", "input_signature") %in% names(run_index)),
            "run_index needs name,run_dir,evaluation_status,input_signature")
  r69d_need(!anyDuplicated(run_index$name) && all(run_index$name %in% lakes$name),
            "Duplicate or unknown lake in run_index")
  analysis_root <- file.path(cfg$results_root, "analysis")
  reports_root <- file.path(analysis_root, "reports")
  dir.create(reports_root, recursive = TRUE, showWarnings = FALSE)
  output_dir <- tempfile(paste0("report_", format(Sys.time(), "%Y%m%dT%H%M%SZ", tz = "UTC"), "_"),
                         tmpdir = reports_root)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  output_dir <- normalizePath(output_dir, winslash = "/", mustWork = TRUE)
  started_utc <- format(Sys.time(), "%Y-%m-%d %H:%M:%S", tz = "UTC")
  completed <- FALSE; accepted <- character()
  on.exit({
    report_status <- data.frame(output_dir = output_dir, started_UTC = started_utc,
      ended_UTC = format(Sys.time(), "%Y-%m-%d %H:%M:%S", tz = "UTC"),
      status = if (!completed) "incomplete" else if (!length(accepted)) "complete_empty" else
        if (length(accepted) == nrow(lakes)) "complete_all_requested" else "complete_partial",
      accepted_lakes = length(accepted), requested_lakes = nrow(lakes), stringsAsFactors = FALSE)
    try(r69d_write(report_status, file.path(output_dir, "analysis_status.csv")), silent = TRUE)
    try(r69d_write(report_status, file.path(analysis_root, "latest_attempt.csv")), silent = TRUE)
    if (completed) try(r69d_write(report_status, file.path(analysis_root, "latest_report.csv")), silent = TRUE)
  }, add = TRUE)
  boundary <- r69d_or(cfg$parameter_boundary_fraction, .05)
  r69d_need(is.numeric(boundary) && length(boundary) == 1L && is.finite(boundary) && boundary >= 0 && boundary < .5,
            "parameter_boundary_fraction must be in [0,.5)")
  all_pairs <- all_parameters <- all_convergence <- failure_rows <- fixed_kw <- list()
  accepted <- character(); errors <- list()
  ready <- run_index[!is.na(run_index$evaluation_status) & run_index$evaluation_status == "ok", , drop = FALSE]
  for (i in seq_len(nrow(ready))) {
    name <- as.character(ready$name[i]); run_dir <- as.character(ready$run_dir[i])
    result <- tryCatch({
      ctx <- r69d_verify_context(run_dir, cfg$models, as.character(ready$input_signature[i]))
      best <- r69d_read(file.path(run_dir, "best_by_calibration_RMSE.csv"))
      summary <- r69d_read(file.path(run_dir, "calibration_summary.csv"))
      final <- r69d_read(file.path(run_dir, "final_metrics.csv"))
      r69d_need(all(c("model", "par_id") %in% names(best)) && nrow(best) == length(cfg$models) &&
                  !anyDuplicated(best$model) && setequal(as.character(best$model), cfg$models),
                "Best-candidate model coverage is incomplete")
      r69d_need(all(c("model", "par_id", "status", "objective") %in% names(summary)), "Incomplete candidate summary")
      r69d_need(all(c("model", "par_id", "split", "N", "RMSE", "MAE", "bias", "NSE", "r") %in% names(final)),
                "Incomplete final metric table")
      r69d_need(nrow(final) == 2L * length(cfg$models) &&
                  setequal(as.character(final$model), cfg$models) &&
                  setequal(as.character(final$split), c("calibration", "validation")),
                "Accepted final metric coverage is incomplete or contains extra rows")
      pairs <- list()
      for (split in c("calibration", "validation")) {
        by_model <- setNames(vector("list", length(cfg$models)), cfg$models)
        for (m in cfg$models) {
          id <- as.character(best$par_id[best$model == m])
          valid <- summary[summary$model == m & summary$status == "ok" & is.finite(summary$objective), , drop = FALSE]
          r69d_need(nrow(valid) > 0L, "No successful training candidate: ", m)
          training_id <- as.character(valid$par_id[order(valid$objective, valid$par_id)][1L])
          r69d_need(identical(id, training_id), "Best ID does not match calibration-RMSE selection: ", m)
          z <- r69d_read_pairs(run_dir, m, id, split)
          check <- r69d_metrics(z$observed, z$predicted)
          if (identical(split, "calibration")) {
            objective <- as.numeric(valid$objective[as.character(valid$par_id) == id])
            r69d_need(length(objective) == 1L && is.finite(objective) &&
                abs(objective - check$RMSE) <= 1e-8 * max(1, abs(check$RMSE)),
              "Training final pairs differ from selected objective: ", m)
          }
          reported <- final[final$model == m & final$split == split & final$par_id == id, , drop = FALSE]
          r69d_need(nrow(reported) == 1L, "Missing/duplicate accepted final metrics: ", m, "/", split)
          for (field in c("N", "RMSE", "MAE", "bias", "NSE", "r")) {
            a <- as.numeric(check[[field]]); b <- as.numeric(reported[[field]])
            r69d_need((is.na(a) && is.na(b)) || (is.finite(a) && is.finite(b) && abs(a-b) <= 1e-8 * max(1, abs(a))),
                      "Final pairs no longer match accepted final metric: ", m, "/", split, "/", field)
          }
          by_model[[m]] <- z
        }
        ensemble <- r69d_align_ensemble(by_model, cfg$models)
        pairs <- c(pairs, by_model, list(ensemble))
      }
      pair <- r69d_bind(pairs); pair$name <- name
      cal_ids <- unique(pair$window_id[pair$split == "calibration"])
      val_ids <- unique(pair$window_id[pair$split == "validation"])
      r69d_need(!length(intersect(cal_ids, val_ids)), "Calibration/validation window IDs overlap")
      pars <- r69d_parameter_tables(name, ctx, best, boundary)
      convergence <- r69d_convergence(name, ctx, summary)
      kw0 <- suppressWarnings(as.numeric(ctx$base$input$light$Kw$all))
      if (length(kw0) != 1L || !is.finite(kw0)) kw0 <- NA_real_
      is_kw_fit <- any(pars$parameter == "Kw")
      failures <- summary[summary$status != "ok", , drop = FALSE]
      if (nrow(failures)) failures$name <- name
      list(pairs = pair, parameters = pars, convergence = convergence, failures = failures,
           fixed_kw = data.frame(name = name, input_Kw0_m_inverse = kw0, Kw_calibrated = is_kw_fit,
               note = if (is_kw_fit) "Kw was sampled; selected multiplier recorded" else "Kw fixed; no best-Kw distribution exists"))
    }, error = function(e) e)
    if (inherits(result, "error")) errors[[length(errors)+1L]] <- data.frame(name = name, error = conditionMessage(result))
    else {
      accepted <- c(accepted, name)
      all_pairs[[name]] <- result$pairs; all_parameters[[name]] <- result$parameters
      all_convergence[[name]] <- result$convergence; failure_rows[[name]] <- result$failures
      fixed_kw[[name]] <- result$fixed_kw
    }
  }
  pairs <- r69d_bind(all_pairs); parameters <- r69d_bind(all_parameters)
  convergence <- r69d_bind(all_convergence)
  coverage <- data.frame(name = as.character(lakes$name), accepted_for_analysis = lakes$name %in% accepted,
    evaluation_status = as.character(run_index$evaluation_status[match(lakes$name, run_index$name)]), stringsAsFactors = FALSE)
  r69d_write(coverage, file.path(output_dir, "lake_coverage.csv"))
  r69d_write(r69d_bind(errors), file.path(output_dir, "diagnostic_input_errors.csv"))
  r69d_write(r69d_bind(failure_rows), file.path(output_dir, "failed_calibration_candidates.csv"))
  r69d_write(parameters, file.path(output_dir, "best_parameter_values_and_bounds.csv"))
  r69d_write(convergence, file.path(output_dir, "training_only_LHC_prefix_progress.csv"))
  r69d_write(r69d_bind(fixed_kw), file.path(output_dir, "input_Kw_and_fit_status.csv"))
  notes <- c(
    paste0("Accepted lakes: ", length(accepted), "/", nrow(lakes), ". Partial coverage must not be described as a completed 69-lake study."),
    "Metrics use MODIS observation windows. Daily model output does not create daily observed temperatures.",
    "Within-lake metrics require identical approved windows and observations for all requested models. No silent NA deletion.",
    "Ensemble_mean is the equal arithmetic mean of all requested models, each member selected by calibration RMSE only.",
    "Validation data are never used here to reselect parameters, the model, or LHC sample size.",
    "Across-lake plots/summaries give each accepted lake one contribution; they are not observation-pooled skill estimates.",
    "RMSE/MAE/bias are in degrees Celsius; bias = predicted - observed. Undefined NSE/correlation are flagged.",
    "nMAE_range_percent = 100*MAE/(max observed - min observed); nRMSE uses the same denominator. These are explicitly defined supplemental metrics.",
    "KGE and percentage bias are not reported: ratios of Celsius means are origin-dependent and unstable near zero.",
    "Model spread is descriptive ensemble spread, not a calibrated confidence or prediction interval.",
    "A window's midpoint is used only for plotting and year/month/DOY grouping; it is not a known satellite overpass timestamp.",
    "The best-parameter multiplier plot follows Feldbauer Fig. 7 in form. Fixed Kw is not shown as a sampled best-parameter distribution.",
    "Search-domain positions are supplemental diagnostics, not the parameter definition used in Feldbauer Fig. 7.",
    "Search prefixes are subsets of the same LHC pool, not independent evidence that the full sample size is adequate.",
    "LSWT-only observations cannot validate thermocline depth, deep-water temperature, stratification duration or ice phenology. No such observed-skill figures are fabricated.",
    "DN>0 screening is the user's temperature proxy. It does not independently prove an entire window was ice free.")
  writeLines(notes, file.path(output_dir, "INTERPRETATION.txt"), useBytes = TRUE)
  if (!nrow(pairs)) {
    completed <- TRUE
    return(invisible(list(output_dir = output_dir, coverage = coverage,
      errors = r69d_bind(errors), metrics = data.frame(), parameters = parameters)))
  }
  metrics <- r69d_group_metrics(pairs, c("name", "model", "split"))
  annual <- r69d_group_metrics(pairs, c("name", "model", "split", "year"))
  monthly <- r69d_group_metrics(pairs, c("name", "model", "split", "month"))
  long <- r69d_metric_long(metrics)
  groups <- split(seq_len(nrow(long)), paste(long$model, long$split, long$metric, sep = "\r"))
  across <- r69d_bind(lapply(groups, function(ii) {
    z <- long[ii, , drop = FALSE]; v <- z$value[is.finite(z$value)]
    q <- if (length(v)) stats::quantile(v, c(.25,.5,.75), names = FALSE) else rep(NA_real_,3)
    data.frame(model = z$model[1], split = z$split[1], metric = z$metric[1],
      lakes_total = nrow(z), lakes_finite = length(v), median = q[2], q25 = q[1], q75 = q[3],
      mean_of_lake_metrics = if (length(v)) mean(v) else NA_real_)
  }))
  selection <- r69d_bind(lapply(split(metrics, metrics$name), function(z) {
    train <- z[z$split == "calibration" & z$model %in% cfg$models, , drop = FALSE]
    chosen <- as.character(train$model[order(train$RMSE, match(train$model, cfg$models))][1L])
    val <- z[z$split == "validation" & z$model == chosen, , drop = FALSE]
    data.frame(name = z$name[1], selected_model = chosen,
      calibration_RMSE = train$RMSE[train$model == chosen], validation_RMSE = val$RMSE,
      selection_rule = "calibration RMSE; ties resolved by cfg$models order", stringsAsFactors = FALSE)
  }))
  comparison <- r69d_bind(lapply(split(metrics, paste(metrics$name, metrics$split, sep = "\r")), function(z) {
    reference <- z$RMSE[z$model == "Ensemble_mean"]
    z$RMSE_skill_vs_equal_mean <- if (length(reference) == 1L && is.finite(reference) && reference > 0)
      1 - z$RMSE/reference else NA_real_
    z
  }))
  r69d_write(pairs, file.path(output_dir, "accepted_common_window_pairs.csv"))
  r69d_write(comparison, file.path(output_dir, "lake_model_split_metrics.csv"))
  r69d_write(annual, file.path(output_dir, "lake_model_year_metrics.csv"))
  r69d_write(monthly, file.path(output_dir, "lake_model_month_metrics.csv"))
  r69d_write(across, file.path(output_dir, "across_lake_metric_distributions.csv"))
  r69d_write(selection, file.path(output_dir, "model_selected_by_training_RMSE.csv"))
  boot <- r69d_year_bootstrap(pairs, r69d_or(cfg$diagnostic_bootstrap_B, 0L), r69d_or(cfg$seed, 20261026L))
  if (nrow(boot)) r69d_write(boot, file.path(output_dir, "optional_year_block_bootstrap.csv"))
  if (!isFALSE(cfg$make_plots)) r69d_plot_all(cfg, output_dir, pairs, metrics, parameters, convergence, selection)
  completed <- TRUE
  invisible(list(output_dir = output_dir, coverage = coverage, errors = r69d_bind(errors),
    pairs = pairs, metrics = comparison, parameters = parameters, convergence = convergence,
    selection = selection, annual = annual, monthly = monthly))
}


# ===== Bundled module: 04_sensitivity.R =====
# Feldbauer-style given-data sensitivity of calibration LHC performance metrics.
# This module never calls a model and never scores or selects validation data.
# The accompanying Python helper uses the pinned SALib estimator, not a new
# unverified R approximation. No package is installed by this module.

r69_gsa_value <- function(cfg, name, default = NULL) {
  value <- cfg[[name]]
  if (is.null(value)) default else value
}

r69_gsa_read <- function(path) {
  if (!file.exists(path)) stop("Missing sensitivity input: ", path, call. = FALSE)
  x <- utils::read.csv(path, fileEncoding = "UTF-8-BOM", check.names = FALSE,
                       stringsAsFactors = FALSE, na.strings = c("NA", "NaN", ""))
  if (anyDuplicated(names(x))) stop("Duplicate CSV names: ", path, call. = FALSE)
  x
}

r69_gsa_write <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(x, path, row.names = FALSE, na = "NA", fileEncoding = "UTF-8")
  invisible(path)
}

r69_gsa_locations <- function(cfg) {
  executable <- r69_gsa_value(cfg, "python_exe", "")
  if (!nzchar(executable)) {
    choices <- Sys.which(c("python", "python3"))
    choices <- unname(choices[nzchar(choices)])
    if (length(choices)) executable <- choices[1L]
  }
  if (!nzchar(executable)) stop("Set cfg$python_exe to the actual Windows python.exe path", call. = FALSE)
  if (!file.exists(executable)) {
    found <- Sys.which(executable)
    if (!nzchar(found)) stop("Python executable not found: ", executable, call. = FALSE)
    executable <- unname(found)
  }
  executable <- normalizePath(executable, winslash = "/", mustWork = TRUE)
  script <- r69_gsa_value(cfg, "gsa_script", NULL)
  if (is.null(script)) {
    root <- r69_gsa_value(cfg, "bundle_root", r69_gsa_value(cfg, "code_dir", ""))
    script <- file.path(root, "python", "delta_analysis.py")
  }
  if (!file.exists(script)) stop("Missing bundled Python GSA helper: ", script, call. = FALSE)
  list(python = executable, script = normalizePath(script, winslash = "/", mustWork = TRUE))
}

r69_gsa_system <- function(python, args, env = character()) {
  # system2(env=...) is not general-purpose on Windows. Set only temporary
  # process variables, let the child inherit them, then restore the R session.
  if (length(env)) {
    split_at <- regexpr("=", env, fixed = TRUE)
    if (any(split_at < 2L)) stop("Invalid temporary child environment assignment", call. = FALSE)
    keys <- substring(env, 1L, split_at - 1L)
    values <- substring(env, split_at + 1L)
    if (anyDuplicated(keys)) stop("Duplicate temporary environment keys", call. = FALSE)
    previous <- Sys.getenv(keys, unset = NA_character_)
    on.exit({
      absent <- is.na(previous)
      if (any(absent)) Sys.unsetenv(keys[absent])
      if (any(!absent)) do.call(Sys.setenv, as.list(stats::setNames(previous[!absent], keys[!absent])))
    }, add = TRUE)
    do.call(Sys.setenv, as.list(stats::setNames(values, keys)))
  }
  output <- suppressWarnings(system2(python, args = vapply(args, shQuote, character(1)),
                                      stdout = TRUE, stderr = TRUE))
  status <- attr(output, "status")
  if (is.null(status)) status <- 0L
  list(status = as.integer(status), output = output)
}

r69_gsa_preflight <- function(cfg) {
  locations <- r69_gsa_locations(cfg)
  if (!requireNamespace("digest", quietly = TRUE)) {
    stop("Sensitivity provenance requires digest; this workflow does not install it", call. = FALSE)
  }
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Sensitivity plots require ggplot2; this workflow does not install it", call. = FALSE)
  }
  check <- r69_gsa_system(locations$python, c(locations$script, "--check"))
  if (check$status != 0L) {
    stop("Sensitivity Python preflight failed. Use requirements-gsa.txt in the selected Python environment.\n",
         paste(check$output, collapse = "\n"), call. = FALSE)
  }
  resamples <- r69_gsa_value(cfg, "num_resamples", 100L)
  minimum <- r69_gsa_value(cfg, "gsa_min_samples", 500L)
  confidence <- r69_gsa_value(cfg, "gsa_conf_level", .95)
  if (length(resamples) != 1L || !is.finite(resamples) || resamples < 2 || resamples != floor(resamples))
    stop("cfg$num_resamples must be an integer >=2 (research default 100)", call. = FALSE)
  if (length(minimum) != 1L || !is.finite(minimum) || minimum < 20 || minimum != floor(minimum))
    stop("cfg$gsa_min_samples must be an integer >=20 (research default 500)", call. = FALSE)
  if (length(confidence) != 1L || !is.finite(confidence) || confidence <= 0 || confidence >= 1)
    stop("cfg$gsa_conf_level must be in (0,1)", call. = FALSE)
  policy <- r69_gsa_value(cfg, "gsa_failure_policy", "strict")
  if (!policy %in% c("strict", "succeeded_only")) stop("Invalid cfg$gsa_failure_policy", call. = FALSE)
  invisible(list(locations = locations, versions = check$output, failure_policy = policy))
}

r69_gsa_bind <- function(x) {
  frames <- Filter(function(z) is.data.frame(z) && ncol(z) > 0L, x)
  x <- Filter(function(z) is.data.frame(z) && nrow(z) > 0L, frames)
  if (!length(x)) return(if (length(frames)) frames[[1L]][FALSE, , drop = FALSE] else data.frame())
  columns <- unique(unlist(lapply(x, names), use.names = FALSE))
  x <- lapply(x, function(z) {
    for (n in setdiff(columns, names(z))) z[[n]] <- NA
    z[, columns, drop = FALSE]
  })
  rownames_out <- do.call(rbind, x)
  rownames(rownames_out) <- NULL
  rownames_out
}

r69_gsa_bool <- function(x) tolower(as.character(x)) %in% c("true", "1", "t")

r69_gsa_save_plot <- function(plot, directory, filename, width, height) {
  for (extension in c("png", "pdf")) {
    ggplot2::ggsave(filename = file.path(directory, paste0(filename, ".", extension)),
                    plot = plot, width = width, height = height, units = "in", dpi = 300,
                    device = extension, limitsize = FALSE, bg = "white")
  }
}

r69_gsa_plots <- function(results, summaries, cfg, out) {
  if (!nrow(results)) return(invisible(NULL))
  gg <- asNamespace("ggplot2")
  real <- results[!r69_gsa_bool(results$is_dummy), , drop = FALSE]
  if (!nrow(real)) return(invisible(NULL))
  plots <- file.path(out, "figures")
  dir.create(plots, recursive = TRUE, showWarnings = FALSE)
  metrics <- unique(as.character(real$metric))
  n_lakes <- length(unique(real$lake))
  plot_receipts <- list()
  save <- function(plot, name, width, height) {
    error <- tryCatch({r69_gsa_save_plot(plot, plots, name, width, height); ""},
                      error = function(e) conditionMessage(e))
    plot_receipts[[length(plot_receipts) + 1L]] <<- data.frame(
      plot = name, status = if (nzchar(error)) "failed" else "ok", error = error)
  }
  # Raw finite-sample estimates are intentionally not clamped to [0,1].
  box <- rbind(transform(real, index = "Delta", value = delta),
               transform(real, index = "S1", value = S1))
  p <- ggplot2::ggplot(box, ggplot2::aes(x = parameter, y = value, fill = index)) +
    ggplot2::geom_boxplot(outlier.size = .5, position = ggplot2::position_dodge(width = .8)) +
    ggplot2::facet_grid(metric ~ model, scales = "free_x", space = "free_x") +
    ggplot2::scale_fill_manual(values = c(Delta = "#45B2DD", S1 = "#72035F")) +
    ggplot2::labs(x = "Sampled parameter", y = "Raw given-data sensitivity estimate", fill = "Index",
      title = "Sensitivity of calibration performance metrics across lakes",
      subtitle = "Delta and first-order S1 from LHC; no total-order indices are estimated") +
    ggplot2::theme_bw(base_size = 10) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 55, hjust = 1))
  save(p, "GSA_raw_index_distributions", 16, max(6, 2.5 * length(metrics)))

  for (metric_name in metrics) {
    z <- real[real$metric == metric_name, , drop = FALSE]
    z$lake <- factor(z$lake, levels = rev(sort(unique(real$lake))))
    for (index_name in c("delta", "S1")) {
      z$importance <- z[[paste0(index_name, "_filtered")]]
      p <- ggplot2::ggplot(z, ggplot2::aes(x = parameter, y = lake, fill = importance)) +
        ggplot2::geom_tile(colour = "white", linewidth = .1) +
        ggplot2::facet_grid(. ~ model, scales = "free_x", space = "free_x") +
        ggplot2::scale_fill_viridis_c(option = "C", na.value = "grey85") +
        ggplot2::labs(x = "Sampled parameter", y = "Lake", fill = index_name,
          title = paste("Dummy-screened", index_name, "sensitivity of", metric_name),
          subtitle = "Real lower confidence bound must exceed dummy upper confidence bound",
          caption = "Missing jobs are listed in metric_status.csv; missing tiles do not mean zero sensitivity.") +
        ggplot2::theme_bw(base_size = 9) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 55, hjust = 1), panel.grid = ggplot2::element_blank())
      save(p, paste0("GSA_heatmap_", index_name, "_", metric_name), 15, max(7, .20 * n_lakes + 3))
    }
  }

  rate_rows <- list()
  for (index_name in c("delta", "S1")) {
    z <- real[, c("model", "metric", "parameter"), drop = FALSE]
    z$above_dummy <- as.integer(r69_gsa_bool(real[[paste0(index_name, "_sensitive")]]))
    counts <- stats::aggregate(z$above_dummy, z[c("model", "metric", "parameter")], sum)
    names(counts)[4] <- "n_above_dummy"
    denominator <- stats::aggregate(rep(1L, nrow(z)), z[c("model", "metric", "parameter")], sum)
    names(denominator)[4] <- "n_analyzed_lakes"
    combined <- merge(counts, denominator, by = c("model", "metric", "parameter"), sort = FALSE)
    combined$fraction_above_dummy <- combined$n_above_dummy / combined$n_analyzed_lakes
    combined$index <- index_name
    rate_rows[[index_name]] <- combined
  }
  rates <- r69_gsa_bind(rate_rows)
  r69_gsa_write(rates, file.path(out, "fraction_sensitive_lakes.csv"))
  p <- ggplot2::ggplot(rates, ggplot2::aes(parameter, fraction_above_dummy, fill = index)) +
    ggplot2::geom_col(position = "dodge") +
    ggplot2::facet_grid(metric ~ model, scales = "free_x", space = "free_x") +
    ggplot2::scale_fill_manual(values = c(delta = "#45B2DD", S1 = "#72035F")) +
    ggplot2::labs(x = "Parameter", y = "Fraction of analyzed lakes above dummy", fill = "Index") +
    ggplot2::theme_bw(base_size = 10) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 55, hjust = 1))
  save(p, "GSA_fraction_sensitive_lakes", 16, max(6, 2.5 * length(metrics)))

  if (nrow(summaries)) {
    for (definition in c("real", "including_dummy")) {
      summaries$value <- summaries[[paste0("interaction_", definition, "_raw")]]
      p <- ggplot2::ggplot(summaries, ggplot2::aes(model, value, fill = metric)) +
        ggplot2::geom_hline(yintercept = 0, colour = "grey50", linetype = 2) +
        ggplot2::geom_boxplot(outlier.size = .6) +
        ggplot2::labs(x = "Model", y = "1 - sum(raw S1)", fill = "Calibration metric",
          title = paste("Interaction residual:", gsub("_", " ", definition)),
          subtitle = "Finite-sample estimates are not clipped; not a total-order Sobol index") +
        ggplot2::theme_bw(base_size = 11)
      save(p, paste0("GSA_interaction_", definition), 11, 6)
    }

    top <- list()
    for (i in seq_len(nrow(summaries))) {
      labels <- as.character(summaries$top_delta_parameters[i])
      if (is.na(labels) || !nzchar(labels)) labels <- "none_above_dummy"
      names_top <- strsplit(labels, ";", fixed = TRUE)[[1]]
      top[[length(top) + 1L]] <- data.frame(
        lake = summaries$lake[i], model = summaries$model[i], metric = summaries$metric[i],
        parameter = names_top, fractional_lake_count = 1 / length(names_top))
    }
    top <- r69_gsa_bind(top)
    top_counts <- stats::aggregate(top$fractional_lake_count,
      top[c("model", "metric", "parameter")], sum)
    names(top_counts)[4] <- "fractional_lake_count"
    r69_gsa_write(top_counts, file.path(out, "most_sensitive_parameter_counts.csv"))
    p <- ggplot2::ggplot(top_counts, ggplot2::aes(parameter, fractional_lake_count)) +
      ggplot2::geom_col(fill = "#72035F") +
      ggplot2::facet_grid(metric ~ model, scales = "free_x", space = "free_x") +
      ggplot2::labs(x = "Most sensitive parameter by screened Delta",
                    y = "Lake count (ties share one vote)") +
      ggplot2::theme_bw(base_size = 10) +
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 55, hjust = 1))
    save(p, "GSA_most_sensitive_parameter", 16, max(6, 2.5 * length(metrics)))

    z <- summaries
    z$n_essential <- factor(z$n_essential_75_delta)
    p <- ggplot2::ggplot(z, ggplot2::aes(n_essential)) + ggplot2::geom_bar(fill = "#45B2DD") +
      ggplot2::facet_grid(metric ~ model) +
      ggplot2::labs(x = "Parameters covering 75% of positive screened Delta", y = "Number of lakes",
                    caption = "Zero means no positive parameter importance remained above the dummy screen; ties at cutoff are retained.") +
      ggplot2::theme_bw(base_size = 10)
    save(p, "GSA_essential_parameter_count_75pct", 14, max(6, 2.2 * length(metrics)))
  }
  plot_receipts <- r69_gsa_bind(plot_receipts)
  r69_gsa_write(plot_receipts, file.path(out, "plot_status.csv"))
  if (nrow(plot_receipts) && any(plot_receipts$status != "ok")) {
    stop("Some sensitivity figures failed; inspect plot_status.csv", call. = FALSE)
  }
  invisible(TRUE)
}

r69_run_sensitivity <- function(cfg, registry, run_index = NULL) {
  if (is.null(cfg$results_root) || !nzchar(cfg$results_root)) stop("cfg$results_root is missing", call. = FALSE)
  analysis_root <- file.path(cfg$results_root, "analysis", "sensitivity")
  reports <- file.path(analysis_root, "reports")
  dir.create(reports, recursive = TRUE, showWarnings = FALSE)
  stamp <- format(Sys.time(), "%Y%m%dT%H%M%S", tz = "UTC")
  out <- tempfile(paste0("gsa_", stamp, "_"), tmpdir = reports)
  dir.create(out, recursive = TRUE)
  latest <- file.path(analysis_root, "latest_report.csv")
  report_state <- "failed_or_interrupted"
  update_pointer <- function(state) {
    r69_gsa_write(data.frame(report_dir = normalizePath(out, winslash = "/", mustWork = TRUE),
                             status = state, updated_utc = format(Sys.time(), "%Y-%m-%d %H:%M:%S", tz = "UTC")), latest)
  }
  update_pointer("running")
  on.exit(update_pointer(report_state), add = TRUE)
  preflight <- r69_gsa_preflight(cfg)
  if (is.null(run_index)) run_index <- r69_gsa_read(file.path(cfg$results_root, "run_index.csv"))
  if (!all(c("name", "run_dir") %in% names(run_index)) || anyDuplicated(run_index$name))
    stop("Sensitivity requires a unique run_index with name and run_dir", call. = FALSE)
  if (!is.data.frame(registry) || !"name" %in% names(registry) || anyDuplicated(registry$name))
    stop("Sensitivity registry requires unique name", call. = FALSE)
  writeLines(preflight$versions, file.path(out, "python_runtime_check.txt"), useBytes = TRUE)
  metrics <- r69_gsa_value(cfg, "gsa_metrics", c("RMSE", "NSE", "r", "bias"))
  models <- cfg$models
  if (!length(models)) stop("cfg$models is missing", call. = FALSE)
  resamples <- r69_gsa_value(cfg, "num_resamples", 100L)
  minimum <- r69_gsa_value(cfg, "gsa_min_samples", 500L)
  confidence <- r69_gsa_value(cfg, "gsa_conf_level", .95)
  seed <- r69_gsa_value(cfg, "gsa_seed", r69_gsa_value(cfg, "seed", 20261026L))
  jobs <- results <- summaries <- statuses <- list()
  for (lake in as.character(registry$name)) {
    row <- run_index[run_index$name == lake, , drop = FALSE]
    # A separate sensitivity stage must not re-authorize edited calibration CSVs.
    # This validates context_integrity.csv and every ctx$calibration_files hash.
    integrity_error <- ""
    if (nrow(row) == 1L && !is.na(row$run_dir) && nzchar(row$run_dir) && dir.exists(row$run_dir)) {
      integrity_error <- tryCatch({
        if (!exists("r69_check_calibration_integrity", mode = "function"))
          stop("Source R/02_runner.R before sensitivity: r69_check_calibration_integrity is required")
        r69_check_calibration_integrity(row$run_dir)
        ""
      }, error = function(e) conditionMessage(e))
    }
    for (model in models) {
      reason <- ""
      if (nrow(row) != 1L) reason <- "No unique calibration run in run_index"
      if (!nzchar(reason) && "calibration_status" %in% names(row) && !identical(as.character(row$calibration_status), "ok"))
        reason <- "Calibration was not accepted by runner"
      if (!nzchar(reason) && (is.na(row$run_dir) || !nzchar(row$run_dir) || !dir.exists(row$run_dir)))
        reason <- "Calibration run_dir missing"
      if (!nzchar(reason) && nzchar(integrity_error)) reason <- paste("Calibration integrity rejected:", integrity_error)
      directory <- ""
      if (nzchar(reason)) {
        jobs[[length(jobs) + 1L]] <- data.frame(name = lake, model = model, status = "skipped", reason = reason,
                                              output_dir = directory)
        next
      }
      run_dir <- row$run_dir
      files <- c(params = file.path(run_dir, paste0("params_", model, ".csv")),
                 spec = file.path(run_dir, paste0("spec_", model, ".csv")),
                 summary = file.path(run_dir, "calibration_summary.csv"))
      if (!all(file.exists(files))) {
        jobs[[length(jobs) + 1L]] <- data.frame(name = lake, model = model, status = "skipped",
          reason = paste("Missing calibration files:", paste(files[!file.exists(files)], collapse = "; ")), output_dir = directory)
        next
      }
      # Case cache identity includes original sealed inputs, estimator, settings
      # and Python versions. Every aggregate report is nevertheless a new version.
      cache_key <- substr(digest::digest(list(
        files = vapply(files, function(p) digest::digest(file = p, algo = "sha256", serialize = FALSE), character(1)),
        script = digest::digest(file = preflight$locations$script, algo = "sha256", serialize = FALSE),
        lake = lake, model = model, metrics = metrics, resamples = resamples,
        minimum = minimum, confidence = confidence, failure_policy = preflight$failure_policy,
        seed = seed, runtime = preflight$versions), algo = "sha256"), 1L, 32L)
      directory <- file.path(analysis_root, "cases", lake, model, cache_key)
      args <- c(preflight$locations$script,
                "--params", files[["params"]], "--spec", files[["spec"]], "--summary", files[["summary"]],
                "--lake", lake, "--model", model, "--out", directory,
                "--metrics", paste(metrics, collapse = ","), "--resamples", as.character(resamples),
                "--conf-level", as.character(confidence), "--min-samples", as.character(minimum),
                "--failure-policy", preflight$failure_policy, "--seed", as.character(seed))
      if (isTRUE(r69_gsa_value(cfg, "resume", TRUE))) args <- c(args, "--resume")
      message("GSA (calibration metrics only): ", lake, " / ", model)
      # Avoid nested BLAS thread oversubscription; model PSOCK workers are not used here.
      job <- r69_gsa_system(preflight$locations$python, args,
                            env = c("OPENBLAS_NUM_THREADS=1", "OMP_NUM_THREADS=1", "MKL_NUM_THREADS=1"))
      log_dir <- file.path(out, "logs")
      dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
      writeLines(job$output, file.path(log_dir, paste0(lake, "_", model, ".log")), useBytes = TRUE)
      jobs[[length(jobs) + 1L]] <- data.frame(name = lake, model = model,
        status = if (job$status == 0L) "complete_or_reused" else "failed",
        reason = if (job$status == 0L) "" else paste(job$output, collapse = " | "), output_dir = directory)
      if (job$status == 0L) {
        results[[length(results) + 1L]] <- r69_gsa_read(file.path(directory, "sensitivity.csv"))
        summaries[[length(summaries) + 1L]] <- r69_gsa_read(file.path(directory, "case_summary.csv"))
        statuses[[length(statuses) + 1L]] <- r69_gsa_read(file.path(directory, "metric_status.csv"))
      }
      r69_gsa_write(r69_gsa_bind(jobs), file.path(out, "job_status.csv"))
    }
  }
  jobs <- r69_gsa_bind(jobs); results <- r69_gsa_bind(results)
  summaries <- r69_gsa_bind(summaries); statuses <- r69_gsa_bind(statuses)
  r69_gsa_write(jobs, file.path(out, "job_status.csv"))
  r69_gsa_write(results, file.path(out, "sensitivity_all.csv"))
  r69_gsa_write(summaries, file.path(out, "case_summary_all.csv"))
  r69_gsa_write(statuses, file.path(out, "metric_status.csv"))
  plot_error <- tryCatch({r69_gsa_plots(results, summaries, cfg, out); ""},
                          error = function(e) conditionMessage(e))
  if (nzchar(plot_error)) writeLines(plot_error, file.path(out, "plot_error.txt"))
  writeLines(c(
    "Methods: Feldbauer et al. (2025), HESS 29, 1183-1199, doi:10.5194/hess-29-1183-2025, section 2.5.",
    "Estimator: SALib 1.5.1 delta.analyze(method='all'), independently seeded U(0,1) dummy.",
    "The confidence level and deterministic seeds are explicitly recorded implementation choices.",
    "Only calibration candidates/metrics are used. Independent validation results are never inputs.",
    "The default strict failure policy skips a metric if any candidate failed or its metric is nonfinite.",
    "succeeded_only, if explicitly selected, estimates a conditional retained domain and can have selection bias.",
    "No successful candidate is discarded for high RMSE; the author's RMSE<20 filter is not copied.",
    "Dummy screening: real(index-conf) > dummy(index+conf). conf values are confidence half-widths.",
    "Raw estimates, intervals, and 1-sum(S1) residuals are not clipped into [0,1].",
    "Both real-only and including-dummy interaction residuals are exported: the author's R script includes dummy literally.",
    "Essential groups cover 75% of positive screened importance and retain all ties at the cutoff.",
    "These estimates depend on the actual sampled parameter ranges, forcing, observations and metric.",
    "Fixed Kw/fetch/native parameters are not sampled and have no estimated sensitivity in this experiment.",
    "With the retained two-parameter YAML, this is not a replication of the paper's six-parameter design.",
    "LHC given-data first-order S1 is not a Saltelli A/B total-order sensitivity analysis.",
    "Paper code reference: https://github.com/aemon-j/isimip-sensitivity-analysis/tree/6ee43226b127d09692daa94709cb54d0b4d99e99."
  ), file.path(out, "METHODS_AND_LIMITATIONS.txt"), useBytes = TRUE)
  report_state <- if (nzchar(plot_error) || any(jobs$status != "complete_or_reused") ||
                      (nrow(statuses) && any(statuses$status != "ok"))) "complete_with_skips_or_failures" else "complete"
  invisible(list(status = report_state, output_dir = out, jobs = jobs, sensitivity = results,
                  cases = summaries, metric_status = statuses, plot_error = plot_error))
}


# ===== Bundled module: 05_daily_plots.R =====
# Daily native surface diagnostics after accepted independent evaluation.
# Observations remain window bars; no daily observations or water-column data are invented.
r69_daily_plots <- function(cfg, registry, index, accepted_report) {
  output <- accepted_report$output_dir
  coverage <- accepted_report$coverage
  selected <- as.character(coverage$name[coverage$accepted_for_analysis %in% TRUE])
  rows <- list()
  for (lake in selected) {
    error <- tryCatch({
      z <- index[index$name == lake & index$evaluation_status == "ok", , drop = FALSE]
      r69_main_need(nrow(z) == 1L, "Missing accepted run mapping: ", lake)
      run <- z$run_dir
      # collect_research_results has just verified this context, final manifest,
      # evaluation receipt and input signature before accepting the lake.
      ctx <- readRDS(file.path(run, "context.rds"))
      best <- utils::read.csv(file.path(run, "best_by_calibration_RMSE.csv"), stringsAsFactors = FALSE)
      daily <- list()
      for (model in cfg$models) {
        id <- as.character(best$par_id[best$model == model])
        r69_main_need(length(id) == 1L, "Missing best candidate for ", model)
        series <- readRDS(file.path(run, "final", model, id, "native_surface.rds"))
        r69_main_need(all(c("datetime", "temperature") %in% names(series)), "Bad native surface schema")
        native_time <- as.POSIXct(series$datetime, tz = "UTC")
        temperature <- as.numeric(series$temperature)
        r69_main_need(length(native_time) >= 2L && !anyNA(native_time) &&
          all(is.finite(temperature)) && all(diff(as.numeric(native_time)) > 0), "Invalid daily native series")
        con <- ctx$contracts[ctx$contracts$model == model, , drop = FALSE]
        r69_main_need(nrow(con) == 1L, "Missing accepted contract for ", model)
        r69_main_need(as.numeric(con$step_seconds) == 86400 &&
          all(abs(diff(as.numeric(native_time)) - 86400) <= .01),
          "Native series is not a complete daily sequence: ", model)
        physical_time <- native_time + as.numeric(con$timestamp_shift_seconds)
        if (as.character(con$method) == "interval_mean") {
          if (as.character(con$label_position) == "start") physical_time <- physical_time + con$step_seconds/2
          if (as.character(con$label_position) == "end") physical_time <- physical_time - con$step_seconds/2
        }
        daily[[model]] <- data.frame(model = model, native_datetime_UTC = native_time,
          plot_datetime_UTC = physical_time, temperature = temperature,
          contract_method = as.character(con$method), contract_label = as.character(con$label_position),
          contract_step_seconds = as.numeric(con$step_seconds), stringsAsFactors = FALSE)
      }
      full <- do.call(rbind, daily); rownames(full) <- NULL
      directory <- file.path(output, "per_lake", lake)
      dir.create(directory, recursive = TRUE, showWarnings = FALSE)
      exported <- full
      for (column in c("native_datetime_UTC", "plot_datetime_UTC"))
        exported[[column]] <- format(exported[[column]], "%Y-%m-%d %H:%M:%S", tz = "UTC")
      connection <- gzfile(file.path(directory, "best_native_surface_full_period.csv.gz"), "wt", encoding = "UTF-8")
      tryCatch(utils::write.csv(exported, connection, row.names = FALSE), finally = close(connection))
      start <- as.POSIXct("2001-01-01 00:00:00", tz = "UTC")
      division <- as.POSIXct("2011-01-01 00:00:00", tz = "UTC")
      end <- as.POSIXct("2016-01-01 00:00:00", tz = "UTC")
      full <- full[full$plot_datetime_UTC >= start & full$plot_datetime_UTC < end, , drop = FALSE]
      r69_main_need(nrow(full) > 0L, "No daily output in observation years")
      full$split <- ifelse(full$plot_datetime_UTC < division, "calibration", "validation")
      full$model <- factor(full$model, levels = cfg$models)
      observed <- accepted_report$pairs
      observed <- observed[observed$name == lake & observed$model %in% cfg$models, , drop = FALSE]
      observed$model <- factor(observed$model, levels = cfg$models)
      if (isTRUE(cfg$make_plots)) {
        p <- ggplot2::ggplot(full, ggplot2::aes(x = plot_datetime_UTC, y = temperature)) +
          ggplot2::geom_line(colour = "steelblue", linewidth = .22) +
          ggplot2::geom_segment(data = observed, inherit.aes = FALSE,
            ggplot2::aes(x = window_start, xend = window_end, y = observed, yend = observed),
            colour = "black", linewidth = .5) +
          ggplot2::facet_grid(model ~ split, scales = "free_x") +
          ggplot2::labs(x = "UTC physical plot time", y = "Near-surface temperature (C)",
            title = paste(lake, "- daily model outputs and observed composite windows"),
            subtitle = "Blue: native model series; black horizontal bars: observed window LSWT. Bars are not daily observations.",
            caption = "Contract time shifts applied; interval means plotted at interval centres. Point/sample/interval methods remain distinct.") +
          ggplot2::theme_bw()
        r69d_plot_save(p, file.path(directory, "daily_native_surface_and_observation_windows"), cfg, 14, 11)
        p <- ggplot2::ggplot(full, ggplot2::aes(x = plot_datetime_UTC, y = model, fill = temperature)) +
          ggplot2::geom_tile(width = 86400, height = .95) +
          ggplot2::facet_wrap(~ split, scales = "free_x", ncol = 1) +
          ggplot2::scale_fill_viridis_c(option = "C") +
          ggplot2::labs(x = "UTC physical plot time", y = "Model", fill = "C",
            title = paste(lake, "- daily near-surface model temperature"),
            subtitle = "Time x model heatmap; not a time x depth water-column reconstruction.",
            caption = "Tiles show native daily values under each accepted contract, not observed daily means. No daily ensemble is inferred across differing contracts.") +
          ggplot2::theme_bw()
        r69d_plot_save(p, file.path(directory, "daily_surface_time_model_heatmap"), cfg, 14, 7)
      }
      ""
    }, error = function(e) conditionMessage(e))
    rows[[length(rows) + 1L]] <- data.frame(name = lake,
      status = if (nzchar(error)) "failed" else "ok", error = error, stringsAsFactors = FALSE)
  }
  status <- if (length(rows)) do.call(rbind, rows) else data.frame(name = character(), status = character(), error = character())
  r69_main_csv(status, file.path(output, "daily_surface_diagnostic_status.csv"))
  invisible(list(status = if (length(selected) == nrow(registry) && all(status$status == "ok"))
    "complete" else "partial_or_skipped", jobs = status, output_dir = output))
}


# Entry point. All stages include checks before any long calibration.
if (!identical(Sys.getenv("LER69_LOAD_ONLY"), "1")) r69_main(CFG)
